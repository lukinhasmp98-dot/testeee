import dns.resolver
import pymongo
import uuid
import sys

dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
dns.resolver.default_resolver.nameservers = ["8.8.8.8", "8.8.4.4"]

VYEPAY_MONGO_URL = "mongodb+srv://luqi:4kz3BclT9i9X0vPV@cluster0.23zupby.mongodb.net/"
VYEPAY_DB = "vye-wallet"

BOTS_MONGO_URL = VYEPAY_MONGO_URL
SKIP_DBS = {"admin", "local", "config"}

def main():
    print("[DNS] Google DNS (8.8.8.8 / 8.8.4.4)")
    print("[1/3] Gerando internalApiSecret para usuarios VyePay existentes...\n")

    client = pymongo.MongoClient(VYEPAY_MONGO_URL, serverSelectionTimeoutMS=10000)

    try:
        client.admin.command("ping")
        print("[DB] Conexao OK!\n")
    except Exception as e:
        print(f"[DB] Falha: {e}")
        sys.exit(1)

    vyepay_db = client[VYEPAY_DB]
    users_col = vyepay_db["users"]

    users_without_secret = list(users_col.find(
        {"internalApiSecret": {"$exists": False}, "apiKey": {"$exists": True}},
        {"_id": 1, "email": 1, "apiKey": 1}
    ))

    print(f"[INFO] {len(users_without_secret)} usuarios VyePay sem internalApiSecret\n")

    user_secrets = {}
    for user in users_without_secret:
        secret = str(uuid.uuid4())
        users_col.update_one(
            {"_id": user["_id"]},
            {"$set": {"internalApiSecret": secret}}
        )
        user_secrets[user.get("apiKey")] = secret
        print(f"  [NEW] {user.get('email', '?')} -> {secret[:8]}...")

    all_users = list(users_col.find(
        {"apiKey": {"$exists": True}, "internalApiSecret": {"$exists": True}},
        {"_id": 1, "apiKey": 1, "internalApiSecret": 1}
    ))
    for u in all_users:
        if u.get("apiKey") not in user_secrets:
            user_secrets[u["apiKey"]] = u["internalApiSecret"]

    print(f"\n[INFO] Total de {len(user_secrets)} usuarios com apiKey + secret mapeados")

    print("\n[2/3] Atualizando bots com internal_secret por api_key...\n")

    all_dbs = client.list_database_names()
    bot_dbs = [db for db in all_dbs if db not in SKIP_DBS]

    updated_bots = 0
    skipped_bots = 0

    for db_name in bot_dbs:
        db = client[db_name]
        collections = db.list_collection_names()
        if "data" not in collections:
            continue

        collection = db["data"]
        doc = collection.find_one({"_id": "payment_configs"})
        if not doc:
            continue

        vyepay = doc.get("vyepay", {})
        if not isinstance(vyepay, dict):
            continue

        api_key = vyepay.get("api_key")
        if not api_key:
            skipped_bots += 1
            continue

        secret = user_secrets.get(api_key)
        if not secret:
            print(f"  [WARN] {db_name} — api_key nao encontrada em nenhum usuario VyePay")
            skipped_bots += 1
            continue

        current = vyepay.get("internal_secret")
        if current == secret:
            print(f"  [OK]   {db_name} — ja correto")
            continue

        collection.update_one(
            {"_id": "payment_configs"},
            {"$set": {"vyepay.internal_secret": secret}}
        )
        print(f"  [UPD]  {db_name} — secret atualizado ({secret[:8]}...)")
        updated_bots += 1

    print(f"\n[3/3] Resultado:")
    print(f"  Usuarios gerados:  {len(users_without_secret)}")
    print(f"  Bots atualizados:  {updated_bots}")
    print(f"  Bots ignorados:    {skipped_bots}")

    client.close()
    print("\n[DONE] Migracao completa.")

if __name__ == "__main__":
    main()
