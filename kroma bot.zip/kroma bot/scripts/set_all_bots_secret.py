import dns.resolver
import pymongo
import sys

dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
dns.resolver.default_resolver.nameservers = ["8.8.8.8", "8.8.4.4"]

MONGO_URL = "mongodb+srv://luqi:4kz3BclT9i9X0vPV@cluster0.23zupby.mongodb.net/"
COLLECTION_NAME = "data"
INTERNAL_SECRET = "vye-internal-secret-change-me"

SKIP_DBS = {"admin", "local", "config"}

def main():
    print("[DNS] Forcando resolucao via Google DNS (8.8.8.8 / 8.8.4.4)")
    print("[DB] Conectando ao MongoDB Atlas...\n")

    client = pymongo.MongoClient(MONGO_URL, serverSelectionTimeoutMS=10000)

    try:
        client.admin.command("ping")
        print("[DB] Conexao OK!\n")
    except Exception as e:
        print(f"[DB] Falha na conexao: {e}")
        sys.exit(1)

    all_dbs = client.list_database_names()
    bot_dbs = [db for db in all_dbs if db not in SKIP_DBS]

    print(f"[INFO] Databases encontradas: {len(bot_dbs)}")
    for db_name in bot_dbs:
        print(f"  - {db_name}")
    print()

    updated = 0
    created = 0
    skipped = 0

    for db_name in bot_dbs:
        db = client[db_name]
        collections = db.list_collection_names()

        if COLLECTION_NAME not in collections:
            print(f"[SKIP] {db_name} — sem collection '{COLLECTION_NAME}'")
            skipped += 1
            continue

        collection = db[COLLECTION_NAME]
        doc = collection.find_one({"_id": "payment_configs"})

        if not doc:
            print(f"[SKIP] {db_name} — sem 'payment_configs'")
            skipped += 1
            continue

        vyepay = doc.get("vyepay", {})
        if not vyepay.get("enabled") and not vyepay.get("api_key"):
            print(f"[SKIP] {db_name} — vyepay nao configurado")
            skipped += 1
            continue

        current_secret = vyepay.get("internal_secret")
        if current_secret == INTERNAL_SECRET:
            print(f"[OK]   {db_name} — ja atualizado")
            continue

        collection.update_one(
            {"_id": "payment_configs"},
            {"$set": {"vyepay.internal_secret": INTERNAL_SECRET}}
        )

        if current_secret:
            print(f"[UPD]  {db_name} — secret atualizado")
            updated += 1
        else:
            print(f"[NEW]  {db_name} — secret inserido")
            created += 1

    print(f"\n{'='*50}")
    print(f"[RESULTADO]")
    print(f"  Atualizados: {updated}")
    print(f"  Criados:     {created}")
    print(f"  Ignorados:   {skipped}")
    print(f"  Total DBs:   {len(bot_dbs)}")
    print(f"{'='*50}")

    client.close()
    print("\n[DONE] Todos os bots processados.")

if __name__ == "__main__":
    main()
