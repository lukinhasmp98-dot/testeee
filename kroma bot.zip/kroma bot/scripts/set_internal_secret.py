import dns.resolver
import pymongo
import sys

dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
dns.resolver.default_resolver.nameservers = ["8.8.8.8", "8.8.4.4"]

MONGO_URL = "mongodb+srv://luqi:4kz3BclT9i9X0vPV@cluster0.23zupby.mongodb.net/"
DATABASE_NAME = "vye-bot"
COLLECTION_NAME = "data"
INTERNAL_SECRET = "vye-internal-secret-change-me"

def main():
    print("[DNS] Forçando resolução via Google DNS (8.8.8.8 / 8.8.4.4)")
    print(f"[DB] Conectando ao MongoDB: {DATABASE_NAME}...")

    client = pymongo.MongoClient(MONGO_URL, serverSelectionTimeoutMS=10000)

    try:
        client.admin.command("ping")
        print("[DB] Conexão OK!")
    except Exception as e:
        print(f"[DB] Falha na conexão: {e}")
        sys.exit(1)

    db = client[DATABASE_NAME]
    collection = db[COLLECTION_NAME]

    doc = collection.find_one({"_id": "payment_configs"})

    if not doc:
        print("[WARN] Documento 'payment_configs' não encontrado. Criando...")
        collection.insert_one({
            "_id": "payment_configs",
            "vyepay": {
                "enabled": True,
                "internal_secret": INTERNAL_SECRET,
            }
        })
        print(f"[OK] Documento criado com internal_secret = {INTERNAL_SECRET}")
    else:
        vyepay = doc.get("vyepay", {})
        if vyepay.get("internal_secret") == INTERNAL_SECRET:
            print(f"[OK] internal_secret já está configurado: {INTERNAL_SECRET}")
        else:
            collection.update_one(
                {"_id": "payment_configs"},
                {"$set": {"vyepay.internal_secret": INTERNAL_SECRET}}
            )
            print(f"[OK] internal_secret atualizado para: {INTERNAL_SECRET}")

        print(f"\n[INFO] Estado atual do vyepay config:")
        updated = collection.find_one({"_id": "payment_configs"})
        vyepay_updated = updated.get("vyepay", {})
        for k, v in vyepay_updated.items():
            display = v if k != "api_key" else v[:10] + "..." if v else "N/A"
            print(f"  {k}: {display}")

    client.close()
    print("\n[DONE] Script finalizado.")

if __name__ == "__main__":
    main()
