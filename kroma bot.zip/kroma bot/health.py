"""
Health endpoint HTTP local (aiohttp).
Expõe GET /health com status do bot.
Porta configurável via env HEALTH_PORT (default 8888).
"""
import os
import time
import asyncio

try:
    from aiohttp import web
except Exception:
    web = None

_start_time = time.time()
_runner = None


async def start_health_server(bot):
    global _runner
    if web is None:
        print("[HEALTH] aiohttp indisponível; health endpoint desativado.")
        return

    port = int(os.environ.get("HEALTH_PORT", "8888"))

    async def health_handler(request):
        uptime_s = int(time.time() - _start_time)
        payload = {
            "status": "ok",
            "ready": bool(getattr(bot, "_fully_ready", False)),
            "uptime_s": uptime_s,
        }
        return web.json_response(payload)

    app = web.Application()
    app.router.add_get("/health", health_handler)

    runner = web.AppRunner(app)
    try:
        await runner.setup()
        site = web.TCPSite(runner, host="0.0.0.0", port=port)
        await site.start()
        _runner = runner
        print(f"[HEALTH] Health endpoint ativo em :{port}/health")
    except Exception as e:
        print(f"[HEALTH] Falha ao iniciar health endpoint: {e}")


async def stop_health_server():
    global _runner
    try:
        if _runner is not None:
            await _runner.cleanup()
            _runner = None
    except Exception:
        pass
