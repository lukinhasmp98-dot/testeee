"""
Módulo de integração com ElevenLabs Conversational AI.
Envia texto para o agente e recebe áudio de volta.
Configurações carregadas do banco de dados (ai_config).
"""

import aiohttp
import asyncio
import base64
import os
import subprocess
import tempfile
from typing import Optional, Tuple, NamedTuple
import websockets
import json
from functions.database import Database


class AgentResponse(NamedTuple):
    audio: bytes
    duration: float
    transcript: str
    should_close: bool = False
    text_only: bool = False


def _get_config():
    config = Database.get_document("ai_config") or {}
    return {
        "enabled": config.get("enabled", False),
        "api_key": config.get("api_key", ""),
        "agent_id": config.get("agent_id", ""),
        "voice_id": config.get("voice_id", ""),
        "prompt": config.get("prompt", ""),
    }


async def chat_with_agent(
    user_message: str,
    prompt_override: str = None,
    conversation_history: list = None,
    dynamic_variables: dict = None,
    timeout: float = 60.0
) -> Optional[AgentResponse]:
    """
    Envia texto para o agente e recebe áudio de volta.

    Args:
        user_message: Mensagem do usuário
        prompt_override: Prompt customizado que sobrescreve o da dashboard ElevenLabs
        conversation_history: Lista de dicts [{"role": "user"|"assistant", "content": "..."}]
                             para injetar contexto de conversas anteriores no prompt
        dynamic_variables: Dicionário de variáveis dinâmicas injetadas na sessão.
                          São acessíveis no prompt do agente via {{nome_variavel}}.
                          Ex: {"user_name": "João", "ticket_id": "12345"}
        timeout: Tempo máximo de espera

    Returns:
        AgentResponse(audio, duration, transcript) ou None se falhou
    """
    config = _get_config()
    if not config["enabled"]:
        return None
    if not config["api_key"] or not config["agent_id"]:
        return None

    ws_url = f"wss://api.elevenlabs.io/v1/convai/conversation?agent_id={config['agent_id']}"

    audio_chunks = []
    transcript_parts = []
    should_close = False
    text_only = False

    try:
        async with websockets.connect(
            ws_url,
            additional_headers={"xi-api-key": config["api_key"]}
        ) as ws:


            agent_override = {
                "first_message": None
            }


            effective_prompt = prompt_override or config.get("prompt", "")
            if effective_prompt or conversation_history:
                final_prompt = effective_prompt or ""


                if conversation_history:
                    history_text = "\n\n--- HISTÓRICO DA CONVERSA ATUAL ---\n"
                    for msg in conversation_history[-20:]:
                        role = "Usuário" if msg.get("role") == "user" else "Assistente"
                        history_text += f"{role}: {msg.get('content', '')}\n"
                    history_text += "--- FIM DO HISTÓRICO ---\n\nContinue a conversa naturalmente, levando em conta o contexto acima."
                    final_prompt = f"{final_prompt}\n{history_text}" if final_prompt else history_text

                if final_prompt.strip():
                    agent_override["prompt"] = {
                        "prompt": final_prompt
                    }


            override = {"agent": agent_override}
            if config.get("voice_id"):
                override["tts"] = {"voice_id": config["voice_id"]}

            init_message = {
                "type": "conversation_initiation_client_data",
                "conversation_config_override": override
            }


            if dynamic_variables:
                init_message["dynamic_variables"] = dynamic_variables

            await ws.send(json.dumps(init_message))


            try:
                response = await asyncio.wait_for(ws.recv(), timeout=10)
                data = json.loads(response)
            except asyncio.TimeoutError:
                return None


            user_msg = {
                "type": "user_message",
                "text": user_message
            }
            await ws.send(json.dumps(user_msg))


            start_time = asyncio.get_event_loop().time()
            last_audio_time = None

            while True:
                elapsed = asyncio.get_event_loop().time() - start_time
                if elapsed > timeout:
                    break


                if last_audio_time:
                    time_since_audio = asyncio.get_event_loop().time() - last_audio_time
                    if time_since_audio > 3.0:
                        break
                    wait_time = 3.0
                else:
                    wait_time = 20.0

                try:
                    response = await asyncio.wait_for(ws.recv(), timeout=wait_time)
                    data = json.loads(response)
                    msg_type = data.get("type", "")

                    if msg_type == "audio":
                        audio_event = data.get("audio_event", {})
                        audio_base64 = audio_event.get("audio_base_64")
                        if audio_base64:
                            audio_bytes = base64.b64decode(audio_base64)
                            audio_chunks.append(audio_bytes)
                            last_audio_time = asyncio.get_event_loop().time()

                    elif msg_type == "agent_response":

                        text = data.get("agent_response_event", {}).get("agent_response", "")
                        if text:
                            transcript_parts.append(text)

                    elif msg_type == "client_tool_call":

                        tool_name = data.get("client_tool_call", {}).get("tool_name", "")
                        tool_call_id = data.get("client_tool_call", {}).get("tool_call_id", "")

                        if tool_name == "fechar_ticket":
                            should_close = True
                        elif tool_name == "responder_por_texto":
                            text_only = True


                        tool_result = {
                            "type": "client_tool_result",
                            "tool_call_id": tool_call_id,
                            "result": "OK",
                            "is_error": False
                        }
                        await ws.send(json.dumps(tool_result))

                    elif msg_type == "ping":
                        ping_event = data.get("ping_event", {})
                        event_id = ping_event.get("event_id", 0)
                        pong = {"type": "pong", "event_id": event_id}
                        await ws.send(json.dumps(pong))

                    elif msg_type == "interruption":
                        if audio_chunks:
                            break

                    elif msg_type == "error":
                        break

                except asyncio.TimeoutError:
                    if audio_chunks:
                        break
                    else:
                        if asyncio.get_event_loop().time() - start_time > 25:
                            return None

    except websockets.exceptions.ConnectionClosed:
        if not audio_chunks and not transcript_parts:
            return None
    except Exception as e:
        print(f"[ELEVENLABS] Erro na conexão WebSocket: {e}")
        return None

    transcript = " ".join(transcript_parts).strip() or "[Resposta em áudio]"


    if text_only and transcript:
        return AgentResponse(audio=b"", duration=0.0, transcript=transcript, should_close=should_close, text_only=True)

    if not audio_chunks:

        if transcript and transcript != "[Resposta em áudio]":
            return AgentResponse(audio=b"", duration=0.0, transcript=transcript, should_close=should_close, text_only=True)
        return None


    full_audio = b"".join(audio_chunks)


    ogg_audio = await convert_audio_to_ogg(full_audio)
    if not ogg_audio:
        return None


    duration = get_audio_duration(ogg_audio)

    return AgentResponse(audio=ogg_audio, duration=duration, transcript=transcript, should_close=should_close, text_only=text_only)


async def convert_audio_to_ogg(audio_bytes: bytes) -> Optional[bytes]:
    try:
        with tempfile.NamedTemporaryFile(suffix=".raw", delete=False) as f:
            f.write(audio_bytes)
            input_path = f.name

        output_path = input_path.replace(".raw", ".ogg")


        ffmpeg_path = "ffmpeg"
        for candidate in [
            r"C:\Users\Administrator\AppData\Local\Microsoft\WinGet\Links\ffmpeg.exe",
            "/usr/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
        ]:
            if os.path.exists(candidate):
                ffmpeg_path = candidate
                break


        process = await asyncio.create_subprocess_exec(
            ffmpeg_path,
            "-f", "s16le",
            "-ar", "48000",
            "-ac", "1",
            "-i", input_path,
            "-c:a", "libopus",
            "-ar", "48000",
            "-b:a", "128k",
            "-y",
            output_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await process.communicate()


        if process.returncode != 0:
            mp3_path = input_path.replace(".raw", ".mp3")
            os.rename(input_path, mp3_path)
            input_path = mp3_path

            process = await asyncio.create_subprocess_exec(
                ffmpeg_path,
                "-i", input_path,
                "-c:a", "libopus",
                "-b:a", "64k",
                "-y",
                output_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()

        if process.returncode != 0:
            os.unlink(input_path)
            return None

        with open(output_path, "rb") as f:
            ogg_bytes = f.read()


        try:
            os.unlink(input_path)
        except Exception:
            pass
        os.unlink(output_path)

        return ogg_bytes

    except Exception as e:
        print(f"[ELEVENLABS] Erro ao converter áudio: {e}")
        return None


def get_audio_duration(audio_bytes: bytes) -> float:
    try:
        with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as f:
            f.write(audio_bytes)
            temp_path = f.name


        ffprobe_path = "ffprobe"
        for candidate in [
            r"C:\Users\Administrator\AppData\Local\Microsoft\WinGet\Links\ffprobe.exe",
            "/usr/bin/ffprobe",
            "/usr/local/bin/ffprobe",
        ]:
            if os.path.exists(candidate):
                ffprobe_path = candidate
                break

        result = subprocess.run([
            ffprobe_path,
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            temp_path
        ], capture_output=True, text=True)

        os.unlink(temp_path)

        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())

        return 5.0

    except Exception:
        return 5.0


async def text_to_speech(text: str) -> Optional[Tuple[bytes, float]]:
    config = _get_config()
    if not config["api_key"] or not config["voice_id"]:
        return None

    url = f"https://api.elevenlabs.io/v1/text-to-speech/{config['voice_id']}"

    headers = {
        "xi-api-key": config["api_key"],
        "Content-Type": "application/json"
    }

    payload = {
        "text": text,
        "model_id": "eleven_multilingual_v2",
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.75
        }
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload, headers=headers) as resp:
            if resp.status != 200:
                return None

            mp3_bytes = await resp.read()

    ogg_bytes = await convert_audio_to_ogg(mp3_bytes)
    if not ogg_bytes:
        return None

    duration = get_audio_duration(ogg_bytes)
    return ogg_bytes, duration
