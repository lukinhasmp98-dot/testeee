import aiohttp
import io
import os
from PIL import Image, ImageDraw, ImageFont, ImageOps
import datetime

class ImageHandler:
    @staticmethod
    async def process_image(url: str, max_size: tuple[int, int] = (400, 240)) -> bytes:
        if not url:
            return None

        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(url) as r:
                    if r.status != 200:
                        return None
                    data = await r.read()

            with Image.open(io.BytesIO(data)) as img:
                img = img.convert("RGBA")
                img.thumbnail(max_size, Image.Resampling.LANCZOS)

                buf = io.BytesIO()
                img.save(buf, format="PNG", optimize=True)
                return buf.getvalue()
        except Exception as e:
            print(f"Erro ao processar imagem ({url}): {e}")
            return None

    @staticmethod
    async def resize_banner(url: str, width: int = None, height: int = None) -> io.BytesIO | None:
        if not url or (not width and not height):
            return None
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(url) as r:
                    if r.status != 200:
                        return None
                    data = await r.read()
            with Image.open(io.BytesIO(data)) as img:
                img = img.convert("RGBA")
                orig_w, orig_h = img.size
                if width and height:
                    img = img.resize((width, height), Image.Resampling.LANCZOS)
                elif width:
                    ratio = width / orig_w
                    img = img.resize((width, int(orig_h * ratio)), Image.Resampling.LANCZOS)
                elif height:
                    ratio = height / orig_h
                    img = img.resize((int(orig_w * ratio), height), Image.Resampling.LANCZOS)
                buf = io.BytesIO()
                img.save(buf, format="PNG", optimize=True)
                buf.seek(0)
                return buf
        except Exception as e:
            print(f"[ResizeBanner] Erro ({url}): {e}")
            return None

    @staticmethod
    async def generate_purchase_image(user_name: str, user_avatar_url: str, items_summary: str, total_price: float, bot_name: str = "Sage", bot_avatar_url: str = None, server_name: str = "SAGE", user_handle: str = None) -> io.BytesIO:

        COLOR_BG = (15, 15, 15)
        COLOR_FOOTER = (25, 25, 25)
        COLOR_GREEN = (46, 204, 113)
        COLOR_WHITE = (255, 255, 255)
        COLOR_GRAY = (140, 145, 150)
        COLOR_BORDER = (40, 40, 40)

        def sanitize(text: str):
            if not text: return ""

            import re
            return re.sub(r'[^\x00-\x7F\xC0-\xFF]', '', text).strip() or "Usuário"

        user_name = sanitize(user_name)
        user_handle = sanitize(user_handle) if user_handle else user_name.lower().replace(' ', '')

        SCALE = 2
        W, H = 360 * SCALE, 220 * SCALE
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle([0, 0, W, H], radius=24*SCALE, fill=COLOR_BG)

        footer_h = 45 * SCALE
        draw.rounded_rectangle([0, H-footer_h, W, H], radius=24*SCALE, fill=COLOR_FOOTER)
        draw.rectangle([0, H-footer_h, W, H-footer_h+(15*SCALE)], fill=COLOR_FOOTER)

        def f(variant, size):
            p = f"assets/fonts/Montserrat-{variant}.ttf"
            return ImageFont.truetype(p, size * SCALE) if os.path.exists(p) else ImageFont.load_default()

        f_name = f("Bold", 12)
        f_handle = f("Regular", 10)
        f_time = f("Regular", 9)
        f_title = f("Bold", 14)
        f_label = f("Regular", 10)
        f_item = f("SemiBold", 11)
        f_price_line = f("Bold", 11)
        f_payment_label = f("Regular", 10)
        f_payment_val = f("Bold", 15)
        f_footer = f("Bold", 9)

        m = 15 * SCALE

        async def paste_avatar(url, pos, size):
            try:

                target_size = size * SCALE
                async with aiohttp.ClientSession() as sess:
                    async with sess.get(url) as r:
                        if r.status == 200:
                            data = await r.read()
                            av = Image.open(io.BytesIO(data)).convert("RGBA").resize((target_size, target_size), Image.LANCZOS)
                            mask = Image.new("L", (target_size, target_size), 0)
                            ImageDraw.Draw(mask).ellipse((0, 0, target_size, target_size), fill=255)
                            img.paste(av, pos, mask)
            except Exception: pass

        await paste_avatar(user_avatar_url, (m, m), 32)

        draw.text((m + (40 * SCALE), m + (2 * SCALE)), user_name, font=f_name, fill=COLOR_WHITE)
        draw.text((m + (40 * SCALE), m + (16 * SCALE)), f"@{user_handle.lower()}", font=f_handle, fill=COLOR_GRAY)

        now_str = datetime.datetime.now().strftime("%d/%m | %H:%M")
        tw = draw.textlength(now_str, font=f_time)
        draw.text((W - m - tw, m + (4 * SCALE)), now_str, font=f_time, fill=COLOR_GRAY)

        draw.ellipse((m, 55*SCALE, m + (14*SCALE), 69*SCALE), fill=COLOR_GREEN)
        draw.line([m+(4*SCALE), 62*SCALE, m+(6*SCALE), 64*SCALE, m+(10*SCALE), 59*SCALE], fill=COLOR_WHITE, width=2*SCALE)
        draw.text((m + (22 * SCALE), 54 * SCALE), "Compra Realizada", font=f_title, fill=COLOR_WHITE)

        draw.text((m, 78 * SCALE), "Carrinho", font=f_label, fill=COLOR_GRAY)

        iy = 92 * SCALE
        raw_items = items_summary.split("\n")[0].replace("• ", "").split(" - ")
        item_disp = raw_items[0]
        draw.text((m, iy + (4 * SCALE)), f"1x {item_disp}", font=f_item, fill=COLOR_WHITE)

        price_brl = f"R$ {total_price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        pw = draw.textlength(price_brl, font=f_price_line)
        draw.text((W - m - pw, iy + (4 * SCALE)), price_brl, font=f_price_line, fill=COLOR_WHITE)

        draw.line([m, 130 * SCALE, W - m, 130 * SCALE], fill=COLOR_BORDER, width=1*SCALE)

        draw.text((m, 147 * SCALE), "Valor pago", font=f_payment_label, fill=COLOR_WHITE)
        vw = draw.textlength(price_brl, font=f_payment_val)
        draw.text((W - m - vw, 140 * SCALE), price_brl, font=f_payment_val, fill=COLOR_GREEN)

        fy = H - (32 * SCALE)
        if bot_avatar_url:
            await paste_avatar(bot_avatar_url, (m, fy), 16)
        else:
            draw.rounded_rectangle([m, fy, m + (16 * SCALE), fy + (16 * SCALE)], radius=3*SCALE, fill=COLOR_GREEN)

        bot_txt = bot_name.upper()
        draw.text((m + (22 * SCALE), fy + (2 * SCALE)), bot_txt, font=f_footer, fill=COLOR_WHITE)

        server_txt = f"{server_name.upper()}"
        sw = draw.textlength(server_txt, font=f_footer)
        draw.text((W - m - sw, fy + (2 * SCALE)), server_txt, font=f_footer, fill=COLOR_WHITE)

        img = img.resize((300, 180), Image.Resampling.LANCZOS)
        img = ImageOps.expand(img, border=5, fill=(0,0,0,0))

        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf
