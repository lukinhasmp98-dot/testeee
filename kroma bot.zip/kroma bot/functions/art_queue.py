"""Fila pública de produção, alimentada somente por PIX confirmado manualmente.

Uma entrada passa por ``fila`` -> ``em_producao`` -> ``entregue``. Somente os
dois primeiros estados aparecem no painel público; o histórico continua salvo
para que a entrega e o portfólio possam ser auditados.
"""
import time
import disnake
from functions.database import Database

FLAGS = disnake.MessageFlags(is_components_v2=True)

def _data():
    data = Database.get_document("kroma_art_queue") or {}
    data.setdefault("entries", [])
    return data

def _components(data):
    active = [entry for entry in data["entries"] if entry.get("status") in {"fila", "em_producao"}]
    lines = []
    for position, entry in enumerate(active, 1):
        state = "EM PRODUÇÃO" if entry.get("status") == "em_producao" else "NA FILA"
        lines.append(f"`{position:02}` · <@{entry['customer_id']}> · **{entry['service']}** · `{state}`")
    title = data.get("title") or "FILA DE ARTES / KROMA STUDIO"
    intro = data.get("intro") or "Pedidos entram somente após a confirmação manual do PIX."
    text = f"# {title}\n-# {intro}\n\n" + ("\n".join(lines) if lines else "Nenhum pedido aguardando produção no momento.")
    children = []
    banner = data.get("banner_url")
    banner_component = disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=banner)) if banner else None
    if banner_component and data.get("banner_position", "top") == "top": children.append(banner_component)
    thumbnail = data.get("thumbnail_url")
    if thumbnail:
        children.append(disnake.ui.Section(disnake.ui.TextDisplay(text), accessory=disnake.ui.Thumbnail(media=thumbnail)))
    else:
        children.append(disnake.ui.TextDisplay(text))
    if banner_component and data.get("banner_position", "top") == "bottom": children.append(banner_component)
    return [disnake.ui.Container(*children, accent_colour=disnake.Colour(0x43DBD0))]

async def sync(bot):
    data = _data(); channel_id = data.get("channel_id")
    if not channel_id: return False
    channel = bot.get_channel(int(channel_id))
    if not isinstance(channel, disnake.TextChannel): return False
    components = _components(data); message = None
    if data.get("message_id"):
        try: message = await channel.fetch_message(int(data["message_id"]))
        except (disnake.NotFound, disnake.HTTPException): message = None
    if message:
        await message.edit(components=components, flags=FLAGS)
    else:
        message = await channel.send(components=components, flags=FLAGS)
        data["message_id"] = str(message.id)
    Database.save_document("kroma_art_queue", data)
    return True

async def add_confirmed_payment(bot, payment):
    if not payment.get("ticket_id"): return False
    data = _data()
    if any(entry.get("payment_id") == payment.get("id") for entry in data["entries"]): return False
    data["entries"].append({"payment_id": payment["id"], "ticket_id": payment["ticket_id"], "customer_id": payment["user_id"], "service": payment.get("description") or "Arte personalizada", "status": "fila", "confirmed_at": payment.get("approved_at") or time.time()})
    Database.save_document("kroma_art_queue", data)
    await sync(bot)
    return True


def get_entry_for_ticket(ticket_id: int):
    """Obtém a entrada mais recente de um ticket, inclusive uma já entregue."""
    data = _data()
    return next((entry for entry in reversed(data["entries"])
                 if str(entry.get("ticket_id")) == str(ticket_id)), None)


async def set_status(bot, ticket_id: int, status: str, *, staff_id: int | None = None,
                     delivery_url: str | None = None):
    """Atualiza o estado de uma arte e sincroniza o painel público."""
    if status not in {"fila", "em_producao", "entregue"}:
        raise ValueError("Estado de fila inválido")
    data = _data()
    entry = next((item for item in reversed(data["entries"])
                  if str(item.get("ticket_id")) == str(ticket_id)), None)
    if not entry:
        return None
    entry["status"] = status
    entry["updated_at"] = time.time()
    if staff_id:
        entry["updated_by"] = staff_id
    if status == "em_producao":
        entry["production_started_at"] = entry["updated_at"]
    elif status == "entregue":
        entry["delivered_at"] = entry["updated_at"]
        if delivery_url:
            entry["delivery_url"] = delivery_url
    Database.save_document("kroma_art_queue", data)
    await sync(bot)
    return entry

async def remove_ticket(bot, ticket_id: int):
    """Remove a entrada ativa quando o atendimento correspondente é fechado."""
    data = _data()
    before = len(data["entries"])
    data["entries"] = [entry for entry in data["entries"] if str(entry.get("ticket_id")) != str(ticket_id)]
    if len(data["entries"]) == before:
        return False
    Database.save_document("kroma_art_queue", data)
    await sync(bot)
    return True
