import disnake
import aiohttp
import io
from functions.database import Database

_bot_instance = None

def set_bot(bot):
    global _bot_instance
    _bot_instance = bot

def get_storage_channel_id() -> int:
    config = Database.get_document("bot_config") or {}
    return config.get("cdn_storage_channel_id")

async def upload_file(file_data: bytes, filename: str, content_type: str = None) -> dict:
    """
    Faz upload de um arquivo para o Discord CDN.

    Args:
        file_data: Bytes do arquivo
        filename: Nome original do arquivo
        content_type: Tipo MIME do arquivo (opcional, não usado)

    Returns:
        dict com 'success', 'url' e 'error' (se houver)
    """
    global _bot_instance

    if not _bot_instance:
        return {"success": False, "url": None, "error": "Bot não inicializado"}

    channel_id = get_storage_channel_id()
    if not channel_id:
        return {"success": False, "url": None, "error": "Canal de storage não configurado. Configure em /config"}

    try:
        channel = _bot_instance.get_channel(int(channel_id))
        if not channel:
            return {"success": False, "url": None, "error": "Canal de storage não encontrado"}

        file = disnake.File(io.BytesIO(file_data), filename=filename)
        msg = await channel.send(file=file)

        if msg.attachments:
            return {
                "success": True,
                "url": msg.attachments[0].url,
                "id": str(msg.id),
                "size": len(file_data)
            }
        else:
            return {"success": False, "url": None, "error": "Falha ao obter URL do attachment"}

    except Exception as e:
        return {"success": False, "url": None, "error": str(e)}

async def upload_from_url(url: str, filename: str = None) -> dict:
    """
    Baixa um arquivo de uma URL e faz upload para o CDN.

    Args:
        url: URL do arquivo para baixar
        filename: Nome do arquivo (opcional, extrai da URL)

    Returns:
        dict com 'success', 'url' e 'error' (se houver)
    """
    if not filename:
        filename = url.split("/")[-1].split("?")[0]

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status != 200:
                    return {"success": False, "url": None, "error": f"Falha ao baixar: HTTP {response.status}"}

                content_type = response.headers.get("Content-Type", "application/octet-stream")
                file_data = await response.read()

                return await upload_file(file_data, filename, content_type)
    except Exception as e:
        return {"success": False, "url": None, "error": str(e)}

async def upload_discord_attachment(attachment) -> dict:
    """
    Faz upload de um attachment do Discord para o CDN.

    Args:
        attachment: disnake.Attachment object

    Returns:
        dict com 'success', 'url' e 'error' (se houver)
    """
    try:
        file_data = await attachment.read()
        return await upload_file(file_data, attachment.filename, attachment.content_type)
    except Exception as e:
        return {"success": False, "url": None, "error": str(e)}
