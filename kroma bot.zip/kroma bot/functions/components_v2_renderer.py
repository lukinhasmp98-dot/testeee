"""
Renderer de Components V2 Discord a partir de schema JSON vindo do dashboard.

Schema suportado (compatível com webhook builder):
- type 1: ActionRow { components: [Button|StringSelect] }
- type 2: Button { label, style (1-5), custom_id?, url?, emoji?, disabled? }
- type 3: StringSelect { custom_id, placeholder?, options: [{label,value,description?,emoji?}], min_values?, max_values? }
- type 9: Section { components: [TextDisplay], accessory: Thumbnail | Button }
- type 10: TextDisplay { content }
- type 11: Thumbnail { media: {url}, width?, height? }
- type 12: MediaGallery { items: [{media:{url}}], width?, height? }
- type 14: Separator { divider?, spacing? }
- type 17: Container { accent_color?, components: [...inner] }

Placeholders no formato {key} são substituídos usando o dict `placeholders`.
Componentes interativos com custom_id ganham prefixo do contexto (ex: "VipPanel:").
"""

from __future__ import annotations

import re
import logging
from typing import Any, Iterable

import disnake

logger = logging.getLogger(__name__)


_EMOJI_CUSTOM_RE = re.compile(r"<(a?):(\w+):(\d+)>")
_PLACEHOLDER_RE = re.compile(r"\{([a-zA-Z0-9_\.]+)\}")


def _substitute(raw: str | None, placeholders: dict[str, str]) -> str:
    if not raw:
        return raw or ""
    return _PLACEHOLDER_RE.sub(
        lambda m: str(placeholders.get(m.group(1), m.group(0))), raw
    )


def _parse_emoji(raw: str | None):
    if not raw:
        return None
    raw = raw.strip()
    if not raw:
        return None
    m = _EMOJI_CUSTOM_RE.match(raw)
    if not m:
        return raw
    try:
        return disnake.PartialEmoji(
            name=m.group(2),
            id=int(m.group(3)),
            animated=m.group(1) == "a",
        )
    except Exception:
        return None


def _build_button(data: dict, placeholders: dict[str, str]):
    """Constrói um disnake.ui.Button a partir do schema. Retorna None em caso
    de erro (em vez de propagar) — o caller decide se ignora ou usa fallback."""
    try:
        style_raw = data.get("style", 2)
        try:
            style = disnake.ButtonStyle(int(style_raw))
        except Exception:
            style = disnake.ButtonStyle.secondary

        label = _substitute(data.get("label", ""), placeholders)
        emoji = _parse_emoji(data.get("emoji"))
        disabled = bool(data.get("disabled"))

        # Discord: button precisa de label OU emoji. Se não tiver nenhum,
        # gera um label padrão pra evitar HTTPException.
        if not label and emoji is None:
            label = "Botão"

        kwargs: dict[str, Any] = {"style": style, "disabled": disabled}
        if label:
            kwargs["label"] = label[:80]
        if emoji is not None:
            kwargs["emoji"] = emoji

        if style == disnake.ButtonStyle.link:
            url = _substitute(data.get("url", ""), placeholders).strip()
            # URL precisa ser http(s); senão, vira link genérico
            if not url or not (url.startswith("http://") or url.startswith("https://")):
                url = "https://discord.com"
            kwargs["url"] = url
        else:
            cid_raw = data.get("custom_id") or f"CustomBuilder_{hash(label or 'btn') & 0xFFFFFFFF:x}"
            kwargs["custom_id"] = str(cid_raw)[:100]

        return disnake.ui.Button(**kwargs)
    except Exception as e:
        logger.warning(f"[components_v2] _build_button falhou: {e!r} — data={data!r}")
        return None


def _build_select_options(options: list, placeholders: dict[str, str]) -> list[disnake.SelectOption]:
    result: list[disnake.SelectOption] = []
    for opt in options[:25]:
        if not isinstance(opt, dict):
            continue
        label = _substitute(opt.get("label", ""), placeholders)[:100]
        value = str(opt.get("value", label))[:100]
        description_raw = opt.get("description")
        description = _substitute(description_raw, placeholders)[:100] if description_raw else None
        emoji = _parse_emoji(opt.get("emoji"))
        try:
            kwargs: dict[str, Any] = {"label": label or "—", "value": value}
            if description:
                kwargs["description"] = description
            if emoji is not None:
                kwargs["emoji"] = emoji
            result.append(disnake.SelectOption(**kwargs))
        except Exception:
            continue
    return result


def _build_string_select(data: dict, placeholders: dict[str, str]):
    options = _build_select_options(data.get("options", []), placeholders)
    if not options:
        return None
    custom_id = str(data.get("custom_id") or f"CustomBuilder_Select_{id(data):x}")[:100]
    placeholder = _substitute(data.get("placeholder"), placeholders)[:150] if data.get("placeholder") else None
    min_values = max(0, min(25, int(data.get("min_values", 1))))
    max_values = max(1, min(25, int(data.get("max_values", 1))))
    return disnake.ui.StringSelect(
        custom_id=custom_id,
        placeholder=placeholder,
        options=options,
        min_values=min_values,
        max_values=max_values,
    )


def _build_action_row(data: dict, placeholders: dict[str, str]):
    items: list = []
    for child in (data.get("components") or [])[:5]:
        if not isinstance(child, dict):
            continue
        t = child.get("type")
        if t == 2:
            btn = _build_button(child, placeholders)
            if btn is not None:
                items.append(btn)
        elif t == 3:
            sel = _build_string_select(child, placeholders)
            if sel is not None:
                items.append(sel)
    if not items:
        return None
    try:
        return disnake.ui.ActionRow(*items)
    except Exception as e:
        logger.warning(f"[components_v2] _build_action_row falhou: {e!r}")
        return None


def _build_text_display(data: dict, placeholders: dict[str, str]):
    content = _substitute(data.get("content", ""), placeholders)
    if not content.strip():
        return None
    return disnake.ui.TextDisplay(content[:4000])


def _build_separator(data: dict):
    try:
        kwargs: dict[str, Any] = {}
        if "divider" in data:
            kwargs["divider"] = bool(data["divider"])
        spacing = data.get("spacing")
        if spacing in (1, 2):
            kwargs["spacing"] = disnake.SeparatorSpacingSize(spacing)
        return disnake.ui.Separator(**kwargs)
    except Exception:
        return disnake.ui.Separator()


def _build_thumbnail(data: dict, placeholders: dict[str, str]):
    media = data.get("media") or {}
    url = _substitute(media.get("url"), placeholders)
    if not url:
        return None
    try:
        return disnake.ui.Thumbnail(media=url)
    except Exception:
        return None


def _build_media_gallery(data: dict, placeholders: dict[str, str]):
    raw_items = data.get("items") or []
    items: list[disnake.MediaGalleryItem] = []
    for it in raw_items[:10]:
        if not isinstance(it, dict):
            continue
        media = it.get("media") or {}
        url = _substitute(media.get("url"), placeholders)
        if not url:
            continue
        try:
            items.append(disnake.MediaGalleryItem(media=url))
        except Exception:
            continue
    if not items:
        return None
    try:
        return disnake.ui.MediaGallery(*items)
    except Exception:
        return None


def _build_section(data: dict, placeholders: dict[str, str]):
    """Section = lista de TextDisplays + accessory (Button OU Thumbnail).
    Discord exige pelo menos 1 text e exatamente 1 accessory."""
    texts = []
    for tx in (data.get("components") or [])[:3]:
        if isinstance(tx, dict) and tx.get("type") == 10:
            td = _build_text_display(tx, placeholders)
            if td is not None:
                texts.append(td)
    if not texts:
        logger.warning("[components_v2] _build_section: sem TextDisplay valido")
        return None

    acc_raw = data.get("accessory")
    if not isinstance(acc_raw, dict):
        logger.warning(f"[components_v2] _build_section: accessory invalido: {acc_raw!r}")
        return None

    accessory = None
    acc_type = acc_raw.get("type")
    if acc_type == 11:
        accessory = _build_thumbnail(acc_raw, placeholders)
    elif acc_type == 2:
        accessory = _build_button(acc_raw, placeholders)
    else:
        logger.warning(f"[components_v2] _build_section: accessory type {acc_type} nao suportado")

    if accessory is None:
        logger.warning(f"[components_v2] _build_section: accessory falhou — acc_raw={acc_raw!r}")
        return None

    try:
        return disnake.ui.Section(*texts, accessory=accessory)
    except Exception as e:
        logger.error(f"[components_v2] _build_section: disnake.Section falhou: {e!r} — texts={len(texts)}, accessory_type={type(accessory).__name__}")
        return None


def _build_inner(item: dict, placeholders: dict[str, str]):
    t = item.get("type")
    if t == 10:
        return _build_text_display(item, placeholders)
    if t == 14:
        return _build_separator(item)
    if t == 12:
        return _build_media_gallery(item, placeholders)
    if t == 9:
        return _build_section(item, placeholders)
    if t == 1:
        return _build_action_row(item, placeholders)
    return None


def _build_container(data: dict, placeholders: dict[str, str]):
    inner: list = []
    for child in (data.get("components") or [])[:25]:
        if not isinstance(child, dict):
            continue
        built = _build_inner(child, placeholders)
        if built is not None:
            inner.append(built)
    if not inner:
        return None
    kwargs: dict[str, Any] = {}
    accent = data.get("accent_color")
    if isinstance(accent, int):
        try:
            kwargs["accent_colour"] = disnake.Colour(accent)
        except Exception:
            pass
    try:
        return disnake.ui.Container(*inner, **kwargs)
    except TypeError:
        return disnake.ui.Container(*inner)


def _is_empty_section(item: dict) -> bool:
    """Section sem TextDisplay valido (vai falhar no Discord se tentar render)."""
    if not isinstance(item, dict) or item.get("type") != 9:
        return False
    comps = item.get("components") or []
    if not isinstance(comps, list) or len(comps) == 0:
        return True
    for c in comps:
        if isinstance(c, dict) and c.get("type") == 10:
            content = (c.get("content") or "").strip()
            if content:
                return False
    return True


def _merge_text_into_empty_sections(items: list) -> list:
    """Junta TextDisplay com Section vazia adjacente (mesmo merge da UI).

    Frontend renderiza preview mergeado (texto + botão side-by-side) mas salva
    separado no schema. Aqui re-fazemos o merge antes de renderizar pra que o
    accessory (Button/Thumbnail) seja incluso na mesma Section que o texto.
    Sem isso, Section vazia é dropada (Discord exige >= 1 TextDisplay).
    """
    if not items:
        return items
    out: list = []
    i = 0
    while i < len(items):
        cur = items[i]
        nxt = items[i + 1] if i + 1 < len(items) else None

        # text + empty section → injeta texto na section
        if isinstance(cur, dict) and cur.get("type") == 10 and _is_empty_section(nxt or {}):
            merged = dict(nxt)
            merged["components"] = [cur]
            out.append(merged)
            i += 2
            continue

        # empty section + text → injeta texto na section
        if _is_empty_section(cur) and isinstance(nxt, dict) and nxt.get("type") == 10:
            merged = dict(cur)
            merged["components"] = [nxt]
            out.append(merged)
            i += 2
            continue

        out.append(cur)
        i += 1
    return out


def render_components_v2(schema: Iterable[dict] | None, placeholders: dict[str, str] | None = None) -> list:
    """Converte schema JSON em lista de objetos disnake UI (top-level).

    Retorna lista vazia se schema for inválido ou vazio. Ignora componentes
    que falharem ao ser construídos (resiliente).
    """
    placeholders = placeholders or {}
    if not schema:
        return []
    items = list(schema)[:25]
    items = _merge_text_into_empty_sections(items)
    # Pra Containers (type 17), faz o mesmo merge nos children deles
    for it in items:
        if isinstance(it, dict) and it.get("type") == 17 and isinstance(it.get("components"), list):
            it["components"] = _merge_text_into_empty_sections(it["components"])
    out: list = []
    for item in items:
        if not isinstance(item, dict):
            continue
        t = item.get("type")
        built = None
        if t == 17:
            built = _build_container(item, placeholders)
        else:
            built = _build_inner(item, placeholders)
        if built is not None:
            out.append(built)
    return out
