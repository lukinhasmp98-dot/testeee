"""Persistência do Kroma Studio.

Sem ``MONGODB_URI`` o bot mantém o modo local para desenvolvimento. Em produção
use ``MONGODB_URI``: todos os documentos, inclusive a configuração do PIX,
ficam no MongoDB e sobrevivem a reinícios/redeploys do host.
"""
import asyncio
import copy
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DOCS_FILE = DATA_DIR / "documents.json"
CONFIG_FILE = ROOT / "config.json"


class Database:
    _cache: dict[str, Any] = {}
    _config_cache: dict[str, Any] = {}
    _loaded = False
    _lock = asyncio.Lock()
    _mongo_db = None

    @classmethod
    def _using_mongo(cls) -> bool:
        return cls._mongo_db is not None

    @classmethod
    def _read_json(cls, path: Path, default):
        try:
            return json.loads(path.read_text(encoding="utf-8")) if path.exists() else copy.deepcopy(default)
        except (OSError, json.JSONDecodeError):
            return copy.deepcopy(default)

    @classmethod
    def _atomic_write(cls, path: Path, data: Any):
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, path)

    @classmethod
    async def load_all(cls):
        mongo_uri = os.getenv("MONGODB_URI", "").strip()
        if mongo_uri:
            try:
                from pymongo import MongoClient
                client = MongoClient(mongo_uri, serverSelectionTimeoutMS=8000)
                client.admin.command("ping")
                cls._mongo_db = client[os.getenv("MONGODB_DATABASE", "kroma_studio").strip() or "kroma_studio"]
                cls._cache = {row["_id"]: row.get("data", {}) for row in cls._mongo_db.documents.find({})}
                config = cls._mongo_db.config.find_one({"_id": "app_config"})
                cls._config_cache = (config or {}).get("data", {})
                cls._loaded = True
                print(f"[DATABASE] MongoDB conectado: {len(cls._cache)} documento(s).")
                return
            except Exception as exc:
                # Em produção falhar em silêncio faria o bot trocar para um
                # JSON efêmero e perder pedidos. A falha precisa ser explícita.
                raise RuntimeError(f"Não foi possível conectar ao MongoDB: {exc}") from exc
        cls._cache = cls._read_json(DOCS_FILE, {})
        cls._config_cache = cls._read_json(CONFIG_FILE, {})
        cls._loaded = True
        print(f"[DATABASE] Banco local carregado: {len(cls._cache)} documento(s).")

    @classmethod
    def get_config(cls, key: str | None = None):
        if not cls._config_cache and not cls._using_mongo():
            cls._config_cache = cls._read_json(CONFIG_FILE, {})
        return cls._config_cache.get(key) if key else cls._config_cache

    @classmethod
    def save_config(cls, data: dict):
        cls._config_cache = copy.deepcopy(data)
        if cls._using_mongo():
            cls._mongo_db.config.replace_one({"_id": "app_config"}, {"_id": "app_config", "data": cls._config_cache}, upsert=True)
            return True
        cls._atomic_write(CONFIG_FILE, cls._config_cache)
        return True

    @classmethod
    def get_document(cls, doc_id: str):
        return copy.deepcopy(cls._cache.get(doc_id, {}))

    @classmethod
    def get_document_ref(cls, doc_id: str):
        return cls._cache.get(doc_id, {})

    @classmethod
    async def _persist(cls):
        async with cls._lock:
            cls._atomic_write(DOCS_FILE, cls._cache)

    @classmethod
    def _schedule_persist(cls):
        if cls._using_mongo():
            return
        try:
            asyncio.get_running_loop().create_task(cls._persist())
        except RuntimeError:
            cls._atomic_write(DOCS_FILE, cls._cache)

    @classmethod
    def save_document(cls, doc_id: str, data: Any):
        cls._cache[doc_id] = copy.deepcopy(data)
        if cls._using_mongo():
            cls._mongo_db.documents.replace_one({"_id": doc_id}, {"_id": doc_id, "data": cls._cache[doc_id]}, upsert=True)
            return
        cls._schedule_persist()

    @classmethod
    async def save_document_await(cls, doc_id: str, data: Any):
        cls.save_document(doc_id, data)
        if not cls._using_mongo():
            await cls._persist()

    @classmethod
    def delete_document(cls, doc_id: str):
        cls._cache.pop(doc_id, None)
        if cls._using_mongo():
            cls._mongo_db.documents.delete_one({"_id": doc_id})
            return
        cls._schedule_persist()

    @classmethod
    async def refresh_document(cls, doc_id: str, *, force: bool = False):
        return cls.get_document(doc_id)

    @classmethod
    async def unset_nested_fields(cls, doc_id: str, paths: list[str]):
        data = cls._cache.get(doc_id, {})
        for path in paths:
            target = data
            bits = path.split(".")
            for part in bits[:-1]:
                if not isinstance(target, dict): break
                target = target.get(part)
            if isinstance(target, dict): target.pop(bits[-1], None)
        cls._cache[doc_id] = data
        if cls._using_mongo():
            cls._mongo_db.documents.replace_one({"_id": doc_id}, {"_id": doc_id, "data": data}, upsert=True)
        else:
            await cls._persist()

    @classmethod
    def clear_cache(cls):
        cls._cache.clear(); cls._loaded = False

    @classmethod
    def clear_document_cache(cls, doc_id: str):
        cls._cache.pop(doc_id, None)
