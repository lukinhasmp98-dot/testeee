"""
Monta contexto de dados não-sensíveis do banco para a IA.
Whitelist rígida: apenas dados seguros são expostos.
Nunca expõe tokens, senhas, chaves de API, dados pessoais ou de outros clientes.
"""

from functions.database import Database


async def build_ai_context(customer_discord_id: str = None) -> str:
    """
    Monta um resumo textual dos dados do bot para injetar no prompt da IA.
    Retorna string formatada com informações da loja, tickets e configuração.
    Se customer_discord_id for fornecido, inclui dados específicos daquele cliente.
    Inclui dados locais da loja quando disponíveis.
    """
    sections = []


    products = Database.get_document("loja_products") or {}
    if products:
        product_lines = []
        for pid, prod in products.items():
            if not isinstance(prod, dict):
                continue
            name = prod.get("name", "Sem nome")
            price = prod.get("price")
            desc = prod.get("description", "")
            delivery = prod.get("delivery_type", "")
            enabled = prod.get("enabled", True)
            status = "ativo" if enabled else "desativado"

            line = f"- {name}"
            if price is not None:
                line += f" (R$ {price:.2f})"
            if delivery:
                line += f" [{delivery}]"
            line += f" — {status}"
            if desc and isinstance(desc, str):
                line += f"\n  Descrição: {desc[:120]}"
            product_lines.append(line)

        if product_lines:
            sections.append("PRODUTOS DA LOJA:\n" + "\n".join(product_lines))


    stock = Database.get_document("loja_stock") or {}
    if stock:
        stock_lines = []
        for pid, fields in stock.items():
            if not isinstance(fields, dict):
                continue

            total = 0
            for field_id, items in fields.items():
                if isinstance(items, list):
                    total += len(items)

            prod = products.get(pid, {}) if products else {}
            name = prod.get("name", pid) if isinstance(prod, dict) else pid
            stock_lines.append(f"- {name}: {total} itens em estoque")
        if stock_lines:
            sections.append("ESTOQUE:\n" + "\n".join(stock_lines))


    prefs = Database.get_document("loja_preferences") or {}
    if prefs:
        pref_lines = []
        terms = prefs.get("terms", "")
        if terms and isinstance(terms, str):
            pref_lines.append(f"Termos de uso: {terms[:200]}")
        if prefs.get("schedule"):
            sched = prefs["schedule"]
            if sched.get("enabled"):
                pref_lines.append(f"Horário: {sched.get('open', '?')} às {sched.get('close', '?')}")
        duration = prefs.get("cart_duration_minutes")
        if duration:
            pref_lines.append(f"Tempo do carrinho: {duration} minutos")
        if pref_lines:
            sections.append("PREFERÊNCIAS DA LOJA:\n" + "\n".join(pref_lines))


    maintenance = Database.get_document("loja_maintenance") or {}
    if maintenance.get("enabled"):
        msg = maintenance.get("message", "")
        msg_str = str(msg) if msg else ""
        sections.append(f"MANUTENÇÃO: A loja está em manutenção." + (f" Motivo: {msg_str[:100]}" if msg_str else ""))


    ticket_stats = Database.get_document("tickets_stats") or {}
    if ticket_stats:
        created = ticket_stats.get("total_created", 0)
        closed = ticket_stats.get("total_closed", 0)
        open_count = created - closed
        sections.append(f"ESTATÍSTICAS DE TICKETS:\n- Total criados: {created}\n- Total fechados: {closed}\n- Abertos agora: {max(0, open_count)}")


    bot_config = Database.get_document("bot_config") or {}
    if bot_config:
        config_lines = []
        presence = bot_config.get("presence", {})
        if isinstance(presence, dict):
            status_type = presence.get("type", "")
            status_name = presence.get("name", "")
            if status_name:
                config_lines.append(f"Status do bot: {status_type} {status_name}")
        if config_lines:
            sections.append("CONFIGURAÇÃO DO BOT:\n" + "\n".join(config_lines))


    ticket_config = Database.get_document("tickets_config") or {}
    panels = ticket_config.get("panels", {})
    if panels:
        panel_lines = []
        for panel_id, panel in panels.items():
            if not isinstance(panel, dict):
                continue
            title = panel.get("title", panel_id)
            options = panel.get("options", [])
            option_names = [o.get("label", "?") for o in options if isinstance(o, dict)]
            line = f"- {title}"
            if option_names:
                line += f" (opções: {', '.join(option_names)})"
            panel_lines.append(line)
        if panel_lines:
            sections.append("PAINÉIS DE TICKET:\n" + "\n".join(panel_lines))


    if customer_discord_id:
        try:
            from connections.mongo_db import get_main_database
            main_db = get_main_database()
            if main_db is not None:
                apps_collection = main_db["applications"]

                customer_apps = []
                async for app in apps_collection.find({
                    "$or": [
                        {"bot.owner": str(customer_discord_id)},
                        {"bot.perms": str(customer_discord_id)}
                    ],
                    "isDeleted": {"$ne": True}
                }):
                    is_owner = str(app.get("bot", {}).get("owner", "")) == str(customer_discord_id)
                    plan = app.get("plan", {})
                    hosting = app.get("hosting", {})
                    info = app.get("info", {})
                    expires = app.get("expiresAt")

                    expires_str = ""
                    if expires:
                        try:
                            from datetime import datetime
                            if hasattr(expires, 'strftime'):
                                expires_str = expires.strftime("%d/%m/%Y")
                            else:
                                expires_str = str(expires)[:10]
                        except Exception:
                            expires_str = str(expires)[:10]

                    status = hosting.get("status", "desconhecido")
                    ram_mb = hosting.get("ram")
                    ram_str = f"{ram_mb} MB" if ram_mb else "N/A"

                    app_line = (
                        f"- ID: {app.get('botID', 'N/A')} | "
                        f"Nome: {info.get('name', app.get('name', 'Sem nome'))} | "
                        f"Plano: {plan.get('name', 'N/A')} | "
                        f"RAM: {ram_str} | "
                        f"Status: {status}"
                    )
                    if expires_str:
                        app_line += f" | Expira: {expires_str}"
                    if app.get("isFree"):
                        app_line += " | Gratuito"
                    if app.get("isBlocked"):
                        app_line += " | BLOQUEADO"
                    app_line += f" | {'Dono' if is_owner else 'Permissão'}"

                    customer_apps.append(app_line)

                if customer_apps:
                    sections.append(
                        f"APLICAÇÕES DESTE CLIENTE (Discord ID: {customer_discord_id}):\n" +
                        "\n".join(customer_apps)
                    )
                else:
                    sections.append(
                        f"APLICAÇÕES DESTE CLIENTE (Discord ID: {customer_discord_id}):\n"
                        "Este cliente não possui nenhuma aplicação ativa na plataforma."
                    )
        except Exception as e:
            print(f"[AI_CONTEXT] Erro ao buscar apps do cliente: {e}")


    loja_data = Database.get_document("loja_data") or {}
    carts = loja_data.get("carts", {})

    if customer_discord_id and carts and isinstance(carts, dict):
        customer_carts = []
        for cid, cart in carts.items():
            if not isinstance(cart, dict):
                continue
            if str(cart.get("user_id", "")) == str(customer_discord_id):
                customer_carts.append(cart)

        if customer_carts:
            customer_lines = []
            for cart in customer_carts:
                status = cart.get("status", "")
                total = cart.get("total", 0)
                items = cart.get("items", [])
                item_names = []
                for item in items:
                    if isinstance(item, dict):
                        name = item.get("product_name", item.get("name", "Produto"))
                        qty = item.get("qty", 1)
                        item_names.append(f"{name} x{qty}" if qty > 1 else name)

                status_label = {
                    "approved": "Aprovado/Entregue",
                    "pending_payment": "Aguardando Pagamento",
                    "active": "Carrinho Ativo",
                    "cancelled": "Cancelado",
                }.get(status, status)

                line = f"- {', '.join(item_names) if item_names else 'Pedido'} — R$ {total:.2f} — {status_label}"
                if cart.get("manual_delivered"):
                    line += " (entrega manual concluída)"
                customer_lines.append(line)

            sections.append(
                f"COMPRAS DESTE CLIENTE (Discord ID: {customer_discord_id}):\n" +
                "\n".join(customer_lines)
            )
        else:
            sections.append(f"COMPRAS DESTE CLIENTE (Discord ID: {customer_discord_id}):\nNenhuma compra registrada nesta loja.")


    if carts and isinstance(carts, dict):
        active_carts = 0
        approved_carts = 0
        pending_carts = 0
        total_revenue = 0.0
        for cid, cart in carts.items():
            if not isinstance(cart, dict):
                continue
            status = cart.get("status", "")
            if status == "approved":
                approved_carts += 1
                total_revenue += cart.get("total", 0)
            elif status in ("pending_payment", "active"):
                pending_carts += 1
            active_carts += 1
        if active_carts > 0:
            cart_lines = [
                f"- Total de pedidos registrados: {active_carts}",
                f"- Aprovados/entregues: {approved_carts}",
                f"- Pendentes de pagamento: {pending_carts}",
                f"- Receita de vendas aprovadas: R$ {total_revenue:.2f}",
            ]
            sections.append("VENDAS GERAIS DA LOJA (todos os clientes):\n" + "\n".join(cart_lines))


    sales = Database.get_document("kroma_sales") or []
    if sales:
        total_sales = sum(float(item.get("amount", 0) or 0) for item in sales)
        sections.append(f"FATURAMENTO LOCAL KROMA:\n- Vendas confirmadas: {len(sales)}\n- Total confirmado: R$ {total_sales:.2f}\n- Pagamentos são PIX manual confirmado pela equipe.")

    if not sections:
        return ""


    text_instruction = (
        "\n\nINSTRUÇÃO IMPORTANTE SOBRE FORMATO DE RESPOSTA:"
        "\n- Quando o cliente pedir informações do sistema (dados do bot, aplicações, transações, saldo, compras, etc), você DEVE incluir os dados DIRETAMENTE na sua resposta. NÃO diga 'vou enviar por texto' ou 'preciso te enviar' — simplesmente responda com as informações."
        "\n- Use a ferramenta 'responder_por_texto' SEMPRE que a resposta contiver: IDs, links, códigos, tokens, nomes de planos, datas específicas, status de aplicações, ou qualquer dado que o cliente precise copiar ou ler com precisão."
        "\n- Pode responder por ÁUDIO normalmente quando for: contagens gerais (ex: 'você tem 3 bots'), valores monetários simples (ex: 'seu saldo é 50 reais'), explicações, orientações ou conversas sem dados específicos."
        "\n- NUNCA dite IDs, códigos ou links por áudio. Essas informações DEVEM ser enviadas por texto."
        "\n- Identifique o cliente pelo Discord ID informado acima e forneça apenas os dados dele."
        "\n- NUNCA use tags de emoção como [Animado], [Feliz], [Triste] etc nas suas respostas. Responda de forma natural sem essas anotações."
    )

    return "--- DADOS DO SISTEMA (contexto para suas respostas) ---\n\n" + "\n\n".join(sections) + text_instruction + "\n\n--- FIM DOS DADOS ---"
