from functions.database import Database
import random
import string
import datetime

class GiveawaysManager:
    @staticmethod
    def gerar_id(length: int = 12) -> str:
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

    @staticmethod
    def obter_giveaways() -> dict:
        data = Database.get_document("giveaways_data") or {}
        return data.get("giveaways", {})

    @staticmethod
    def salvar_giveaways(giveaways: dict):
        Database.save_document("giveaways_data", {"giveaways": giveaways})

    @staticmethod
    def obter_giveaway(giveaway_id: str) -> dict | None:
        giveaways = GiveawaysManager.obter_giveaways()
        return giveaways.get(giveaway_id)

    @staticmethod
    def salvar_giveaway(giveaway_id: str, data: dict):
        giveaways = GiveawaysManager.obter_giveaways()
        giveaways[giveaway_id] = data
        GiveawaysManager.salvar_giveaways(giveaways)

    @staticmethod
    def deletar_giveaway(giveaway_id: str):
        giveaways = GiveawaysManager.obter_giveaways()
        if giveaway_id in giveaways:
            del giveaways[giveaway_id]
            GiveawaysManager.salvar_giveaways(giveaways)

    @staticmethod
    def atualizar_task(giveaway_id: str, task_id: str, task_data: dict):
        giveaway = GiveawaysManager.obter_giveaway(giveaway_id)
        if not giveaway:
            return

        for i, task in enumerate(giveaway.get("tasks", [])):
            if task.get("id") == task_id:
                giveaway["tasks"][i] = task_data
                GiveawaysManager.salvar_giveaway(giveaway_id, giveaway)
                break

    @staticmethod
    def check_requirements(member, giveaway_data: dict) -> tuple[bool, str]:

        min_age_days = giveaway_data.get("min_account_age_days", 0)
        if min_age_days > 0:
            account_age = (datetime.datetime.now(datetime.timezone.utc) - member.created_at).days
            if account_age < min_age_days:
                return False, f"Sua conta precisa ter pelo menos {min_age_days} dias (você tem {account_age})"

        allowed_roles = giveaway_data.get("allowed_roles", [])
        if allowed_roles:
            member_role_ids = {r.id for r in member.roles}
            if not any(int(rid) in member_role_ids for rid in allowed_roles):
                return False, "Você não possui nenhum cargo permitido para este sorteio"

        forbidden_roles = giveaway_data.get("forbidden_roles", [])
        if forbidden_roles:
            member_role_ids = {r.id for r in member.roles}
            if any(int(rid) in member_role_ids for rid in forbidden_roles):
                return False, "Você possui um cargo que não pode participar deste sorteio"

        min_invites = giveaway_data.get("min_invites", 0)
        if min_invites > 0:

            invites_data = Database.get_document("invites_data") or {}
            guild_id_str = str(member.guild.id)
            member_id_str = str(member.id)
            user_invites = (
                invites_data.get(guild_id_str, {})
                .get("invites", {})
                .get(member_id_str, {})
                .get("valid", 0)
            )
            if user_invites < min_invites:
                return False, f"Você precisa ter pelo menos {min_invites} convites válidos (você tem {user_invites})"

        return True, ""
