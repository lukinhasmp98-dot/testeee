from functions.database import Database


class PlanManager:
    @staticmethod
    def get_plan() -> str:
        try:
            config = Database.get_config()
            if config and isinstance(config, dict):
                plan = config.get("plan", "pro")
                if plan and isinstance(plan, str):
                    return plan.lower()
            return "pro"
        except Exception:
            return "pro"

    @staticmethod
    def should_enable_panel_button(button_name: str) -> bool:
        button_to_module = {
            "loja": "store",
            "ticket": "tickets",
            "cloud": "cloud",
            "personalizacao": "customization",
            "automacoes": "automations",
            "protection": "protection",
            "sorteios": "giveaways",
            "configuracoes": "settings",
            "rendimentos": "earnings"
        }

        plan = PlanManager.get_plan()

        if plan == "pro":
            return True

        if plan == "cloud":
            module_name = button_to_module.get(button_name, button_name)
            return module_name in ["cloud", "settings", "customization"]

        if plan == "basic":
            module_name = button_to_module.get(button_name, button_name)
            return module_name != "cloud"

        if plan == "free":
            module_name = button_to_module.get(button_name, button_name)
            return module_name not in ["cloud", "protection"]

        return True
