import os
import json
import asyncio
from collections import deque
from datetime import datetime

try:
    import aiohttp
except Exception:
    aiohttp = None

_log_queue: deque = deque()
_QUEUE_MAX = 500
_queue_overflow_warned = False
_api_url = None
_bot_id = None
_bot_token = None
_running = False
_worker_task = None
_session: "aiohttp.ClientSession | None" = None


def init_reporter():
    """Inicializa o reporter de logs lendo config.json. Worker assíncrono inicia no primeiro log."""
    global _api_url, _bot_id, _bot_token, _running

    try:
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json")
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)

        _api_url = config.get("api_url")
        _bot_id = config.get("bot_id")
        _bot_token = config.get("bot_token")

        if not _api_url or not _bot_id:
            return

        _running = True
    except Exception:
        pass


async def _ensure_worker():
    """Garante que o worker assíncrono esteja rodando (precisa de loop ativo)."""
    global _worker_task, _session
    if _worker_task is not None and not _worker_task.done():
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    if aiohttp is None:
        return
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()
    _worker_task = loop.create_task(_worker())


async def _worker():
    """Drena a queue e envia logs em HTTP assíncrono."""
    global _session
    while _running:
        if not _log_queue:
            await asyncio.sleep(0.5)
            continue
        entry = _log_queue.popleft()
        try:
            await _send_log(entry)
        except Exception:
            # Nunca derruba o worker
            pass


async def _send_log(entry: dict):
    global _session
    if not _api_url or not _bot_id or aiohttp is None:
        return
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()

    headers = {}
    if _bot_token:
        headers["Authorization"] = str(_bot_token)

    try:
        timeout = aiohttp.ClientTimeout(total=5)
        async with _session.post(
            f"{_api_url}/api/bot/{_bot_id}/log",
            json=entry,
            headers=headers,
            timeout=timeout,
        ) as resp:
            # Consome o body pra liberar conexão; ignora status
            await resp.read()
    except Exception:
        pass


def report(message: str, level: str = "info", context: str = None):
    """Envia um log para o backend (não-bloqueante).
    Mantém backpressure: se >QUEUE_MAX, descarta o mais antigo e avisa 1x."""
    global _queue_overflow_warned
    if not _running:
        return

    entry = {
        "level": level,
        "message": message,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    if context:
        entry["context"] = context

    if len(_log_queue) >= _QUEUE_MAX:
        try:
            _log_queue.popleft()
        except IndexError:
            pass
        if not _queue_overflow_warned:
            print(f"[LOG_REPORTER WARN] Fila de logs atingiu {_QUEUE_MAX}; descartando logs antigos.")
            _queue_overflow_warned = True

    _log_queue.append(entry)

    # Dispara o worker na primeira publicação que acontece com loop ativo
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_ensure_worker())
    except RuntimeError:
        # Sem loop ativo ainda; o worker será iniciado quando houver loop
        pass


async def shutdown():
    """Fecha a sessão aiohttp no shutdown."""
    global _running, _session, _worker_task
    _running = False
    try:
        if _worker_task is not None:
            _worker_task.cancel()
    except Exception:
        pass
    try:
        if _session is not None and not _session.closed:
            await _session.close()
    except Exception:
        pass


# Atalhos
def info(msg: str, ctx: str = None):
    report(msg, "info", ctx)

def success(msg: str, ctx: str = None):
    report(msg, "success", ctx)

def warn(msg: str, ctx: str = None):
    report(msg, "warn", ctx)

def error(msg: str, ctx: str = None):
    report(msg, "error", ctx)

def debug(msg: str, ctx: str = None):
    report(msg, "debug", ctx)
