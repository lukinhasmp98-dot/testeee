import disnake
import random
import string
from functions.database import Database


class Utils:
    @staticmethod
    def get_server_id() -> int | None:
        from functions.servers import ServerManager
        return ServerManager.get_server_id("main")

    @staticmethod
    def normalize_hex_color(hex_str: str) -> str | None:
        """
        Normaliza uma string de cor hexadecimal.

        Args:
            hex_str: Cor em formato "#RGB", "#RRGGBB", "RGB" ou "RRGGBB".

        Returns:
            Cor normalizada em formato "#rrggbb" ou None se inválida.
        """
        if not hex_str or not isinstance(hex_str, str):
            return None
        s = hex_str.strip()
        if not s:
            return None
        if s.startswith("#"):
            s = s[1:]
        if len(s) not in (3, 6):
            return None
        try:
            int(s, 16)
        except ValueError:
            return None
        return f"#{s.lower()}"

    @staticmethod
    def format_price_brl(price: float) -> str:
        if price is None:
            price = 0.0
        return f"R$ {price:.2f}".replace(".", ",")

    @staticmethod
    def gerar_id(length=8):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    @staticmethod
    def format_timestamp(timestamp):
        if not timestamp:
            return "N/A"
        return f"<t:{int(timestamp)}:f>"

    @staticmethod
    def wrap_text_hyphenate(text, max_width=40):

        import textwrap
        return "\n".join(textwrap.wrap(text, width=max_width))

    @staticmethod
    def safe_get_emoji(emoji_str):
        if not emoji_str or not isinstance(emoji_str, str):
            return None
        emoji_str = emoji_str.strip()
        if not emoji_str:
            return None

        return emoji_str

    @staticmethod
    def generate_feedback_container(text: str, type: str = "success") -> disnake.ui.Container:
        from functions.panels import PanelMixin
        return PanelMixin.generate_feedback_container(text, type)
    @staticmethod
    def truncate_text(text: str, max_length: int = 100) -> str:
        if not text:
            return ""
        return (text[:max_length] + "..") if len(text) > max_length else text

    @staticmethod
    def get_loading_components() -> list[disnake.ui.Container]:
        from functions.panels import PanelMixin
        return PanelMixin.get_loading_components()
