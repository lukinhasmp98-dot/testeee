from functions.database import Database

class Permissions:
    @staticmethod
    async def check_user(user_id) -> bool:

        config = Database.get_config()
        perms = config.get("perms", [])
        if str(user_id) in perms:
            return True

        admins_data = Database.get_document("admins") or {}
        admin_ids = admins_data.get("ids", [])
        if str(user_id) in admin_ids:
            return True

        return await Permissions.check_owner(user_id)

    @staticmethod
    async def check_owner(user_id) -> bool:
        owner_id = Database.get_config("owner_id")
        return str(user_id) == str(owner_id)

    @staticmethod
    def get_admins() -> list:
        admins_data = Database.get_document("admins") or {}
        return admin_ids if (admin_ids := admins_data.get("ids")) else []

    @staticmethod
    def add_admin(user_id: str) -> bool:
        admins_data = Database.get_document("admins") or {"ids": []}
        if str(user_id) not in admins_data["ids"]:
            admins_data["ids"].append(str(user_id))
            Database.save_document("admins", admins_data)
            return True
        return False

    @staticmethod
    def remove_admin(user_id: str) -> bool:
        admins_data = Database.get_document("admins") or {"ids": []}
        if str(user_id) in admins_data["ids"]:
            admins_data["ids"].remove(str(user_id))
            Database.save_document("admins", admins_data)
            return True
        return False

