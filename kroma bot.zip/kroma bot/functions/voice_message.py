"""
Módulo para enviar mensagens de voz no Discord.
As mensagens de voz aparecem como áudios gravados pelo aplicativo,
não como arquivos anexados.
"""

import aiohttp
import base64
import os
import io
from typing import Union, Optional


IS_VOICE_MESSAGE = 1 << 13


DEFAULT_WAVEFORM = "acU6Va9UcSVZzsVw7IU/80s0Kh/pbrTcwmpR9da4mvQejIMykkgo9F2FfeCd235K/atHZtSAmxKeTUgKxAdNVO8PAoZq1cHNQXT/PHthL2sfPZGSdxNgLH0AuJwVeI7QZJ02ke40+HkUcBoDdqGDZeUvPqoIRbE23Kr+sexYYe4dVq+zyCe3ci/6zkMWbVBpCjq8D8ZZEFo/lmPJTkgjwqnqHuf6XT4mJyLNphQjvFH9aRqIZpPoQz1sGwAY2vssQ5mTy5J5muGo+n82b0xFROZwsJpumDsFi4Da/85uWS/YzjY5BdxGac8rgUqm9IKh7E6GHzOGOy0LQIz3O4ntTg=="


async def send_voice_message(
    bot,
    channel_id: int,
    audio_data: Union[bytes, io.BytesIO, str],
    duration_secs: float = 5.0,
    waveform: Optional[str] = None,
    filename: str = "voice-message.ogg",
    reply_to: Optional[int] = None
) -> Optional[dict]:
    """
    Envia uma mensagem de voz em um canal do Discord.

    A mensagem aparece como um áudio gravado pelo aplicativo,
    não como um arquivo anexado.

    Args:
        bot: Instância do bot (commands.Bot)
        channel_id: ID do canal onde enviar a mensagem
        audio_data: Dados do áudio em formato .ogg (bytes, BytesIO, ou caminho do arquivo)
        duration_secs: Duração do áudio em segundos (para exibição)
        waveform: Base64 encoded waveform (opcional, usa padrão se não fornecido)
        filename: Nome do arquivo (deve terminar com .ogg)
        reply_to: ID da mensagem para responder (opcional)

    Returns:
        dict com os dados da mensagem enviada, ou None se falhou
    """


    if not filename.endswith(".ogg"):
        raise ValueError("O arquivo deve ser no formato .ogg")


    if isinstance(audio_data, str):
        if not os.path.exists(audio_data):
            raise ValueError(f"Arquivo não encontrado: {audio_data}")
        with open(audio_data, "rb") as f:
            audio_bytes = f.read()
    elif isinstance(audio_data, io.BytesIO):
        audio_data.seek(0)
        audio_bytes = audio_data.read()
    elif isinstance(audio_data, bytes):
        audio_bytes = audio_data
    else:
        raise ValueError("audio_data deve ser bytes, BytesIO ou caminho de arquivo")

    file_size = len(audio_bytes)


    if waveform is None:
        waveform = DEFAULT_WAVEFORM


    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bot {bot.http.token}"
    }

    async with aiohttp.ClientSession() as session:

        upload_request_url = f"https://discord.com/api/v10/channels/{channel_id}/attachments"
        upload_request_data = {
            "files": [
                {
                    "filename": filename,
                    "file_size": file_size,
                    "id": "0"
                }
            ]
        }

        async with session.post(upload_request_url, json=upload_request_data, headers=headers) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                print(f"[VOICE] Erro ao solicitar URL de upload: {resp.status} - {error_text}")
                return None

            upload_response = await resp.json()


        attachment_data = upload_response.get("attachments", [{}])[0]
        upload_url = attachment_data.get("upload_url")
        upload_filename = attachment_data.get("upload_filename")

        if not upload_url or not upload_filename:
            print("[VOICE] Resposta de upload inválida")
            return None


        upload_headers = {
            "Content-Type": "audio/ogg"
        }

        async with session.put(upload_url, data=audio_bytes, headers=upload_headers) as resp:
            if resp.status not in [200, 201]:
                error_text = await resp.text()
                print(f"[VOICE] Erro ao fazer upload: {resp.status} - {error_text}")
                return None


        message_url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
        message_data = {
            "flags": IS_VOICE_MESSAGE,
            "attachments": [
                {
                    "id": "0",
                    "filename": filename,
                    "uploaded_filename": upload_filename,
                    "duration_secs": duration_secs,
                    "waveform": waveform
                }
            ]
        }


        if reply_to:
            message_data["message_reference"] = {
                "message_id": str(reply_to)
            }

        async with session.post(message_url, json=message_data, headers=headers) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                print(f"[VOICE] Erro ao enviar mensagem: {resp.status} - {error_text}")
                return None

            return await resp.json()


async def send_voice_message_to_channel(
    channel,
    audio_data: Union[bytes, io.BytesIO, str],
    duration_secs: float = 5.0,
    waveform: Optional[str] = None,
    filename: str = "voice-message.ogg"
) -> Optional[dict]:
    bot = channel._state._get_client()
    return await send_voice_message(
        bot=bot,
        channel_id=channel.id,
        audio_data=audio_data,
        duration_secs=duration_secs,
        waveform=waveform,
        filename=filename
    )
