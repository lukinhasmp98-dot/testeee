import disnake
from disnake.ext import commands
from functions.panels import PanelMixin

class DashboardModule(PanelMixin):
    pass
