from functions.database import Database
from typing import Any
import datetime

class ProtectionManager:

    PROTECTION_TYPES = {
        "mass_ban": {
            "name": "Mass Ban",
            "description": "Proteção contra banimentos em massa",
            "default_limit": 3,
            "default_interval": 60
        },
        "mass_kick": {
            "name": "Mass Kick",
            "description": "Proteção contra expulsões em massa",
            "default_limit": 5,
            "default_interval": 60
        },
        "mass_role_create": {
            "name": "Mass Role Create",
            "description": "Proteção contra criação em massa de cargos",
            "default_limit": 3,
            "default_interval": 30
        },
        "mass_role_delete": {
            "name": "Mass Role Delete",
            "description": "Proteção contra exclusão em massa de cargos",
            "default_limit": 3,
            "default_interval": 30
        },
        "mass_role_edit": {
            "name": "Mass Role Edit",
            "description": "Proteção contra edição em massa de cargos",
            "default_limit": 5,
            "default_interval": 30
        },
        "mass_channel_create": {
            "name": "Mass Channel Create",
            "description": "Proteção contra criação em massa de canais",
            "default_limit": 3,
            "default_interval": 30
        },
        "mass_channel_delete": {
            "name": "Mass Channel Delete",
            "description": "Proteção contra exclusão em massa de canais",
            "default_limit": 3,
            "default_interval": 30
        },
        "mass_webhook_create": {
            "name": "Mass Webhook Create",
            "description": "Proteção contra criação em massa de webhooks",
            "default_limit": 2,
            "default_interval": 60
        },
        "anti_fake": {
            "name": "Anti-Fake",
            "description": "Expulsa contas criadas recentemente",
            "default_limit": 1,
            "default_interval": 0,
            "min_days": 7
        },
        "bot_entry": {
            "name": "Bloqueio de Bots",
            "description": "Bloqueia a entrada de qualquer bot externo",
            "default_limit": 1,
            "default_interval": 0
        }
    }

    PUNISHMENT_OPTIONS = {
        "ban": "Banimento",
        "kick": "Expulsão",
        "timeout_30d": "Timeout 30 dias",
        "remove_roles": "Remover Cargos",
        "none": "Nenhuma (apenas log)"
    }

    @staticmethod
    def get_config(protection_type: str = None) -> dict[str, Any]:
        config = Database.get_document("protection_config") or {}

        if protection_type:
            if protection_type not in config:
                defaults = ProtectionManager.PROTECTION_TYPES.get(protection_type, {})
                base_config = {
                    "enabled": False,
                    "limit": defaults.get("default_limit", 5),
                    "interval": defaults.get("default_interval", 60),
                    "punishment": "ban",
                    "immune_roles": [],
                    "log_channel": None,
                    "actions": []
                }

                for key, value in defaults.items():
                    if key not in ["name", "description", "default_limit", "default_interval"]:
                        base_config[key] = value
                return base_config
            return config[protection_type]

        for ptype in ProtectionManager.PROTECTION_TYPES:
            if ptype not in config:
                defaults = ProtectionManager.PROTECTION_TYPES[ptype]
                ptype_config = {
                    "enabled": False,
                    "limit": defaults["default_limit"],
                    "interval": defaults["default_interval"],
                    "punishment": "ban",
                    "immune_roles": [],
                    "log_channel": None,
                    "actions": []
                }
                for key, value in defaults.items():
                    if key not in ["name", "description", "default_limit", "default_interval"]:
                        ptype_config[key] = value
                config[ptype] = ptype_config

        return config

    @staticmethod
    def save_config(protection_type: str, config_data: dict[str, Any]):
        config = ProtectionManager.get_config()
        config[protection_type] = config_data
        Database.save_document("protection_config", config)

    @staticmethod
    def toggle_protection(protection_type: str) -> bool:
        config = ProtectionManager.get_config(protection_type)
        config["enabled"] = not config.get("enabled", False)
        ProtectionManager.save_config(protection_type, config)
        return config["enabled"]

    @staticmethod
    def set_limit(protection_type: str, limit: int):
        config = ProtectionManager.get_config(protection_type)
        config["limit"] = max(1, min(limit, 100))
        ProtectionManager.save_config(protection_type, config)

    @staticmethod
    def set_interval(protection_type: str, interval: int):
        config = ProtectionManager.get_config(protection_type)
        config["interval"] = max(5, min(interval, 3600))
        ProtectionManager.save_config(protection_type, config)

    @staticmethod
    def set_punishment(protection_type: str, punishment: str):
        if punishment in ProtectionManager.PUNISHMENT_OPTIONS:
            config = ProtectionManager.get_config(protection_type)
            config["punishment"] = punishment
            ProtectionManager.save_config(protection_type, config)

    @staticmethod
    def set_immune_roles(protection_type: str, role_ids: list):
        config = ProtectionManager.get_config(protection_type)
        config["immune_roles"] = [int(rid) for rid in role_ids]
        ProtectionManager.save_config(protection_type, config)

    @staticmethod
    def set_log_channel(protection_type: str, channel_id: int = None):
        config = ProtectionManager.get_config(protection_type)
        config["log_channel"] = int(channel_id) if channel_id else None
        ProtectionManager.save_config(protection_type, config)

    @staticmethod
    def set_min_days(days: int):
        config = ProtectionManager.get_config("anti_fake")
        config["min_days"] = max(0, min(days, 365))
        ProtectionManager.save_config("anti_fake", config)

    @staticmethod
    def get_min_days() -> int:
        config = ProtectionManager.get_config("anti_fake")
        return config.get("min_days", 7)

    @staticmethod
    def record_action(protection_type: str, user_id: int):
        config = ProtectionManager.get_config(protection_type)

        if "actions" not in config:
            config["actions"] = []

        now = datetime.datetime.now().timestamp()
        config["actions"].append({"user_id": user_id, "timestamp": now})

        interval = config.get("interval", 60)
        config["actions"] = [
            action for action in config["actions"]
            if now - action["timestamp"] <= interval
        ]

        ProtectionManager.save_config(protection_type, config)

        return sum(1 for a in config["actions"] if a["user_id"] == user_id)

    @staticmethod
    def check_violation(protection_type: str, user_id: int) -> bool:
        config = ProtectionManager.get_config(protection_type)

        if not config.get("enabled", False):
            return False

        action_count = ProtectionManager.record_action(protection_type, user_id)
        limit = config.get("limit", 5)

        return action_count > limit
