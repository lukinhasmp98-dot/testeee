
class Messages:

    ERROR_NO_PERMISSION = "Você não tem permissão para executar esta ação."
    ERROR_NOT_FOUND = "Item não encontrado."
    ERROR_INVALID_INPUT = "Entrada inválida. Verifique os dados e tente novamente."
    ERROR_ALREADY_EXISTS = "Este item já existe."
    ERROR_LIMIT_REACHED = "Limite máximo atingido."
    ERROR_INTERACTION_EXPIRED = "Interação expirada. Tente novamente."
    ERROR_API = "Erro na API. Tente novamente mais tarde."
    ERROR_DATABASE = "Erro ao acessar o banco de dados."
    ERROR_CONFIG_MISSING = "Configuração não encontrada."

    SUCCESS_SAVED = "Salvo com sucesso!"
    SUCCESS_CREATED = "Criado com sucesso!"
    SUCCESS_DELETED = "Removido com sucesso!"
    SUCCESS_UPDATED = "Atualizado com sucesso!"
    SUCCESS_ENABLED = "Ativado com sucesso!"
    SUCCESS_DISABLED = "Desativado com sucesso!"
    SUCCESS_ADDED = "Adicionado com sucesso!"
    SUCCESS_REMOVED = "Removido com sucesso!"


    WARNING_NO_CHANGES = "Nenhuma alteração foi feita."
    WARNING_ALREADY_ENABLED = "Já está ativado."
    WARNING_ALREADY_DISABLED = "Já está desativado."
    WARNING_EMPTY_LIST = "A lista está vazia."


    INFO_LOADING = "Carregando..."
    INFO_PROCESSING = "Processando..."
    INFO_PLEASE_WAIT = "Aguarde um momento..."


    TICKET_NOT_FOUND = "Ticket não encontrado."
    TICKET_ALREADY_EXISTS = "Você já possui um ticket aberto."
    TICKET_CLOSED = "Ticket fechado com sucesso."


    STORE_MAINTENANCE = "Loja em manutenção. Tente novamente mais tarde."
    STORE_OUT_OF_STOCK = "Produto fora de estoque."
    STORE_CART_EXPIRED = "Seu carrinho expirou."
    STORE_PAYMENT_PENDING = "Aguardando confirmação de pagamento..."
    STORE_PAYMENT_APPROVED = "Pagamento aprovado!"


class LoadingStates:

    DEFAULT = "**Carregando...**\n-# Aguarde enquanto processamos sua solicitação."
    SAVING = "**Salvando...**\n-# Aguarde um momento."
    PROCESSING = "**Processando...**\n-# Isso pode levar alguns segundos."
    CREATING = "**Criando...**\n-# Preparando seu recurso."
    DELETING = "**Removendo...**\n-# Processando exclusão."
    FETCHING = "**Buscando dados...**\n-# Consultando informações."
    PUBLISHING = "**Publicando...**\n-# Enviando para o canal."


    CHECKING_STOCK = "**Verificando estoque...**"
    CREATING_CART = "**Criando carrinho...**"
    PROCESSING_PAYMENT = "**Processando pagamento...**"


class Limits:


    MAX_TICKET_OPTIONS = 25
    MAX_TICKET_QUESTIONS = 10
    TICKET_NAME_MAX_LENGTH = 100


    MAX_PRODUCT_FIELDS = 25
    MAX_PRODUCT_NAME_LENGTH = 50


    MAX_GIVEAWAY_WINNERS = 100
    MAX_GIVEAWAY_TASKS = 10


    MAX_REWARDS = 25


    EMBED_DESCRIPTION_MAX = 4096
    BUTTON_LABEL_MAX = 80
    SELECT_OPTION_MAX = 25


class Breadcrumbs:

    @staticmethod
    def create(path: list) -> str:
        """
        Cria breadcrumb formatado.

        Args:
            path: Lista de strings representando o caminho.
                  O último item será destacado.

        Returns:
            String formatada: "-# Painel > Loja > **Produtos**"
        """
        if not path:
            return ""

        if len(path) == 1:
            return f"-# **{path[0]}**"


        formatted = " > ".join(path[:-1])
        return f"-# {formatted} > **{path[-1]}**"


class Prefixes:

    DASHBOARD = "Dashboard_"
    STORE = "Store_"
    TICKET = "Ticket_"
    GIVEAWAY = "Giveaway_"
    PROTECTION = "Protection_"
    SETTINGS = "Settings_"
    AUTOMATION = "Automation_"
    INVITE = "InviteTracker_"
    FORMS = "Forms_"
    BOOSTERS = "Boosters_"
    AFFILIATE = "Affiliate_"
    ADMINS = "Admins_"
    CART = "Cart_"
    CHECKOUT = "Checkout_"
    WALLET = "Wallet_"
