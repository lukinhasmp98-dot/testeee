import disnake
import asyncio
from typing import Callable, Any


class PanelMixin:
    """
    Mixin base para módulos que possuem painéis de configuração.

    Fornece métodos padronizados para:
    - Exibição de painéis
    - Feedback temporário
    - Componentes de loading
    - Navegação consistente

    Usage:
        class MyModule(commands.Cog, PanelMixin):
            def get_panel(self, inter) -> dict:
                return {"components": [...]}
    """

    _last_interaction: dict[int, float] = {}

    @staticmethod
    def get_accent() -> disnake.Colour:
        """
        Retorna a cor de destaque do tema.

        Returns:
            disnake.Colour: Cor primária do tema.
        """
        return disnake.Colour(0x5865F2)

    @staticmethod
    def get_container_kwargs() -> dict:
        """
        Retorna kwargs para containers com cor do tema.

        Returns:
            dict: {"accent_colour": Colour}
        """
        return {}

    @staticmethod
    def get_loading_components() -> list[disnake.ui.Container]:
        """
        Retorna componentes de loading padrão.

        Returns:
            list[Container]: Componentes de loading.
        """
        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay("⏳ **Carregando...**"),
                disnake.ui.TextDisplay("-# Aguarde enquanto processamos sua solicitação."),
            )
        ]

    @staticmethod
    def get_error_components(message: str = "Ocorreu um erro inesperado.") -> list[disnake.ui.Container]:
        """
        Retorna componentes de erro padrão.

        Args:
            message: Mensagem de erro a exibir.

        Returns:
            list[Container]: Componentes de erro.
        """
        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"# Erro"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(message),

            )
        ]

    @staticmethod
    def get_success_components(message: str) -> list[disnake.ui.Container]:
        """
        Retorna componentes de sucesso padrão.

        Args:
            message: Mensagem de sucesso a exibir.

        Returns:
            list[Container]: Componentes de sucesso.
        """
        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"# Sucesso"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(message),

            )
        ]

    @staticmethod
    def create_back_button(
        custom_id: str = "Dashboard_Home",
        label: str = "Voltar"
    ) -> disnake.ui.ActionRow:
        """
        Cria um botão de voltar padronizado.

        Args:
            custom_id: ID do botão de destino.
            label: Texto do botão.

        Returns:
            ActionRow: Linha com botão de voltar.
        """
        return disnake.ui.ActionRow(
            disnake.ui.Button(
                label=label,
                style=disnake.ButtonStyle.grey,
                custom_id=custom_id
            )
        )

    @staticmethod
    def generate_feedback_container(
        text: str,
        feedback_type: str = "success"
    ) -> disnake.ui.Container:
        configs = {
            "success": {"title": "Sucesso"},
            "error": {"title": "Erro"},
            "warning": {"title": "Aviso"},
            "info": {"title": "Informação"},
        }

        config = configs.get(feedback_type, configs["success"])

        return disnake.ui.Container(
            disnake.ui.TextDisplay(f"### {config['title']}"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(f"-# {text}"),
        )

    async def show_loading(self, inter: disnake.MessageInteraction) -> None:
        """
        Exibe loading na interação.

        Args:
            inter: Interação do Discord.
        """
        if not inter.response.is_done():
            await inter.response.edit_message(
                components=self.get_loading_components(),
                flags=disnake.MessageFlags(is_components_v2=True)
            )

    async def edit_panel(
        self,
        inter: disnake.MessageInteraction,
        panel_data: dict
    ) -> None:
        """
        Edita a mensagem com os dados do painel.

        Args:
            inter: Interação do Discord.
            panel_data: dict com 'components' e opcionalmente 'content'.
        """
        if "content" not in panel_data:
            panel_data["content"] = None

        try:
            if inter.response.is_done():
                await inter.edit_original_message(
                    **panel_data,
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
            else:
                await inter.response.edit_message(
                    **panel_data,
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
        except disnake.errors.NotFound:
            pass
        except Exception as e:
            print(f"[PANEL ERROR] Erro ao editar painel: {e}")

    async def show_feedback(
        self,
        inter: disnake.MessageInteraction,
        message: str,
        feedback_type: str,
        view_func: Callable,
        *args,
        **kwargs
    ) -> None:
        """
        Exibe feedback temporário (10s) e depois restaura o painel.

        Args:
            inter: Interação do Discord.
            message: Mensagem de feedback.
            feedback_type: Tipo (success, error, warning, info).
            view_func: Função que retorna o painel original.
            *args: Argumentos para view_func.
            **kwargs: Kwargs para view_func.
        """
        import inspect

        message_id = inter.message.id if inter.message else None
        timestamp = asyncio.get_event_loop().time()

        if message_id:
            PanelMixin._last_interaction[message_id] = timestamp

        feedback_container = self.generate_feedback_container(message, feedback_type)


        sig = inspect.signature(view_func)
        has_feedback_arg = "feedback_data" in sig.parameters or any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
        )

        if has_feedback_arg:
            kwargs["feedback_data"] = feedback_container
            panel = view_func(*args, **kwargs)
        else:
            panel = view_func(*args, **kwargs)
            if isinstance(panel, dict) and "components" in panel:
                if isinstance(panel["components"], list):
                    panel["components"].append(feedback_container)

        payload = {**panel, "flags": disnake.MessageFlags(is_components_v2=True)}
        if "content" not in payload:
            payload["content"] = None

        try:
            if not inter.response.is_done():
                await inter.response.edit_message(**payload)
            else:
                await inter.edit_original_message(**payload)
        except disnake.errors.NotFound:
            return
        except Exception as e:
            print(f"[FEEDBACK ERROR] Erro ao mostrar feedback: {e}")
            return

        async def clear_feedback(msg_id: int, original_time: float):
            await asyncio.sleep(10)

            if msg_id and PanelMixin._last_interaction.get(msg_id) != original_time:
                return

            kwargs.pop("feedback_data", None)

            if has_feedback_arg:
                clean_panel = view_func(*args, **kwargs)
            else:
                clean_panel = view_func(*args, **kwargs)

            payload_clean = {**clean_panel, "flags": disnake.MessageFlags(is_components_v2=True)}
            if "content" not in payload_clean:
                payload_clean["content"] = None

            try:
                await inter.edit_original_message(**payload_clean)
            except Exception:
                pass

        asyncio.create_task(clear_feedback(message_id, timestamp))


class PanelRouter:
    """
    Roteador centralizado para navegação entre painéis.

    Permite mapear custom_ids para handlers de forma declarativa.

    Usage:
        router = PanelRouter()
        router.register("Module_Action", handler_func)
        await router.handle(inter)
    """

    def __init__(self):
        self._routes: dict[str, Callable] = {}
        self._prefix_routes: dict[str, Callable] = {}

    def register(
        self,
        pattern: str,
        handler: Callable,
        is_prefix: bool = False
    ) -> None:
        """
        Registra um handler para um padrão de custom_id.

        Args:
            pattern: Padrão exato ou prefixo do custom_id.
            handler: Função async que recebe (inter, *args).
            is_prefix: Se True, faz match por prefixo.
        """
        if is_prefix:
            self._prefix_routes[pattern] = handler
        else:
            self._routes[pattern] = handler

    async def handle(
        self,
        inter: disnake.MessageInteraction
    ) -> bool:
        """
        Tenta rotear a interação para um handler registrado.

        Args:
            inter: Interação do Discord.

        Returns:
            bool: True se encontrou e executou um handler.
        """
        custom_id = inter.component.custom_id


        if custom_id in self._routes:
            await self._routes[custom_id](inter)
            return True


        for prefix, handler in self._prefix_routes.items():
            if custom_id.startswith(prefix):

                args_str = custom_id[len(prefix):]
                args = args_str.split(":") if args_str else []
                await handler(inter, *args)
                return True

        return False
