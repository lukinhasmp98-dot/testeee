import disnake

class Themes:
    @staticmethod
    def get_current_theme() -> str:
        return "default"

    @staticmethod
    def set_theme(theme: str) -> bool:
        return True

    @staticmethod
    def get_theme_data(theme: str | None = None) -> dict:
        return {
            "name": "Padrão",
            "description": "Tema limpo sem cores",
            "primary_color": None,
            "greeting": "Olá",
            "greeting_suffix": "",
        }

    @staticmethod
    def get_color(color_type: str, theme: str | None = None) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @staticmethod
    def get_primary_color(theme: str | None = None) -> disnake.Colour:
        return Themes.get_color("primary", theme)

    @staticmethod
    def get_greeting(username: str, theme: str | None = None) -> str:
        return f"Olá **{username}**"

    @staticmethod
    def get_available_themes() -> list:
        return ["default"]

    @staticmethod
    def get_all_themes_info() -> dict:
        return {"default": {"name": "Padrão", "description": "Tema único", "primary_color": None}}

    @staticmethod
    def get_container_kwargs(theme: str | None = None) -> dict:
        return {}
