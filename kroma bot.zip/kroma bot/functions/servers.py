import disnake
from functions.database import Database

class ServerManager:

    @staticmethod
    def get_server_id(context: str = "main") -> int:
        db_config = Database.get_document("server_settings") or {}

        if db_config.get(context):
            return int(db_config[context])

        local_config = Database.get_config("server_settings") or {}
        if local_config.get(context):
            return int(local_config[context])

        if context == "main":
            return int(Database.get_config("server_id") or 0)


        return ServerManager.get_server_id("main")

    @staticmethod
    def set_server_id(context: str, guild_id: int):
        db_config = Database.get_document("server_settings") or {}
        db_config[context] = str(guild_id)
        Database.save_document("server_settings", db_config)

        if context == "main":
            all_config = Database.get_config()
            all_config["server_id"] = str(guild_id)
            if "server_settings" not in all_config:
                all_config["server_settings"] = {}
            all_config["server_settings"]["main"] = str(guild_id)
            Database.save_config(all_config)

        all_config = Database.get_config()
        if "server_settings" not in all_config:
            all_config["server_settings"] = {}
        all_config["server_settings"][context] = str(guild_id)
        Database.save_config(all_config)

    @staticmethod
    def get_guild(bot, context: str = "main"):
        gid = ServerManager.get_server_id(context)
        if not gid:
            return None
        return bot.get_guild(gid)
