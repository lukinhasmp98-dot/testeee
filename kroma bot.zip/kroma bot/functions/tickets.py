import time
from functions.database import Database
from typing import Any

class TicketStatsManager:

    @staticmethod
    def get_stats() -> dict[str, Any]:
        stats = Database.get_document("tickets_stats") or {}
        tickets_data = Database.get_document("tickets_data") or {}
        open_tickets = 0
        by_panel = {}
        for panel_id, users in tickets_data.get("panels", {}).items():
            active = 0
            for tickets in users.values():
                active += sum(1 for ticket in tickets if ticket.get("status") == "open")
            by_panel[panel_id] = active
            open_tickets += active
        return {
            "total_created": stats.get("total_created", 0),
            "total_closed": stats.get("total_closed", 0),
            "open_now": open_tickets,
            "by_panel": by_panel,
            "updated_at": stats.get("updated_at"),
        }

    @staticmethod
    def add_ticket_created():
        stats = Database.get_document("tickets_stats") or {}
        stats["total_created"] = stats.get("total_created", 0) + 1
        stats["updated_at"] = int(time.time())
        Database.save_document("tickets_stats", stats)

    @staticmethod
    def add_ticket_closed():
        stats = Database.get_document("tickets_stats") or {}
        stats["total_closed"] = stats.get("total_closed", 0) + 1
        stats["updated_at"] = int(time.time())
        Database.save_document("tickets_stats", stats)
