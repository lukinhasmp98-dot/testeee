import asyncio

import disnake
from disnake.ext import commands

from .manager import VipManager
from .logger import VipLogger


_DISCORD_OP_DELAY = 0.3


class VipVoice(commands.Cog):
    """Voice Hub + canal pessoal VIP + limite dinâmico.
    - Entrar no voice_hub_channel_id cria (ou move pra) o canal pessoal.
    - Canal pessoal é criado na voiceCategoryId do plano.
    - dynamicLimit atualiza user_limit = len(members) + 1 (respeitando memberLimit como teto)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._creating: set[int] = set()

    async def _get_vip_for_channel(self, channel_id: int):
        return await VipManager.find_vip_by_channel(channel_id)

    def _plan_categories(self) -> set[int]:
        cats: set[int] = set()
        for plan in VipManager.get_plans():
            features = plan.get("features") or {}
            cat_id = features.get("voiceCategoryId") or plan.get("voiceCategoryId")
            if not cat_id:
                continue
            if isinstance(cat_id, list):
                for c in cat_id:
                    try:
                        cats.add(int(c))
                    except (TypeError, ValueError):
                        continue
            else:
                try:
                    cats.add(int(cat_id))
                except (TypeError, ValueError):
                    continue
        return cats

    async def _ensure_personal_channel(self, member: disnake.Member, data: dict) -> disnake.VoiceChannel | None:
        """Garante que o usuário tenha canal pessoal. Retorna o canal ou None."""
        features = VipManager.get_plan_features(data.get("plan"))
        if not features.get("voiceChannel"):
            return None

        guild = member.guild
        channel_id = data.get("channel_id")
        if channel_id:
            try:
                existing = guild.get_channel(int(channel_id))
            except (TypeError, ValueError):
                existing = None
            if existing:
                return existing
            data["channel_id"] = None

        cat_id = features.get("voiceCategoryId")
        if not cat_id:
            return None
        if isinstance(cat_id, list) and cat_id:
            cat_id = cat_id[0]
        try:
            category = guild.get_channel(int(cat_id))
        except (TypeError, ValueError):
            category = None
        if not category:
            return None

        locked = bool(data.get("locked"))
        hidden = bool(data.get("hidden"))
        overwrites = {
            guild.default_role: disnake.PermissionOverwrite(
                connect=False if locked else None,
                view_channel=False if hidden else None,
            ),
            member: disnake.PermissionOverwrite(
                connect=True,
                view_channel=True,
                manage_channels=True,
                move_members=True,
            ),
        }
        dynamic = features.get("dynamicLimit", True)
        member_limit = features.get("memberLimit", 5)
        initial_limit = 1 if dynamic else (member_limit or 0)
        try:
            channel = await guild.create_voice_channel(
                name=f"🎙️ {member.display_name}",
                category=category,
                overwrites=overwrites,
                user_limit=initial_limit,
            )
        except Exception as e:
            print(f"[VIP VOICE] Falha ao criar canal para {member.id}: {e}")
            return None

        await asyncio.sleep(_DISCORD_OP_DELAY)
        for uid in data.get("allowed_users") or []:
            if uid == member.id:
                continue
            target = guild.get_member(uid)
            if not target:
                continue
            try:
                await channel.set_permissions(target, connect=not locked, view_channel=True)
            except Exception:
                pass
            await asyncio.sleep(_DISCORD_OP_DELAY)

        data["channel_id"] = str(channel.id)
        VipManager.save_user_vip(member.id, data)
        try:
            await VipLogger.channel_created(self.bot, member, channel)
        except Exception:
            pass
        return channel

    async def _apply_dynamic_limit(self, channel: disnake.VoiceChannel):
        match = await self._get_vip_for_channel(channel.id)
        if not match:
            return
        _, data = match
        features = VipManager.get_plan_features(data.get("plan"))
        if not features.get("dynamicLimit", True):
            return
        current_members = len(channel.members)
        new_limit = current_members + 1
        member_limit = features.get("memberLimit")
        if member_limit:
            try:
                new_limit = min(new_limit, int(member_limit) + 1)
            except (TypeError, ValueError):
                pass
        if channel.user_limit != new_limit:
            try:
                await channel.edit(user_limit=new_limit, reason="VIP: limite dinâmico")
            except Exception as e:
                print(f"[VIP VOICE] Falha ao atualizar limite em {channel.id}: {e}")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: disnake.Member, before: disnake.VoiceState, after: disnake.VoiceState):
        if member.bot:
            return

        if after.channel and after.channel != before.channel:
            owner_data = VipManager.get_user_vip(member.id)
            if owner_data and owner_data.get("channel_id") and str(after.channel.id) == str(owner_data["channel_id"]):
                try:
                    from datetime import datetime
                    VipManager.merge_user_data(member.id, {"last_voice_activity_at": datetime.now().isoformat()})
                except Exception:
                    pass

        hub_id = VipManager.get_voice_hub()

        if hub_id and after.channel and after.channel.id == hub_id:
            if member.id in self._creating:
                return
            data = await VipManager.refresh_user_vip(member.id) or VipManager.get_user_vip(member.id)
            if not data or not data.get("status") or VipManager.is_expired(data):
                return

            self._creating.add(member.id)
            try:
                channel = await self._ensure_personal_channel(member, data)
                if channel:
                    try:
                        await member.move_to(channel, reason="VIP Voice Hub")
                    except Exception:
                        pass
            finally:
                self._creating.discard(member.id)
            return

        categories = self._plan_categories()
        affected: list[disnake.VoiceChannel] = []
        if before.channel and isinstance(before.channel, disnake.VoiceChannel) and before.channel.category_id in categories:
            affected.append(before.channel)
        if after.channel and isinstance(after.channel, disnake.VoiceChannel) and after.channel.category_id in categories:
            if after.channel not in affected:
                affected.append(after.channel)

        for channel in affected:
            await self._apply_dynamic_limit(channel)

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        data = VipManager.get_user_vip(member.id)
        if not data:
            return
        guild = member.guild
        channel_id = data.get("channel_id")
        if channel_id:
            try:
                channel = guild.get_channel(int(channel_id))
            except (TypeError, ValueError):
                channel = None
            if channel:
                try:
                    await channel.delete(reason="VIP: dono saiu do servidor")
                except Exception:
                    pass
                try:
                    await VipLogger.channel_deleted(self.bot, member, "dono saiu do servidor")
                except Exception:
                    pass
            data["channel_id"] = None
            VipManager.save_user_vip(member.id, data)


def setup(bot: commands.Bot):
    bot.add_cog(VipVoice(bot))
