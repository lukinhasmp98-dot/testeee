import asyncio
import re
import time
import urllib.parse

import aiohttp
import disnake
from disnake.ext import commands

from .manager import VipManager


_EMOJI_CUSTOM_RE = re.compile(r"<(a?):(\w+):(\d+)>")
_DISCORD_API = "https://discord.com/api/v10"

_PREMIUM_CACHE: dict[str, tuple[bool, float]] = {}
_PREMIUM_TTL = 300.0


async def _token_has_nitro(session: aiohttp.ClientSession, token: str) -> bool:
    """Cacheia premium_type do token por 5min. Retorna True só se premium_type > 0.
    Sem Nitro o Discord aceita o PUT do burst mas remove logo em seguida — então
    a gente nem tenta, cai direto pro fallback de reação normal."""
    now = time.time()
    cached = _PREMIUM_CACHE.get(token)
    if cached and cached[1] > now:
        return cached[0]
    try:
        async with session.get(
            f"{_DISCORD_API}/users/@me",
            headers={"Authorization": token, "User-Agent": "Mozilla/5.0"},
            timeout=aiohttp.ClientTimeout(total=6),
        ) as resp:
            if resp.status != 200:
                _PREMIUM_CACHE[token] = (False, now + 60)
                return False
            data = await resp.json()
            has = isinstance(data.get("premium_type"), int) and data["premium_type"] > 0
            _PREMIUM_CACHE[token] = (has, now + _PREMIUM_TTL)
            return has
    except Exception as e:
        print(f"[VIP SUPER_REACT] Erro ao checar Nitro: {e}")
        _PREMIUM_CACHE[token] = (False, now + 60)
        return False


def _emoji_url_part(emoji_str: str) -> str | None:
    """Formata o emoji pro path da URL da Discord API.
    Unicode: percent-encoded. Custom: name:id (sem encode)."""
    match = _EMOJI_CUSTOM_RE.match(emoji_str.strip())
    if match:
        return f"{match.group(2)}:{match.group(3)}"
    return urllib.parse.quote(emoji_str, safe="")


async def _apply_super_reaction(
    session: aiohttp.ClientSession,
    token: str,
    channel_id: int,
    message_id: int,
    emoji_str: str,
) -> bool:
    """Tenta aplicar burst/super reaction via user token.
    Endpoint: PUT /channels/:ch/messages/:msg/reactions/:emoji/@me?type=1
    Sem Nitro válido a chamada "sucede" e some — então pré-checamos premium."""
    emoji_part = _emoji_url_part(emoji_str)
    if not emoji_part:
        return False
    if not await _token_has_nitro(session, token):
        return False
    url = f"{_DISCORD_API}/channels/{channel_id}/messages/{message_id}/reactions/{emoji_part}/@me?type=1"
    try:
        async with session.put(
            url,
            headers={
                "Authorization": token,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            },
            timeout=aiohttp.ClientTimeout(total=8),
        ) as resp:
            if resp.status in (200, 204):
                return True
            body = await resp.text()
            print(f"[VIP SUPER_REACT] HTTP {resp.status}: {body[:200]}")
            return False
    except Exception as e:
        print(f"[VIP SUPER_REACT] Erro: {e}")
        return False


def _parse_emoji(emoji_str: str, bot: commands.Bot):
    """Converte string de emoji em algo aceitável por add_reaction.
    - Unicode: retorna a string pura.
    - Custom (<:nome:id> ou <a:nome:id>): retorna disnake.Emoji (se o bot conhece)
      ou disnake.PartialEmoji como fallback."""
    if not emoji_str:
        return None

    match = _EMOJI_CUSTOM_RE.match(emoji_str.strip())
    if not match:
        return emoji_str

    animated = match.group(1) == "a"
    name = match.group(2)
    try:
        eid = int(match.group(3))
    except (TypeError, ValueError):
        return None

    emoji_obj = bot.get_emoji(eid)
    if emoji_obj is not None:
        return emoji_obj

    try:
        return disnake.PartialEmoji(name=name, id=eid, animated=animated)
    except Exception:
        return None


class VipReactions(commands.Cog):
    """Listener on_message para reagir com emoji personalizado quando:
    - Um VIP ativo com customReaction.enabled=True é mencionado; ou
    - O trigger de texto aparece no conteúdo (case-insensitive, word boundary)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot:
            return
        if message.guild is None:
            return
        content = (message.content or "").lower()

        try:
            active = await VipManager.list_active_vips()
        except Exception as e:
            print(f"[VIP REACTIONS] Falha ao listar VIPs: {e}")
            return

        vip_infos = []
        for user_id, data in active:
            reaction = data.get("customReaction") or {}
            if not reaction.get("enabled"):
                continue
            emoji = reaction.get("emoji")
            if not emoji:
                continue
            trigger = (reaction.get("trigger") or "").strip().lower()
            vip_infos.append({
                "user_id": user_id,
                "emoji": emoji,
                "trigger": trigger,
                "super": bool(reaction.get("superReactionEnabled")),
            })

        if not vip_infos:
            return

        to_react: list[dict] = []
        seen: set = set()

        mentioned_ids = {m.id for m in message.mentions}
        for info in vip_infos:
            if info["user_id"] in mentioned_ids and info["emoji"] not in seen:
                to_react.append(info)
                seen.add(info["emoji"])

        if content:
            for info in vip_infos:
                if info["emoji"] in seen:
                    continue
                trig = info["trigger"]
                if not trig:
                    continue
                pattern = rf"\b{re.escape(trig)}\b"
                try:
                    if re.search(pattern, content):
                        to_react.append(info)
                        seen.add(info["emoji"])
                except Exception:
                    if trig in content:
                        to_react.append(info)
                        seen.add(info["emoji"])

        if not to_react:
            return

        config = VipManager.get_config()
        super_token = (config.get("super_reaction_token") or "").strip() or None
        session: aiohttp.ClientSession | None = None

        try:
            for i, info in enumerate(to_react):
                emoji_str = info["emoji"]
                wants_super = info.get("super") and super_token

                applied_super = False
                if wants_super:
                    if session is None:
                        session = aiohttp.ClientSession()
                    applied_super = await _apply_super_reaction(
                        session, super_token, message.channel.id, message.id, emoji_str
                    )

                if not applied_super:
                    emoji = _parse_emoji(emoji_str, self.bot)
                    if emoji is None:
                        continue
                    try:
                        await message.add_reaction(emoji)
                    except disnake.HTTPException as e:
                        print(f"[VIP REACTIONS] Falha add_reaction {emoji_str}: {e}")
                    except Exception as e:
                        print(f"[VIP REACTIONS] Erro inesperado add_reaction: {e}")

                if i < len(to_react) - 1:
                    await asyncio.sleep(0.25)
        finally:
            if session is not None:
                await session.close()


def setup(bot: commands.Bot):
    bot.add_cog(VipReactions(bot))
