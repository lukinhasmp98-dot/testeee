import asyncio

import disnake
from disnake.ext import commands

from functions.servers import ServerManager
from .manager import VipManager


_DISCORD_OP_DELAY = 0.3


class VipSync(commands.Cog):
    """Sincroniza cargos Discord com o estado registrado no banco.
    - on_ready: reaplica cargos para VIPs ativos que já estão no servidor
    - on_member_join: reaplica cargo quando um VIP ativo volta ao servidor"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._synced_once = False

    @commands.Cog.listener()
    async def on_ready(self):
        if self._synced_once:
            return
        self._synced_once = True
        try:
            await self._sync_all_active()
        except Exception as e:
            print(f"[VIP SYNC] Erro no sync inicial: {e}")

    async def _sync_all_active(self):
        guild = ServerManager.get_guild(self.bot, "main")
        if guild is None:
            guild = next(iter(self.bot.guilds), None)
        if guild is None:
            return

        try:
            active = await VipManager.list_active_vips()
        except Exception as e:
            print(f"[VIP SYNC] Erro ao listar VIPs: {e}")
            return

        for user_id, data in active:
            try:
                if VipManager.is_expired(data):
                    continue

                plan = VipManager.get_plan(data.get("plan"))
                if not plan or not plan.get("roleId"):
                    continue

                role = guild.get_role(int(plan["roleId"]))
                if not role:
                    continue

                member = guild.get_member(user_id)
                if not member:
                    continue

                if role not in member.roles:
                    try:
                        await member.add_roles(role, reason="VIP Sync: reaplicar cargo ativo")
                    except Exception as e:
                        print(f"[VIP SYNC] Falha ao adicionar cargo {role.id} a {user_id}: {e}")
                    await asyncio.sleep(_DISCORD_OP_DELAY)
            except Exception as e:
                print(f"[VIP SYNC] Falha ao sincronizar user_vip_{user_id}: {e}")

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        try:
            data = await VipManager.refresh_user_vip(member.id) or VipManager.get_user_vip(member.id)
            if not data or not data.get("status"):
                return
            if VipManager.is_expired(data):
                return

            plan = VipManager.get_plan(data.get("plan"))
            if not plan or not plan.get("roleId"):
                return

            role = member.guild.get_role(int(plan["roleId"]))
            if not role:
                return
            if role in member.roles:
                return

            try:
                await member.add_roles(role, reason="VIP Sync: retorno ao servidor")
            except Exception as e:
                print(f"[VIP SYNC] Falha ao reaplicar cargo VIP para {member.id}: {e}")
        except Exception as e:
            print(f"[VIP SYNC] Erro on_member_join {member.id}: {e}")


def setup(bot: commands.Bot):
    bot.add_cog(VipSync(bot))
