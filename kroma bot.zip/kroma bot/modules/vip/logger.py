import disnake
from datetime import datetime
from typing import Optional

from .manager import VipManager


_COLORS = {
    "activated": 0x57F287,
    "expired": 0xED4245,
    "restored": 0xFEE75C,
    "revoked": 0xED4245,
    "channel": 0x5865F2,
    "role": 0xEB459E,
    "group": 0xF5A623,
    "reaction": 0xFEE75C,
}


class VipLogger:
    """Envia embeds de eventos VIP pro canal configurado em vip_config.log_channel_id.
    NÃO grava no doc `vip_logs` — isso é responsabilidade do backend."""

    @staticmethod
    async def _send(bot, title: str, description: str, color: int, user: Optional[disnake.abc.User] = None):
        config = VipManager.get_config()
        chan_id = config.get("log_channel_id")
        if not chan_id:
            return

        try:
            channel = bot.get_channel(int(chan_id))
        except (TypeError, ValueError):
            return
        if channel is None:
            return

        header = f"# Log de Sistema\n-# VIP > **{title}**"
        components = [
            disnake.ui.TextDisplay(header),
            disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
            disnake.ui.TextDisplay(description),
        ]
        if user is not None:
            footer = f"Membro: {getattr(user, 'display_name', user.name)} ({user.id}) | {datetime.now().strftime('%d/%m/%Y %H:%M')}"
            components.append(disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small))
            components.append(disnake.ui.TextDisplay(f"-# {footer}"))

        try:
            container = disnake.ui.Container(*components, accent_colour=disnake.Colour(color))
        except TypeError:
            container = disnake.ui.Container(*components)

        try:
            await channel.send(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True),
            )
        except Exception as e:
            print(f"[VIP LOG ERROR] Falha ao enviar log: {e}")

    @staticmethod
    async def activated(bot, user, plan_name: str, duration_text: str, staff=None):
        staff_line = f"— Processado por: {staff.mention}" if staff else ""
        desc = (
            f"**Assinatura Ativada**\n"
            f"— Membro: {user.mention}\n"
            f"— Plano: `{plan_name}`\n"
            f"— Duração: `{duration_text}`\n"
            f"{staff_line}"
        )
        await VipLogger._send(bot, "Ativação de VIP", desc, _COLORS["activated"], user)

    @staticmethod
    async def expired(bot, user, plan_name: str):
        user_mention = user.mention if hasattr(user, "mention") else f"`{user}`"
        desc = (
            f"**Assinatura Expirada**\n"
            f"— Membro: {user_mention}\n"
            f"— Plano Anterior: `{plan_name}`\n"
            f"— Motivo: Final do período de vigência"
        )
        await VipLogger._send(bot, "Expiração de VIP", desc, _COLORS["expired"], user if hasattr(user, "id") else None)

    @staticmethod
    async def restored(bot, user, from_plan: str, to_plan: str):
        user_mention = user.mention if hasattr(user, "mention") else f"`{user}`"
        desc = (
            f"**Assinatura Restaurada do Histórico**\n"
            f"— Membro: {user_mention}\n"
            f"— Plano Anterior: `{from_plan}`\n"
            f"— Plano Atual: `{to_plan}`"
        )
        await VipLogger._send(bot, "Restauração de VIP", desc, _COLORS["restored"], user if hasattr(user, "id") else None)

    @staticmethod
    async def channel_created(bot, user, channel):
        channel_mention = channel.mention if hasattr(channel, "mention") else f"`{channel}`"
        desc = (
            f"**Canal VIP Criado**\n"
            f"— Membro: {user.mention}\n"
            f"— Canal: {channel_mention}"
        )
        await VipLogger._send(bot, "Canal VIP Criado", desc, _COLORS["channel"], user)

    @staticmethod
    async def channel_deleted(bot, user, reason: str = "VIP expirado"):
        user_mention = user.mention if hasattr(user, "mention") else f"`{user}`"
        desc = (
            f"**Canal VIP Removido**\n"
            f"— Membro: {user_mention}\n"
            f"— Motivo: `{reason}`"
        )
        await VipLogger._send(bot, "Canal VIP Removido", desc, _COLORS["channel"], user if hasattr(user, "id") else None)

    @staticmethod
    async def role_created(bot, user, role):
        role_mention = role.mention if hasattr(role, "mention") else f"`{role}`"
        desc = (
            f"**Cargo Personalizado Criado**\n"
            f"— Membro: {user.mention}\n"
            f"— Cargo: {role_mention}"
        )
        await VipLogger._send(bot, "Cargo Personalizado Criado", desc, _COLORS["role"], user)

    @staticmethod
    async def role_deleted(bot, user, role_name: str, reason: str = "VIP expirado"):
        user_mention = user.mention if hasattr(user, "mention") else f"`{user}`"
        desc = (
            f"**Cargo Personalizado Removido**\n"
            f"— Membro: {user_mention}\n"
            f"— Cargo: `{role_name}`\n"
            f"— Motivo: `{reason}`"
        )
        await VipLogger._send(bot, "Cargo Personalizado Removido", desc, _COLORS["role"], user if hasattr(user, "id") else None)

    @staticmethod
    async def member_added_group(bot, owner, target, scope: str):
        desc = (
            f"**Membro Adicionado ao Grupo VIP**\n"
            f"— Dono: {owner.mention}\n"
            f"— Alvo: {target.mention}\n"
            f"— Escopo: `{scope}`"
        )
        await VipLogger._send(bot, "Grupo VIP — Adição", desc, _COLORS["group"], owner)

    @staticmethod
    async def member_removed_group(bot, owner, target, scope: str):
        target_mention = target.mention if hasattr(target, "mention") else f"`{target}`"
        desc = (
            f"**Membro Removido do Grupo VIP**\n"
            f"— Dono: {owner.mention}\n"
            f"— Alvo: {target_mention}\n"
            f"— Escopo: `{scope}`"
        )
        await VipLogger._send(bot, "Grupo VIP — Remoção", desc, _COLORS["group"], owner)

    @staticmethod
    async def reaction_enabled(bot, user, emoji: str, trigger: str):
        desc = (
            f"**Reação Personalizada Ativada**\n"
            f"— Membro: {user.mention}\n"
            f"— Emoji: {emoji}\n"
            f"— Gatilho: `{trigger}`"
        )
        await VipLogger._send(bot, "Reação VIP Ativada", desc, _COLORS["reaction"], user)

    @staticmethod
    async def reaction_disabled(bot, user):
        desc = (
            f"**Reação Personalizada Desativada**\n"
            f"— Membro: {user.mention}"
        )
        await VipLogger._send(bot, "Reação VIP Desativada", desc, _COLORS["reaction"], user)

    @staticmethod
    async def revoked(bot, user, plan_name: str, staff=None):
        staff_line = f"— Executado por: {staff.mention}" if staff else "— Executado por: Sistema"
        user_mention = user.mention if hasattr(user, "mention") else f"`{user}`"
        desc = (
            f"**Assinatura Revogada**\n"
            f"— Membro: {user_mention}\n"
            f"— Plano: `{plan_name}`\n"
            f"{staff_line}"
        )
        await VipLogger._send(bot, "Revogação de VIP", desc, _COLORS["revoked"], user if hasattr(user, "id") else None)
