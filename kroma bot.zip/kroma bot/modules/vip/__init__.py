def setup(bot):
    bot.load_extension("modules.vip.expiration")
    bot.load_extension("modules.vip.sync")
    bot.load_extension("modules.vip.commands")
    bot.load_extension("modules.vip.voice")
    bot.load_extension("modules.vip.protection")
    bot.load_extension("modules.vip.reactions")
    bot.load_extension("modules.vip.warnings")
