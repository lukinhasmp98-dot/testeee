import asyncio
from datetime import datetime

import disnake
from disnake.ext import commands, tasks

from functions.servers import ServerManager
from .manager import VipManager
from .logger import VipLogger


_DISCORD_OP_DELAY = 0.3


class VipExpiration(commands.Cog):
    """Loop que expira VIPs vencidos e restaura do histórico quando possível."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.expiration_loop.is_running():
            self.expiration_loop.start()

    def cog_unload(self):
        self.expiration_loop.cancel()

    @tasks.loop(minutes=15)
    async def expiration_loop(self):
        try:
            active = await VipManager.list_active_vips()
        except Exception as e:
            print(f"[VIP EXPIRATION] Erro ao listar VIPs: {e}")
            return

        if not active:
            return

        guild = ServerManager.get_guild(self.bot, "main")
        now = datetime.now()

        for user_id, data in active:
            try:
                if not VipManager.is_expired(data):
                    continue

                expired_plan_key = data.get("plan")
                expired_plan = VipManager.get_plan(expired_plan_key)
                expired_role_id = expired_plan.get("roleId") if expired_plan else None
                expired_plan_name = (expired_plan or {}).get("displayName") or expired_plan_key or "desconhecido"

                member = None
                if guild:
                    member = guild.get_member(user_id)
                    if not member:
                        try:
                            member = await guild.fetch_member(user_id)
                        except (disnake.NotFound, disnake.Forbidden):
                            member = None

                if member and expired_role_id:
                    role = guild.get_role(int(expired_role_id))
                    if role and role in member.roles:
                        try:
                            await member.remove_roles(role, reason="VIP expirado")
                        except Exception as e:
                            print(f"[VIP EXPIRATION] Falha ao remover cargo {role.id} de {user_id}: {e}")
                        await asyncio.sleep(_DISCORD_OP_DELAY)

                channel_id = data.get("channel_id")
                if guild and channel_id:
                    try:
                        channel = guild.get_channel(int(channel_id))
                    except (TypeError, ValueError):
                        channel = None
                    if channel:
                        try:
                            await channel.delete(reason="VIP expirado")
                            target_user = member or self.bot.get_user(user_id)
                            if target_user:
                                await VipLogger.channel_deleted(self.bot, target_user, "VIP expirado")
                        except Exception as e:
                            print(f"[VIP EXPIRATION] Falha ao deletar canal {channel_id}: {e}")
                        await asyncio.sleep(_DISCORD_OP_DELAY)
                    data["channel_id"] = None

                custom_role_id = data.get("custom_role_id")
                if guild and custom_role_id:
                    try:
                        custom_role = guild.get_role(int(custom_role_id))
                    except (TypeError, ValueError):
                        custom_role = None
                    if custom_role:
                        role_name = custom_role.name
                        try:
                            await custom_role.delete(reason="VIP expirado")
                            target_user = member or self.bot.get_user(user_id)
                            if target_user:
                                await VipLogger.role_deleted(self.bot, target_user, role_name, "VIP expirado")
                        except Exception as e:
                            print(f"[VIP EXPIRATION] Falha ao deletar cargo personalizado {custom_role_id}: {e}")
                        await asyncio.sleep(_DISCORD_OP_DELAY)
                    data["custom_role_id"] = None

                data["allowed_users"] = []
                data["role_members"] = []
                data["role_color"] = None
                data["locked"] = False
                data["hidden"] = False
                data["customReaction"] = {"enabled": False, "emoji": None, "trigger": None, "superReactionEnabled": False}

                restored_plan = None
                history = data.get("history") or []
                while history:
                    prev = history.pop()
                    if not isinstance(prev, dict):
                        continue

                    is_valid = False
                    if prev.get("is_permanent"):
                        is_valid = True
                    elif prev.get("expires_at"):
                        try:
                            if datetime.fromisoformat(prev["expires_at"]) > now:
                                is_valid = True
                        except (TypeError, ValueError):
                            pass

                    if is_valid:
                        restored_plan = prev
                        break

                if restored_plan:
                    data.update({
                        "status": True,
                        "plan": restored_plan.get("plan"),
                        "expires_at": restored_plan.get("expires_at"),
                        "is_permanent": restored_plan.get("is_permanent", False),
                        "history": history,
                        "last_updated": now.isoformat(),
                    })
                    new_plan = VipManager.get_plan(restored_plan.get("plan"))
                    new_plan_name = (new_plan or {}).get("displayName") or restored_plan.get("plan") or "desconhecido"

                    if member and new_plan and new_plan.get("roleId"):
                        role = guild.get_role(int(new_plan["roleId"]))
                        if role and role not in member.roles:
                            try:
                                await member.add_roles(role, reason="VIP restaurado do histórico")
                            except Exception as e:
                                print(f"[VIP EXPIRATION] Falha ao adicionar cargo {role.id} para {user_id}: {e}")
                            await asyncio.sleep(_DISCORD_OP_DELAY)

                    VipManager.save_user_vip(user_id, data)
                    target = member or self.bot.get_user(user_id)
                    if target is None:
                        try:
                            target = await self.bot.fetch_user(user_id)
                        except Exception:
                            target = None
                    if target:
                        await VipLogger.restored(self.bot, target, expired_plan_name, new_plan_name)
                else:
                    data["status"] = False
                    data["history"] = []
                    data["last_updated"] = now.isoformat()
                    VipManager.save_user_vip(user_id, data)

                    target = member or self.bot.get_user(user_id)
                    if target is None:
                        try:
                            target = await self.bot.fetch_user(user_id)
                        except Exception:
                            target = None
                    if target:
                        await VipLogger.expired(self.bot, target, expired_plan_name)

                await asyncio.sleep(_DISCORD_OP_DELAY)
            except Exception as e:
                print(f"[VIP EXPIRATION] Falha ao processar user_vip_{user_id}: {e}")

    @expiration_loop.before_loop
    async def before_expiration_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(VipExpiration(bot))
