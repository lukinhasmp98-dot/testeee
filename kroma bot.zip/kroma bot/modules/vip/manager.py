from datetime import datetime
from typing import Optional

from functions.database import Database
from connections import mongo_db


class VipManager:
    """Helpers de leitura/escrita do sistema VIP.
    Backend é quem atribui/revoga; o bot apenas reflete o estado e aplica cargos."""

    @staticmethod
    def get_plans() -> list:
        data = Database.get_document("vip_plans")
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get("items", [])
        return []

    @staticmethod
    def get_plan(key: str) -> Optional[dict]:
        if not key:
            return None
        for plan in VipManager.get_plans():
            if plan.get("key") == key:
                return plan
        return None

    @staticmethod
    def get_user_vip(user_id: int) -> Optional[dict]:
        doc_id = f"user_vip_{user_id}"
        data = Database.get_document(doc_id)
        if not data:
            return None
        return data

    @staticmethod
    async def refresh_user_vip(user_id: int) -> Optional[dict]:
        """Força refresh do doc no MongoDB e retorna o valor mais recente.
        Usar quando precisar de dado fresco (ex.: painel admin, context menu)."""
        doc_id = f"user_vip_{user_id}"
        data = await Database.refresh_document(doc_id)
        return data or None

    @staticmethod
    def save_user_vip(user_id: int, data: dict):
        doc_id = f"user_vip_{user_id}"
        Database.save_document(doc_id, data)

    @staticmethod
    async def list_active_vips() -> list:
        """Lista tuplas (user_id, data) de todos os VIPs com status=True.
        Consulta direta ao MongoDB — docs de VIP são criados dinamicamente pelo backend
        e nem sempre estão no cache RAM."""
        coll = mongo_db.bot_collection
        if coll is None:
            mongo_db.init_connection()
            coll = mongo_db.bot_collection
        if coll is None:
            return []

        results = []
        try:
            cursor = coll.find({"_id": {"$regex": "^user_vip_"}})
            async for doc in cursor:
                _id = doc.pop("_id", "")
                try:
                    user_id = int(str(_id).replace("user_vip_", ""))
                except (TypeError, ValueError):
                    continue

                if len(doc) == 1 and "items" in doc:
                    data = doc["items"]
                else:
                    data = doc

                if not isinstance(data, dict):
                    continue
                if not data.get("status"):
                    continue

                Database._cache[_id] = data
                results.append((user_id, data))
        except Exception as e:
            print(f"[VIP MANAGER] Erro ao listar VIPs ativos: {e}")
            return []

        return results

    @staticmethod
    def get_config() -> dict:
        return Database.get_document("vip_config") or {}

    @staticmethod
    def get_panel_config() -> dict:
        raw = Database.get_document("vip_panel_config") or {}
        defaults = {
            "content": "Bem-vindo {user}!\n**Plano:** {plan}\n**Expira:** {expires}",
            "show_info_buttons": True,
            "show_help_button": False,
            "help_ticket_panel": None,
        }
        merged = {**defaults, **(raw if isinstance(raw, dict) else {})}
        return merged

    @staticmethod
    def get_voice_hub() -> Optional[int]:
        config = VipManager.get_config()
        raw = config.get("voice_hub_channel_id")
        if not raw:
            return None
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None

    _DEFAULT_FEATURES = {
        "voiceChannel": False,
        "voiceCategoryId": None,
        "dynamicLimit": True,
        "memberLimit": 5,
        "customRole": False,
        "roleMemberLimit": 3,
        "mentionReaction": False,
    }

    @staticmethod
    def get_plan_features(plan_key: str) -> dict:
        plan = VipManager.get_plan(plan_key) or {}
        features = dict(VipManager._DEFAULT_FEATURES)
        features.update(plan.get("features") or {})
        return features

    @staticmethod
    def merge_user_data(user_id: int, patch: dict) -> dict:
        """Merge shallow no doc VIP do usuário e salva.
        Retorna o doc atualizado."""
        current = VipManager.get_user_vip(user_id) or {}
        current.update(patch or {})
        VipManager.save_user_vip(user_id, current)
        return current

    @staticmethod
    async def find_vip_by_channel(channel_id: int) -> Optional[tuple]:
        """Encontra o dono VIP de um canal. Retorna (user_id, data) ou None."""
        try:
            active = await VipManager.list_active_vips()
        except Exception:
            return None
        for user_id, data in active:
            cid = data.get("channel_id")
            if cid and str(cid) == str(channel_id):
                return user_id, data
        return None

    @staticmethod
    async def find_vip_by_role(role_id: int) -> Optional[tuple]:
        try:
            active = await VipManager.list_active_vips()
        except Exception:
            return None
        for user_id, data in active:
            rid = data.get("custom_role_id")
            if rid and str(rid) == str(role_id):
                return user_id, data
        return None

    @staticmethod
    def is_expired(data: dict) -> bool:
        if not data:
            return False
        if not data.get("status"):
            return False
        if data.get("is_permanent"):
            return False
        expires_at = data.get("expires_at")
        if not expires_at:
            return False
        try:
            expiry_dt = datetime.fromisoformat(expires_at)
        except (TypeError, ValueError):
            return False
        return datetime.now() >= expiry_dt
