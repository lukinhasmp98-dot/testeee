import asyncio
from datetime import datetime, timedelta

import disnake
from disnake.ext import commands, tasks

from functions.database import Database
from functions.servers import ServerManager
from .manager import VipManager


class VipWarnings(commands.Cog):
    """Avisos de expiração via DM + cleanup de canais VIP inativos.
    Config vem de `vip_config`:
      - expiration_warning_enabled: bool
      - expiration_warning_days: [int]
      - auto_cleanup_inactive_days: int (0 = desativado)"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.hourly_loop.is_running():
            self.hourly_loop.start()

    def cog_unload(self):
        self.hourly_loop.cancel()

    @tasks.loop(hours=1)
    async def hourly_loop(self):
        try:
            await self._send_expiration_warnings()
        except Exception as e:
            print(f"[VIP WARNINGS] expiration loop erro: {e}")
        try:
            await self._cleanup_inactive_channels()
        except Exception as e:
            print(f"[VIP WARNINGS] cleanup loop erro: {e}")

    @hourly_loop.before_loop
    async def before_hourly(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(30)

    async def _send_expiration_warnings(self):
        config = VipManager.get_config() or {}
        if not config.get("expiration_warning_enabled"):
            return
        days_list = config.get("expiration_warning_days") or [7, 3, 1]
        if not days_list:
            return

        today = datetime.now().date().isoformat()

        try:
            active = await VipManager.list_active_vips()
        except Exception as e:
            print(f"[VIP WARNINGS] list_active_vips: {e}")
            return

        for user_id, data in active:
            if data.get("is_permanent"):
                continue
            expires_at = data.get("expires_at")
            if not expires_at:
                continue
            try:
                dt = datetime.fromisoformat(expires_at)
            except (TypeError, ValueError):
                continue

            delta = dt - datetime.now()
            if delta.total_seconds() <= 0:
                continue
            days_until = int(delta.total_seconds() // 86400)
            if delta.total_seconds() % 86400:
                days_until += 1

            if days_until not in days_list:
                continue

            last_warned = data.get("last_warning_sent") or ""
            marker = f"{today}:{days_until}"
            if last_warned == marker:
                continue

            user = self.bot.get_user(user_id)
            if user is None:
                try:
                    user = await self.bot.fetch_user(user_id)
                except Exception:
                    user = None
            if user is None:
                continue

            plan_key = data.get("plan")
            plan = VipManager.get_plan(plan_key) if plan_key else None
            plan_name = (plan or {}).get("displayName") or plan_key or "VIP"

            text = (
                f"⏰ **Aviso VIP**\n\n"
                f"Seu plano **{plan_name}** expira em **{days_until}** {'dia' if days_until == 1 else 'dias'}.\n"
                f"Renove pra não perder os benefícios."
            )
            try:
                await user.send(content=text)
            except Exception as e:
                print(f"[VIP WARNINGS] DM falhou pra {user_id}: {e}")
                continue

            try:
                VipManager.merge_user_data(user_id, {"last_warning_sent": marker})
            except Exception as e:
                print(f"[VIP WARNINGS] merge last_warning_sent falhou: {e}")

            await asyncio.sleep(0.3)

    async def _cleanup_inactive_channels(self):
        config = VipManager.get_config() or {}
        threshold_days = config.get("auto_cleanup_inactive_days") or 0
        if threshold_days <= 0:
            return

        guild_id = ServerManager.get_server_id("main")
        guild = self.bot.get_guild(guild_id) if guild_id else None
        if guild is None:
            for g in self.bot.guilds:
                guild = g
                break
        if guild is None:
            return

        try:
            active = await VipManager.list_active_vips()
        except Exception:
            return

        cutoff = datetime.now() - timedelta(days=threshold_days)
        cutoff_iso = cutoff.isoformat()

        for user_id, data in active:
            channel_id = data.get("channel_id")
            if not channel_id:
                continue
            last_activity = data.get("last_voice_activity_at")
            if not last_activity:
                continue
            if last_activity >= cutoff_iso:
                continue

            try:
                channel = guild.get_channel(int(channel_id))
            except (TypeError, ValueError):
                channel = None

            if channel is not None:
                try:
                    await channel.delete(reason=f"VIP inativo há +{threshold_days} dias")
                except disnake.HTTPException as e:
                    print(f"[VIP WARNINGS] cleanup canal {channel_id} falhou: {e}")

            try:
                VipManager.merge_user_data(user_id, {
                    "channel_id": None,
                    "allowed_users": [],
                    "locked": False,
                    "hidden": False,
                })
            except Exception as e:
                print(f"[VIP WARNINGS] merge cleanup falhou: {e}")

            await asyncio.sleep(0.3)


def setup(bot: commands.Bot):
    bot.add_cog(VipWarnings(bot))
