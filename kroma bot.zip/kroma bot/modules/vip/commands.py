import asyncio
import re
from datetime import datetime

import disnake
from disnake.ext import commands

from functions.database import Database
from functions.components_v2_renderer import render_components_v2
from .manager import VipManager
from .logger import VipLogger


DASHBOARD_URL = "https://vyeapps.com"
_DISCORD_OP_DELAY = 0.3
_FEEDBACK_TIMEOUT_SEC = 4.0
_feedback_tasks: dict[int, asyncio.Task] = {}

_EMOJI_CUSTOM_RE = re.compile(r"<(a?):(\w+):(\d+)>")

_PAGE_DEFAULTS: dict[str, str] = {
    "main": "Bem-vindo {user}!\n**Plano:** {plan}\n**Expira:** {expires}",
    "call": "## Painel VIP — Call",
    "call_group": "## Painel VIP — Grupo da Call",
    "custom_role": "## Painel VIP — Cargo",
    "custom_role_group": "## Painel VIP — Grupo do Cargo",
    "reaction": "## Painel VIP — Reação",
}

_NAV_DEFAULTS: dict[str, tuple[str, str]] = {
    "main": ("Visão geral", "Resumo do plano"),
    "call": ("Minha call", "Gerencie seu canal de voz VIP"),
    "custom_role": ("Meu cargo", "Personalize seu cargo"),
    "reaction": ("Minha reação", "Reação custom em menções"),
}


def _days_remaining(expires_at: str) -> int | None:
    if not expires_at:
        return None
    try:
        dt = datetime.fromisoformat(expires_at)
    except (TypeError, ValueError):
        return None
    delta = dt - datetime.now()
    if delta.total_seconds() <= 0:
        return 0
    return max(1, int(delta.total_seconds() // 86400) + (1 if delta.total_seconds() % 86400 else 0))


def _format_expiry(data: dict) -> str:
    if data.get("is_permanent"):
        return "Permanente"
    days = _days_remaining(data.get("expires_at"))
    if days is None:
        return "Sem data"
    if days <= 0:
        return "Expirado"
    return f"{days} dia(s) restante(s)"


def _dashboard_vip_url() -> str:
    app_id = Database.get_config("bot_id") or ""
    if not app_id or app_id == "REPLACE_WITH_APP_ID":
        return f"{DASHBOARD_URL}/dashboard"
    return f"{DASHBOARD_URL}/dashboard/app/{app_id}/vip"


def _is_active_vip(data: dict | None) -> bool:
    if not data or not data.get("status"):
        return False
    return not VipManager.is_expired(data)


def _back_row(custom_id: str) -> disnake.ui.ActionRow:
    return disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Voltar",
            style=disnake.ButtonStyle.grey,
            custom_id=custom_id,
        )
    )


def _feedback_container(text: str, success: bool = True) -> disnake.ui.Container:
    color = 0x57F287 if success else 0xED4245
    prefix = "Sucesso" if success else "Atenção"
    try:
        return disnake.ui.Container(
            disnake.ui.TextDisplay(f"**{prefix}:** {text}"),
            accent_colour=disnake.Colour(color),
        )
    except TypeError:
        return disnake.ui.Container(disnake.ui.TextDisplay(f"**{prefix}:** {text}"))


def _render_panel_content(template: str, user: disnake.abc.User, data: dict | None, plan: dict | None) -> str:
    """Processa placeholders {user}, {plan}, {expires}, {days_left} no template."""
    plan_name = (plan or {}).get("displayName") or (data or {}).get("plan") or "—"
    expires_text = _format_expiry(data) if data else "—"
    days_left = _days_remaining((data or {}).get("expires_at"))
    days_left_str = "∞" if (data or {}).get("is_permanent") else (str(days_left) if days_left is not None else "—")
    return (
        template
        .replace("{user}", user.mention)
        .replace("{plan}", str(plan_name))
        .replace("{expires}", expires_text)
        .replace("{days_left}", days_left_str)
    )


def _page_custom_content(page_name: str) -> str | None:
    """Retorna o content customizado bruto (sem placeholders processados) ou None."""
    panel_cfg = VipManager.get_panel_config() or {}
    pages = panel_cfg.get("pages") or {}
    page = pages.get(page_name) or {}
    content = page.get("content")
    if isinstance(content, str) and content.strip():
        return content
    return None


def _page_components_v2(page_name: str) -> list | None:
    """Retorna o schema components_v2 customizado da página ou None."""
    panel_cfg = VipManager.get_panel_config() or {}
    pages = panel_cfg.get("pages") or {}
    page = pages.get(page_name) or {}
    schema = page.get("components_v2")
    if isinstance(schema, list) and schema:
        return schema
    return None


def _vip_placeholders(user: disnake.abc.User, data: dict | None, plan: dict | None) -> dict[str, str]:
    """Monta dict de placeholders padrão do painel VIP pra usar no renderer."""
    plan_name = (plan or {}).get("displayName") or (data or {}).get("plan") or "—"
    expires_text = _format_expiry(data) if data else "—"
    days_left = _days_remaining((data or {}).get("expires_at"))
    days_left_str = "∞" if (data or {}).get("is_permanent") else (str(days_left) if days_left is not None else "—")
    return {
        "user": user.mention,
        "username": getattr(user, "display_name", None) or user.name,
        "plan": str(plan_name),
        "expires": expires_text,
        "days_left": days_left_str,
    }


def _call_placeholders(user, data: dict, plan: dict | None, guild, features: dict) -> dict[str, str]:
    base = _vip_placeholders(user, data, plan)
    channel_id = data.get("channel_id")
    channel = None
    if guild and channel_id:
        try:
            channel = guild.get_channel(int(channel_id))
        except (TypeError, ValueError):
            channel = None
    base.update({
        "channel": channel.mention if channel else "*nenhum canal criado*",
        "privacy": "Trancado" if data.get("locked") else "Aberto",
        "visibility": "Oculto" if data.get("hidden") else "Visível",
        "member_limit": str(features.get("memberLimit", 5)),
    })
    return base


def _format_members_list(uids: list, guild) -> str:
    if not uids:
        return "*Nenhum membro autorizado.*"
    out = []
    for uid in uids:
        member = guild.get_member(uid) if guild else None
        out.append(f"- {member.mention if member else f'`ID: {uid}`'}")
    return "\n".join(out)


def _call_group_placeholders(user, data: dict, plan: dict | None, guild, features: dict) -> dict[str, str]:
    base = _vip_placeholders(user, data, plan)
    limit = features.get("memberLimit", 5)
    allowed = [uid for uid in (data.get("allowed_users") or []) if uid != user.id]
    base.update({
        "member_count": str(len(allowed)),
        "member_limit": str(limit),
        "members_list": _format_members_list(allowed, guild),
    })
    return base


def _custom_role_placeholders(user, data: dict, plan: dict | None, guild, features: dict) -> dict[str, str]:
    base = _vip_placeholders(user, data, plan)
    role_id = data.get("custom_role_id")
    role = None
    if guild and role_id:
        try:
            role = guild.get_role(int(role_id))
        except (TypeError, ValueError):
            role = None
    base.update({
        "role": role.mention if role else "*sem cargo*",
        "role_name": role.name if role else "—",
        "role_color": (f"#{role.color.value:06X}" if role and role.color else "—"),
        "role_members": str(len(data.get("role_members") or [])),
        "role_member_limit": str(features.get("roleMemberLimit", 3)),
    })
    return base


def _custom_role_group_placeholders(user, data: dict, plan: dict | None, guild, features: dict) -> dict[str, str]:
    base = _vip_placeholders(user, data, plan)
    limit = features.get("roleMemberLimit", 3)
    members = [uid for uid in (data.get("role_members") or []) if uid != user.id]
    base.update({
        "member_count": str(len(members)),
        "member_limit": str(limit),
        "members_list": _format_members_list(members, guild),
    })
    return base


def _reaction_placeholders(user, data: dict, plan: dict | None) -> dict[str, str]:
    base = _vip_placeholders(user, data, plan)
    reaction_data = data.get("customReaction") or {}
    base.update({
        "status": "Ativado" if reaction_data.get("enabled") else "Desativado",
        "super_status": "Ativado" if reaction_data.get("superReactionEnabled") else "Desativado",
        "emoji": reaction_data.get("emoji") or "*não configurado*",
        "trigger": reaction_data.get("trigger") or "*não configurado*",
    })
    return base


def _page_content(page_name: str, user: disnake.abc.User, data: dict | None, plan: dict | None) -> str:
    """Resolve content customizado ou fallback default, já com placeholders processados."""
    template = _page_custom_content(page_name) or _PAGE_DEFAULTS.get(page_name, "")
    return _render_panel_content(template, user, data, plan)


def _page_content_optional(page_name: str, user: disnake.abc.User, data: dict | None, plan: dict | None) -> str | None:
    """Retorna o content customizado renderizado ou None quando admin não customizou.
    Usado em páginas com corpo dinâmico (call, cargo, reação) pra prepend."""
    template = _page_custom_content(page_name)
    if template is None:
        return None
    return _render_panel_content(template, user, data, plan)


def _parse_nav_emoji(emoji_str: str):
    """Converte emoji string pra algo aceitável em SelectOption.emoji.
    - Unicode: string direta
    - Custom <a?:name:id>: PartialEmoji"""
    if not emoji_str:
        return None
    m = _EMOJI_CUSTOM_RE.match(emoji_str.strip())
    if not m:
        return emoji_str
    try:
        return disnake.PartialEmoji(
            name=m.group(2),
            id=int(m.group(3)),
            animated=m.group(1) == "a",
        )
    except Exception:
        return None


def _member_remove_option(guild, uid: int) -> disnake.SelectOption:
    """Constrói a opção pra remover um membro do grupo — com ID/username como descrição."""
    member = guild.get_member(uid) if guild else None
    if member:
        label = member.display_name[:25] or f"ID: {uid}"
        description = f"@{member.name} · {uid}"[:100]
    else:
        label = f"ID: {uid}"[:25]
        description = f"Fora do servidor · {uid}"[:100]
    return disnake.SelectOption(label=label, value=str(uid), description=description)


def _nav_option(page_name: str, default_label: str, default_desc: str) -> disnake.SelectOption:
    """Monta SelectOption do dropdown de navegação usando panel_cfg.pages overrides."""
    panel_cfg = VipManager.get_panel_config() or {}
    pages = panel_cfg.get("pages") or {}
    page = pages.get(page_name) or {}
    label = (page.get("label") or "").strip() or default_label
    description = (page.get("description") or "").strip() or default_desc
    emoji_raw = (page.get("emoji") or "").strip()

    kwargs: dict = {
        "label": label[:80],
        "value": page_name,
        "description": description[:100],
    }
    if emoji_raw:
        emoji_obj = _parse_nav_emoji(emoji_raw)
        if emoji_obj is not None:
            kwargs["emoji"] = emoji_obj
    return disnake.SelectOption(**kwargs)


def _main_page(user: disnake.abc.User, data: dict | None) -> list:
    panel_cfg = VipManager.get_panel_config()
    plan = VipManager.get_plan((data or {}).get("plan")) if data else None

    if not _is_active_vip(data):
        header = f"## Painel VIP\n-# {user.mention}"
        body = (
            "Você ainda não possui VIP ativo.\n\n"
            "-# Confira os planos disponíveis através do nosso portal."
        )
        plans = VipManager.get_plans()
        if plans:
            lines = ["**Planos disponíveis:**"]
            for p in plans[:6]:
                emoji = p.get("emoji") or ""
                name = p.get("displayName") or p.get("key") or "Plano"
                lines.append(f"-# {emoji} {name}")
            body = f"{body}\n\n" + "\n".join(lines)
        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(header),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(body),
            )
        ]

    plan_name = (plan or {}).get("displayName") or (data or {}).get("plan") or "desconhecido"
    features = VipManager.get_plan_features((data or {}).get("plan"))

    # Nav dropdown (reusado em qualquer modo de render)
    options = [_nav_option("main", *_NAV_DEFAULTS["main"])]
    if features.get("voiceChannel"):
        options.append(_nav_option("call", *_NAV_DEFAULTS["call"]))
    if features.get("customRole"):
        options.append(_nav_option("custom_role", *_NAV_DEFAULTS["custom_role"]))
    if features.get("mentionReaction"):
        options.append(_nav_option("reaction", *_NAV_DEFAULTS["reaction"]))

    nav_row = disnake.ui.ActionRow(
        disnake.ui.StringSelect(
            custom_id="VipUser_Navigation",
            placeholder="Escolha uma área para gerenciar...",
            options=options,
        )
    )

    # ─── Render V2 (builder do dashboard) tem prioridade ───
    custom_schema = _page_components_v2("main")
    if custom_schema:
        placeholders = _vip_placeholders(user, data, plan)
        rendered = render_components_v2(custom_schema, placeholders)
        if rendered:
            return rendered + [nav_row]

    template = (
        _page_custom_content("main")
        or panel_cfg.get("content")
        or _PAGE_DEFAULTS["main"]
    )
    rendered_body = _render_panel_content(template, user, data, plan)

    container = disnake.ui.Container(disnake.ui.TextDisplay(rendered_body))
    return [container, nav_row]


def _call_page(guild, user, data: dict) -> list:
    features = VipManager.get_plan_features(data.get("plan"))
    plan = VipManager.get_plan(data.get("plan"))
    channel_id = data.get("channel_id")
    channel = None
    if guild and channel_id:
        try:
            channel = guild.get_channel(int(channel_id))
        except (TypeError, ValueError):
            channel = None

    locked = bool(data.get("locked"))
    hidden = bool(data.get("hidden"))

    if not channel:
        buttons = disnake.ui.ActionRow(
            disnake.ui.Button(label="Criar canal", style=disnake.ButtonStyle.green, custom_id="VipUser_CreateChannel"),
        )
    else:
        buttons = disnake.ui.ActionRow(
            disnake.ui.Button(label="Editar nome", style=disnake.ButtonStyle.grey, custom_id="VipUser_EditName"),
            disnake.ui.Button(
                label="Destrancar" if locked else "Trancar",
                style=disnake.ButtonStyle.green if locked else disnake.ButtonStyle.red,
                custom_id="VipUser_ToggleLock",
            ),
            disnake.ui.Button(
                label="Mostrar" if hidden else "Ocultar",
                style=disnake.ButtonStyle.blurple,
                custom_id="VipUser_ToggleVisibility",
            ),
            disnake.ui.Button(label="Gerenciar grupo", style=disnake.ButtonStyle.secondary, custom_id="VipUser_CallGroup"),
        )

    custom_schema = _page_components_v2("call")
    if custom_schema:
        rendered = render_components_v2(custom_schema, _call_placeholders(user, data, plan, guild, features))
        if rendered:
            return [_back_row("VipUser_BackToMain"), *rendered, buttons]

    channel_text = channel.mention if channel else "*nenhum canal criado*"
    body = (
        f"**Minha Call**\n"
        f"— Canal: {channel_text}\n"
        f"— Privacidade: `{'Trancado' if locked else 'Aberto'}` | `{'Oculto' if hidden else 'Visível'}`\n"
        f"— Limite do grupo: `{features.get('memberLimit', 5)}` membros"
    )

    custom_intro = _page_content_optional("call", user, data, plan)
    header = custom_intro or "## Painel VIP — Call"
    container = disnake.ui.Container(
        disnake.ui.TextDisplay(header),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    return [_back_row("VipUser_BackToMain"), container, buttons]


def _call_group_page(guild, user, data: dict) -> list:
    features = VipManager.get_plan_features(data.get("plan"))
    plan = VipManager.get_plan(data.get("plan"))
    limit = features.get("memberLimit", 5)
    allowed = [uid for uid in (data.get("allowed_users") or []) if uid != user.id]

    add_row = disnake.ui.ActionRow(
        disnake.ui.UserSelect(
            custom_id="VipUser_CallGroupAdd",
            placeholder="Selecione membros para adicionar...",
            min_values=1,
            max_values=min(25, max(1, limit)),
        )
    )
    options = [_member_remove_option(guild, uid) for uid in allowed[:25]] or [
        disnake.SelectOption(label="—", value="none", description="Sem membros")
    ]
    remove_row = disnake.ui.ActionRow(
        disnake.ui.StringSelect(
            custom_id="VipUser_CallGroupRemove",
            placeholder="Remover membro do grupo...",
            options=options,
            disabled=not allowed,
        )
    )

    custom_schema = _page_components_v2("call_group")
    if custom_schema:
        rendered = render_components_v2(custom_schema, _call_group_placeholders(user, data, plan, guild, features))
        if rendered:
            return [_back_row("VipUser_BackCall"), *rendered, add_row, remove_row]

    members_list = _format_members_list(allowed, guild)
    body = (
        f"**Grupo da Call**\n"
        f"Membros autorizados a entrar mesmo se a call estiver trancada.\n"
        f"Limite: `{len(allowed)}/{limit}`\n\n"
        f"{members_list}"
    )

    custom_intro = _page_content_optional("call_group", user, data, plan)
    header = custom_intro or "## Painel VIP — Grupo da Call"
    container = disnake.ui.Container(
        disnake.ui.TextDisplay(header),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    return [_back_row("VipUser_BackCall"), container, add_row, remove_row]


def _custom_role_page(guild, user, data: dict) -> list:
    features = VipManager.get_plan_features(data.get("plan"))
    plan = VipManager.get_plan(data.get("plan"))
    role_id = data.get("custom_role_id")
    role = None
    if guild and role_id:
        try:
            role = guild.get_role(int(role_id))
        except (TypeError, ValueError):
            role = None

    if not role:
        rows = [
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Criar cargo", style=disnake.ButtonStyle.green, custom_id="VipUser_CustomRoleCreate"),
            )
        ]
    else:
        rows = [
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Editar nome", style=disnake.ButtonStyle.grey, custom_id="VipUser_CustomRoleEditName"),
                disnake.ui.Button(label="Editar cor", style=disnake.ButtonStyle.grey, custom_id="VipUser_CustomRoleEditColor"),
                disnake.ui.Button(label="Editar ícone", style=disnake.ButtonStyle.grey, custom_id="VipUser_CustomRoleEditIcon"),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Opções", style=disnake.ButtonStyle.primary, custom_id="VipUser_CustomRoleOptions"),
                disnake.ui.Button(label="Gerenciar grupo", style=disnake.ButtonStyle.secondary, custom_id="VipUser_CustomRoleGroup"),
                disnake.ui.Button(label="Deletar cargo", style=disnake.ButtonStyle.red, custom_id="VipUser_CustomRoleDelete"),
            ),
        ]

    custom_schema = _page_components_v2("custom_role")
    if custom_schema:
        rendered = render_components_v2(custom_schema, _custom_role_placeholders(user, data, plan, guild, features))
        if rendered:
            return [_back_row("VipUser_BackToMain"), *rendered] + rows

    if role:
        color_hex = f"#{role.color.value:06X}" if role.color else "—"
        hoist_txt = "Ativado" if role.hoist else "Desativado"
        mention_txt = "Ativado" if role.mentionable else "Desativado"
        body = (
            f"**Cargo:** {role.mention}\n"
            f"**Cor:** `{color_hex}`\n"
            f"**Exibir separado:** `{hoist_txt}`\n"
            f"**Mencionável:** `{mention_txt}`\n"
            f"**Membros do grupo:** `{len(data.get('role_members') or [])}/{features.get('roleMemberLimit', 3)}`"
        )
    else:
        body = (
            "Você ainda não possui cargo personalizado.\n"
            f"Limite de membros do seu plano: `{features.get('roleMemberLimit', 3)}`"
        )

    custom_intro = _page_content_optional("custom_role", user, data, plan)
    header = custom_intro or "## Painel VIP — Cargo"
    container = disnake.ui.Container(
        disnake.ui.TextDisplay(header),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    return [_back_row("VipUser_BackToMain"), container] + rows


def _custom_role_group_page(guild, user, data: dict) -> list:
    features = VipManager.get_plan_features(data.get("plan"))
    plan = VipManager.get_plan(data.get("plan"))
    limit = features.get("roleMemberLimit", 3)
    members = [uid for uid in (data.get("role_members") or []) if uid != user.id]

    add_row = disnake.ui.ActionRow(
        disnake.ui.UserSelect(
            custom_id="VipUser_CustomRoleGroupAdd",
            placeholder="Selecione membros para adicionar ao cargo...",
            min_values=1,
            max_values=min(25, max(1, limit)),
        )
    )
    options = [_member_remove_option(guild, uid) for uid in members[:25]] or [
        disnake.SelectOption(label="—", value="none", description="Sem membros")
    ]
    remove_row = disnake.ui.ActionRow(
        disnake.ui.StringSelect(
            custom_id="VipUser_CustomRoleGroupRemove",
            placeholder="Remover membro do cargo...",
            options=options,
            disabled=not members,
        )
    )

    custom_schema = _page_components_v2("custom_role_group")
    if custom_schema:
        rendered = render_components_v2(custom_schema, _custom_role_group_placeholders(user, data, plan, guild, features))
        if rendered:
            return [_back_row("VipUser_BackCustomRole"), *rendered, add_row, remove_row]

    members_list = _format_members_list(members, guild).replace("*Nenhum membro autorizado.*", "*Nenhum membro no seu cargo.*")
    body = (
        f"**Membros do Cargo VIP**\n"
        f"Limite do plano: `{len(members)}/{limit}`\n\n"
        f"{members_list}"
    )

    custom_intro = _page_content_optional("custom_role_group", user, data, plan)
    header = custom_intro or "## Painel VIP — Grupo do Cargo"
    container = disnake.ui.Container(
        disnake.ui.TextDisplay(header),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    return [_back_row("VipUser_BackCustomRole"), container, add_row, remove_row]


def _custom_role_options_page(guild, user, data: dict) -> list:
    role_id = data.get("custom_role_id")
    role = None
    if guild and role_id:
        try:
            role = guild.get_role(int(role_id))
        except (TypeError, ValueError):
            role = None

    hoist = bool(role and role.hoist)
    mentionable = bool(role and role.mentionable)

    body = (
        "Alterna comportamentos adicionais do seu cargo.\n\n"
        f"**Exibir separado:** `{'Ativado' if hoist else 'Desativado'}`\n"
        f"**Mencionável:** `{'Ativado' if mentionable else 'Desativado'}`"
    )
    container = disnake.ui.Container(
        disnake.ui.TextDisplay("## Painel VIP — Opções do Cargo"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    buttons = disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Desativar exibição" if hoist else "Ativar exibição",
            style=disnake.ButtonStyle.red if hoist else disnake.ButtonStyle.green,
            custom_id="VipUser_CustomRoleToggleHoist",
            disabled=not role,
        ),
        disnake.ui.Button(
            label="Desativar menção" if mentionable else "Ativar menção",
            style=disnake.ButtonStyle.red if mentionable else disnake.ButtonStyle.green,
            custom_id="VipUser_CustomRoleToggleMentionable",
            disabled=not role,
        ),
    )

    return [_back_row("VipUser_BackCustomRole"), container, buttons]


def _reaction_page(guild, user, data: dict) -> list:
    features = VipManager.get_plan_features(data.get("plan"))
    plan = VipManager.get_plan(data.get("plan"))

    if not features.get("mentionReaction"):
        custom_intro = _page_content_optional("reaction", user, data, plan)
        header = custom_intro or "## Painel VIP — Reação"
        container = disnake.ui.Container(
            disnake.ui.TextDisplay(header),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay("Seu plano não possui reação personalizada."),
        )
        return [_back_row("VipUser_BackToMain"), container]

    reaction_data = data.get("customReaction") or {}
    enabled = bool(reaction_data.get("enabled"))
    super_enabled = bool(reaction_data.get("superReactionEnabled"))

    rows = []

    guild_emojis = [e for e in (guild.emojis if guild else []) if getattr(e, "available", True)]
    guild_emojis.sort(key=lambda e: e.name.lower())
    if guild_emojis:
        options = []
        for emoji_obj in guild_emojis[:25]:
            try:
                options.append(
                    disnake.SelectOption(
                        label=emoji_obj.name[:25],
                        value=str(emoji_obj.id),
                        emoji=disnake.PartialEmoji(name=emoji_obj.name, id=emoji_obj.id, animated=emoji_obj.animated),
                    )
                )
            except Exception:
                continue
        if options:
            rows.append(
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id="VipUser_ReactionEmojiSelect",
                        placeholder="Escolha um emoji...",
                        options=options,
                    )
                )
            )

    rows.append(
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Definir gatilho", style=disnake.ButtonStyle.primary, custom_id="VipUser_ReactionConfig"),
            disnake.ui.Button(
                label="Desativar" if enabled else "Ativar",
                style=disnake.ButtonStyle.red if enabled else disnake.ButtonStyle.green,
                custom_id="VipUser_ReactionToggle",
                disabled=not (reaction_data.get("emoji") and reaction_data.get("trigger")),
            ),
            disnake.ui.Button(
                label="Super: OFF" if super_enabled else "Super: ON",
                style=disnake.ButtonStyle.secondary,
                custom_id="VipUser_ReactionSuperToggle",
            ),
        )
    )

    custom_schema = _page_components_v2("reaction")
    if custom_schema:
        rendered = render_components_v2(custom_schema, _reaction_placeholders(user, data, plan))
        if rendered:
            return [_back_row("VipUser_BackToMain"), *rendered] + rows

    emoji = reaction_data.get("emoji") or "*não configurado*"
    trigger = reaction_data.get("trigger") or "*não configurado*"
    body = (
        f"**Status:** `{'Ativado' if enabled else 'Desativado'}`\n"
        f"**Super Reação:** `{'Ativado' if super_enabled else 'Desativado'}`\n"
        f"**Emoji:** {emoji}\n"
        f"**Gatilho:** `{trigger}`\n\n"
        "-# Super Reação depende de integração externa (em breve)."
    )
    custom_intro = _page_content_optional("reaction", user, data, plan)
    header = custom_intro or "## Painel VIP — Reação"
    container = disnake.ui.Container(
        disnake.ui.TextDisplay(header),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    return [_back_row("VipUser_BackToMain"), container] + rows


def _render_page(bot, guild, user, data, page: str) -> list:
    if page == "call":
        return _call_page(guild, user, data)
    if page == "call_group":
        return _call_group_page(guild, user, data)
    if page == "custom_role":
        return _custom_role_page(guild, user, data)
    if page == "custom_role_group":
        return _custom_role_group_page(guild, user, data)
    if page == "custom_role_options":
        return _custom_role_options_page(guild, user, data)
    if page == "reaction":
        return _reaction_page(guild, user, data)
    return _main_page(user, data)


def _admin_panel(target: disnake.abc.User, data: dict | None) -> tuple[list, list]:
    header = f"## Gerenciamento VIP\n-# Alvo: {target.mention} (`{target.id}`)"

    if not data:
        body = "Este usuário não possui registro VIP no sistema."
    else:
        status = "Ativo" if data.get("status") else "Inativo"
        plan = VipManager.get_plan(data.get("plan"))
        plan_name = (plan or {}).get("displayName") or data.get("plan") or "—"
        expiry = _format_expiry(data) if data.get("status") else "—"
        history_count = len(data.get("history") or [])
        last_updated = data.get("last_updated") or "—"

        body = (
            f"**Status:** `{status}`\n"
            f"**Plano:** `{plan_name}`\n"
            f"**Validade:** `{expiry}`\n"
            f"**Histórico:** `{history_count}` plano(s) em fila\n"
            f"**Última atualização:** `{last_updated}`"
        )

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(header),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(body),
    )

    buttons = disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Ver detalhes",
            style=disnake.ButtonStyle.grey,
            custom_id=f"VipAdmin_Details_{target.id}",
        ),
        disnake.ui.Button(
            label="Abrir dashboard",
            style=disnake.ButtonStyle.link,
            url=_dashboard_vip_url(),
        ),
    )
    return [container], [buttons]


async def _edit_panel(inter: disnake.MessageInteraction, components: list, feedback=None):
    base = list(components)
    payload = base + ([feedback] if feedback is not None else [])
    flags = disnake.MessageFlags(is_components_v2=True)
    try:
        if not inter.response.is_done():
            await inter.response.edit_message(components=payload, flags=flags)
        else:
            await inter.edit_original_message(components=payload)
    except disnake.errors.NotFound:
        return
    except Exception as e:
        print(f"[VIP PANEL] Erro ao editar painel: {e}")
        return

    user_id = getattr(getattr(inter, "user", None), "id", None)
    if user_id is None:
        return

    prev = _feedback_tasks.pop(user_id, None)
    if prev and not prev.done():
        prev.cancel()

    if feedback is None:
        return

    async def _clear_feedback():
        try:
            await asyncio.sleep(_FEEDBACK_TIMEOUT_SEC)
            await inter.edit_original_message(components=base)
        except (asyncio.CancelledError, disnake.errors.NotFound):
            pass
        except Exception as e:
            print(f"[VIP PANEL] Erro ao limpar feedback: {e}")
        finally:
            _feedback_tasks.pop(user_id, None)

    _feedback_tasks[user_id] = asyncio.create_task(_clear_feedback())


async def _render_and_edit(bot, inter: disnake.MessageInteraction, data, page, feedback=None):
    guild = inter.guild
    components = _render_page(bot, guild, inter.user, data, page)
    await _edit_panel(inter, components, feedback)


def _protection_pending_reverts(bot, role_id: int, adding: bool = True):
    cog = bot.get_cog("VipProtection")
    if cog is None or not hasattr(cog, "_pending_reverts"):
        return
    try:
        if adding:
            cog._pending_reverts.add(role_id)
        else:
            cog._pending_reverts.discard(role_id)
    except Exception:
        pass


class VipCommands(commands.Cog):
    """Slash `/vip` (usuário, multipágina) + context menu `Gerenciar VIP` (admin, info)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(
        name="vip",
        description="Abre o painel do seu VIP.",
    )
    async def vip(self, inter: disnake.ApplicationCommandInteraction):
        await inter.response.defer(ephemeral=True)
        data = await VipManager.refresh_user_vip(inter.user.id) or VipManager.get_user_vip(inter.user.id)
        components = _main_page(inter.user, data)
        await inter.followup.send(
            components=components,
            ephemeral=True,
            flags=disnake.MessageFlags(is_components_v2=True),
        )

    @commands.user_command(
        name="Gerenciar VIP",
        default_member_permissions=disnake.Permissions(manage_guild=True),
    )
    async def gerenciar_vip(self, inter: disnake.UserCommandInteraction, target: disnake.User):
        await inter.response.defer(ephemeral=True)
        data = await VipManager.refresh_user_vip(target.id) or VipManager.get_user_vip(target.id)
        containers, buttons = _admin_panel(target, data)
        await inter.followup.send(
            components=containers + buttons,
            ephemeral=True,
            flags=disnake.MessageFlags(is_components_v2=True),
        )

    @commands.Cog.listener("on_button_click")
    async def _on_admin_button(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id or ""
        if not cid.startswith("VipAdmin_Details_"):
            return

        perms = getattr(inter.user, "guild_permissions", None)
        if perms is None or not perms.manage_guild:
            try:
                await inter.response.send_message(
                    "Você não tem permissão para visualizar esses detalhes.",
                    ephemeral=True,
                )
            except Exception:
                pass
            return

        try:
            user_id = int(cid.replace("VipAdmin_Details_", ""))
        except ValueError:
            return

        await inter.response.defer(ephemeral=True)

        target = inter.guild.get_member(user_id) if inter.guild else None
        if target is None:
            try:
                target = await self.bot.fetch_user(user_id)
            except Exception:
                target = None

        if target is None:
            await inter.followup.send("Usuário não encontrado.", ephemeral=True)
            return

        data = await VipManager.refresh_user_vip(user_id) or VipManager.get_user_vip(user_id)

        if not data:
            body = "Nenhum registro VIP encontrado para este usuário."
        else:
            history = data.get("history") or []
            history_lines = []
            for idx, item in enumerate(history[-5:], start=1):
                p = VipManager.get_plan(item.get("plan"))
                p_name = (p or {}).get("displayName") or item.get("plan") or "?"
                perm = "permanente" if item.get("is_permanent") else (item.get("expires_at") or "sem data")
                history_lines.append(f"-# {idx}. `{p_name}` — {perm}")
            history_text = "\n".join(history_lines) if history_lines else "-# (vazio)"

            plan = VipManager.get_plan(data.get("plan"))
            plan_name = (plan or {}).get("displayName") or data.get("plan") or "—"

            body = (
                f"**Status:** `{'Ativo' if data.get('status') else 'Inativo'}`\n"
                f"**Plano:** `{plan_name}`\n"
                f"**Permanente:** `{data.get('is_permanent', False)}`\n"
                f"**Expira em:** `{data.get('expires_at') or '—'}`\n"
                f"**Última atualização:** `{data.get('last_updated') or '—'}`\n\n"
                f"**Histórico ({len(history)} total):**\n{history_text}"
            )

        container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"## Detalhes VIP\n-# {target.mention} (`{target.id}`)"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(body),
        )

        await inter.followup.send(
            components=[container],
            ephemeral=True,
            flags=disnake.MessageFlags(is_components_v2=True),
        )

    async def _require_active_vip(self, inter: disnake.MessageInteraction) -> dict | None:
        data = await VipManager.refresh_user_vip(inter.user.id) or VipManager.get_user_vip(inter.user.id)
        if not _is_active_vip(data):
            try:
                await inter.response.send_message(
                    "Você não possui VIP ativo.",
                    ephemeral=True,
                )
            except Exception:
                pass
            return None
        return data

    @commands.Cog.listener("on_dropdown")
    async def _on_dropdown(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id or ""
        if not cid.startswith("VipUser_"):
            return

        data = await self._require_active_vip(inter)
        if data is None:
            return

        if not inter.response.is_done():
            try:
                await inter.response.defer_update()
            except Exception:
                pass

        try:
            if cid == "VipUser_Navigation":
                page = inter.values[0]
                await _render_and_edit(self.bot, inter, data, page)
                return

            if cid == "VipUser_CallGroupAdd":
                await self._call_group_add(inter, data)
                return

            if cid == "VipUser_CallGroupRemove":
                await self._call_group_remove(inter, data)
                return

            if cid == "VipUser_CustomRoleGroupAdd":
                await self._role_group_add(inter, data)
                return

            if cid == "VipUser_CustomRoleGroupRemove":
                await self._role_group_remove(inter, data)
                return

            if cid == "VipUser_ReactionEmojiSelect":
                await self._reaction_select_emoji(inter, data)
                return
        except Exception as e:
            print(f"[VIP DROPDOWN] {cid}: {e}")

    @commands.Cog.listener("on_button_click")
    async def _on_user_button(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id or ""
        if not cid.startswith("VipUser_"):
            return

        data = await self._require_active_vip(inter)
        if data is None:
            return

        modal_triggers = {
            "VipUser_EditName",
            "VipUser_CustomRoleEditName",
            "VipUser_CustomRoleEditColor",
            "VipUser_ReactionConfig",
        }
        if cid not in modal_triggers and not inter.response.is_done():
            try:
                await inter.response.defer_update()
            except Exception:
                pass

        try:
            if cid == "VipUser_BackToMain":
                await _render_and_edit(self.bot, inter, data, "main")
                return
            if cid == "VipUser_BackCall":
                await _render_and_edit(self.bot, inter, data, "call")
                return
            if cid == "VipUser_BackCustomRole":
                await _render_and_edit(self.bot, inter, data, "custom_role")
                return

            if cid == "VipUser_CreateChannel":
                await self._create_channel(inter, data)
                return
            if cid == "VipUser_ToggleLock":
                await self._toggle_lock(inter, data)
                return
            if cid == "VipUser_ToggleVisibility":
                await self._toggle_visibility(inter, data)
                return
            if cid == "VipUser_EditName":
                await self._open_modal_edit_channel_name(inter, data)
                return
            if cid == "VipUser_CallGroup":
                await _render_and_edit(self.bot, inter, data, "call_group")
                return

            if cid == "VipUser_CustomRoleCreate":
                await self._create_custom_role(inter, data)
                return
            if cid == "VipUser_CustomRoleEditName":
                await self._open_modal_role_name(inter, data)
                return
            if cid == "VipUser_CustomRoleEditColor":
                await self._open_modal_role_color(inter, data)
                return
            if cid == "VipUser_CustomRoleEditIcon":
                await self._edit_role_icon(inter, data)
                return
            if cid == "VipUser_CustomRoleOptions":
                await _render_and_edit(self.bot, inter, data, "custom_role_options")
                return
            if cid == "VipUser_CustomRoleToggleHoist":
                await self._toggle_role_attr(inter, data, "hoist")
                return
            if cid == "VipUser_CustomRoleToggleMentionable":
                await self._toggle_role_attr(inter, data, "mentionable")
                return
            if cid == "VipUser_CustomRoleGroup":
                await _render_and_edit(self.bot, inter, data, "custom_role_group")
                return
            if cid == "VipUser_CustomRoleDelete":
                await self._delete_custom_role(inter, data)
                return

            if cid == "VipUser_ReactionToggle":
                await self._toggle_reaction(inter, data)
                return
            if cid == "VipUser_ReactionSuperToggle":
                await self._toggle_super_reaction(inter, data)
                return
            if cid == "VipUser_ReactionConfig":
                await self._open_modal_reaction_trigger(inter, data)
                return
        except Exception as e:
            print(f"[VIP BUTTON] {cid}: {e}")

    @commands.Cog.listener("on_modal_submit")
    async def _on_modal(self, inter: disnake.ModalInteraction):
        cid = inter.custom_id or ""
        if not cid.startswith("VipUser_Modal"):
            return

        data = await VipManager.refresh_user_vip(inter.user.id) or VipManager.get_user_vip(inter.user.id)
        if not _is_active_vip(data):
            try:
                await inter.response.send_message("VIP inativo.", ephemeral=True)
            except Exception:
                pass
            return

        if not inter.response.is_done():
            try:
                await inter.response.defer(with_message=False)
            except Exception:
                pass

        try:
            if cid == "VipUser_ModalEditName":
                await self._submit_edit_channel_name(inter, data)
                return
            if cid == "VipUser_ModalCustomRoleName":
                await self._submit_role_name(inter, data)
                return
            if cid == "VipUser_ModalCustomRoleColor":
                await self._submit_role_color(inter, data)
                return
            if cid == "VipUser_ModalReactionTrigger":
                await self._submit_reaction_trigger(inter, data)
                return
        except Exception as e:
            print(f"[VIP MODAL] {cid}: {e}")

    async def _create_channel(self, inter, data):
        features = VipManager.get_plan_features(data.get("plan"))
        if not features.get("voiceChannel"):
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Seu plano não inclui canal de voz.", False))
            return
        if data.get("channel_id"):
            guild = inter.guild
            existing = guild.get_channel(int(data["channel_id"])) if guild else None
            if existing:
                await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Você já possui canal criado.", False))
                return

        cat_id = features.get("voiceCategoryId")
        if not cat_id:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Categoria de voz não configurada no plano.", False))
            return

        guild = inter.guild
        try:
            category = guild.get_channel(int(cat_id))
        except (TypeError, ValueError):
            category = None
        if not category:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Categoria configurada não encontrada.", False))
            return

        locked = bool(data.get("locked"))
        hidden = bool(data.get("hidden"))
        overwrites = {
            guild.default_role: disnake.PermissionOverwrite(
                connect=None if not locked else False,
                view_channel=False if hidden else None,
            ),
            inter.user: disnake.PermissionOverwrite(
                connect=True,
                view_channel=True,
                manage_channels=True,
                move_members=True,
            ),
        }
        limit = features.get("memberLimit", 5) if not features.get("dynamicLimit") else 1
        try:
            channel = await guild.create_voice_channel(
                name=f"🎙️ {inter.user.display_name}",
                category=category,
                overwrites=overwrites,
                user_limit=limit,
            )
        except disnake.Forbidden:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Sem permissão para criar canal nessa categoria.", False))
            return
        except Exception as e:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container(f"Erro: {e}", False))
            return

        await asyncio.sleep(_DISCORD_OP_DELAY)
        for uid in data.get("allowed_users") or []:
            if uid == inter.user.id:
                continue
            member = guild.get_member(uid)
            if not member:
                continue
            try:
                await channel.set_permissions(member, connect=not locked, view_channel=True)
            except Exception:
                pass
            await asyncio.sleep(_DISCORD_OP_DELAY)

        data["channel_id"] = str(channel.id)
        VipManager.save_user_vip(inter.user.id, data)
        await VipLogger.channel_created(self.bot, inter.user, channel)
        await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Canal VIP criado!"))

    async def _toggle_lock(self, inter, data):
        guild = inter.guild
        channel_id = data.get("channel_id")
        channel = guild.get_channel(int(channel_id)) if channel_id and guild else None
        if not channel:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Canal não encontrado.", False))
            return
        locked = not bool(data.get("locked"))
        data["locked"] = locked

        try:
            overwrite = channel.overwrites_for(guild.default_role)
            overwrite.connect = False if locked else None
            await channel.set_permissions(guild.default_role, overwrite=overwrite)
        except Exception:
            pass

        for uid in data.get("allowed_users") or []:
            if uid == inter.user.id:
                continue
            member = guild.get_member(uid)
            if not member:
                continue
            try:
                await channel.set_permissions(member, connect=True, view_channel=True)
            except Exception:
                pass
            await asyncio.sleep(_DISCORD_OP_DELAY)

        VipManager.save_user_vip(inter.user.id, data)
        await _render_and_edit(self.bot, inter, data, "call", _feedback_container(f"Canal {'trancado' if locked else 'destrancado'}."))

    async def _toggle_visibility(self, inter, data):
        guild = inter.guild
        channel_id = data.get("channel_id")
        channel = guild.get_channel(int(channel_id)) if channel_id and guild else None
        if not channel:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Canal não encontrado.", False))
            return

        hidden = not bool(data.get("hidden"))
        data["hidden"] = hidden
        try:
            overwrite = channel.overwrites_for(guild.default_role)
            overwrite.view_channel = False if hidden else None
            await channel.set_permissions(guild.default_role, overwrite=overwrite)
        except Exception:
            pass
        VipManager.save_user_vip(inter.user.id, data)
        await _render_and_edit(self.bot, inter, data, "call", _feedback_container(f"Canal {'oculto' if hidden else 'visível'}."))

    async def _open_modal_edit_channel_name(self, inter, data):
        channel_id = data.get("channel_id")
        if not channel_id:
            await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Crie o canal antes.", False))
            return
        await inter.response.send_modal(
            title="Nome do Canal",
            custom_id="VipUser_ModalEditName",
            components=[
                disnake.ui.TextInput(
                    label="Novo nome",
                    custom_id="name",
                    max_length=50,
                    placeholder="Ex: 🎙️ Minha sala",
                )
            ],
        )

    async def _submit_edit_channel_name(self, inter, data):
        name = inter.text_values.get("name", "").strip()
        if not name:
            return
        guild = inter.guild
        channel = guild.get_channel(int(data.get("channel_id") or 0)) if guild else None
        if not channel:
            return
        try:
            await channel.edit(name=name, reason="VIP: usuário renomeou canal")
        except Exception as e:
            print(f"[VIP] Falha ao renomear canal: {e}")
        await _render_and_edit(self.bot, inter, data, "call", _feedback_container("Canal renomeado."))

    async def _call_group_add(self, inter, data):
        features = VipManager.get_plan_features(data.get("plan"))
        limit = features.get("memberLimit", 5)
        selected = [int(v) for v in inter.values]
        allowed = list(data.get("allowed_users") or [])
        new_ids = [uid for uid in selected if uid not in allowed and uid != inter.user.id]
        if not new_ids:
            await _render_and_edit(self.bot, inter, data, "call_group")
            return
        if len(allowed) + len(new_ids) > limit:
            await _render_and_edit(self.bot, inter, data, "call_group", _feedback_container(f"Limite de {limit} membros atingido.", False))
            return

        allowed.extend(new_ids)
        data["allowed_users"] = allowed
        VipManager.save_user_vip(inter.user.id, data)

        guild = inter.guild
        channel = guild.get_channel(int(data.get("channel_id") or 0)) if guild else None
        locked = bool(data.get("locked"))
        for uid in new_ids:
            member = guild.get_member(uid) if guild else None
            if not member:
                continue
            if channel:
                try:
                    await channel.set_permissions(member, connect=True, view_channel=True)
                except Exception:
                    pass
            await VipLogger.member_added_group(self.bot, inter.user, member, "Call")
            await asyncio.sleep(_DISCORD_OP_DELAY)

        await _render_and_edit(self.bot, inter, data, "call_group", _feedback_container(f"{len(new_ids)} membro(s) adicionado(s)."))

    async def _call_group_remove(self, inter, data):
        raw = inter.values[0] if inter.values else None
        if raw in (None, "none"):
            await _render_and_edit(self.bot, inter, data, "call_group")
            return
        try:
            target_id = int(raw)
        except ValueError:
            return
        allowed = list(data.get("allowed_users") or [])
        if target_id not in allowed:
            await _render_and_edit(self.bot, inter, data, "call_group")
            return
        allowed.remove(target_id)
        data["allowed_users"] = allowed
        VipManager.save_user_vip(inter.user.id, data)

        guild = inter.guild
        channel = guild.get_channel(int(data.get("channel_id") or 0)) if guild else None
        target = guild.get_member(target_id) if guild else None
        if channel and target:
            try:
                await channel.set_permissions(target, overwrite=None)
            except Exception:
                pass
        await VipLogger.member_removed_group(self.bot, inter.user, target or f"ID: {target_id}", "Call")
        await _render_and_edit(self.bot, inter, data, "call_group", _feedback_container("Membro removido."))

    async def _create_custom_role(self, inter, data):
        features = VipManager.get_plan_features(data.get("plan"))
        if not features.get("customRole"):
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Seu plano não inclui cargo personalizado.", False))
            return

        if data.get("custom_role_id"):
            guild = inter.guild
            existing = guild.get_role(int(data["custom_role_id"])) if guild else None
            if existing:
                await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Você já possui cargo personalizado.", False))
                return

        guild = inter.guild
        try:
            role = await guild.create_role(
                name=f"VIP: {inter.user.display_name}",
                reason=f"VIP Custom Role: {inter.user.id}",
                permissions=disnake.Permissions.none(),
            )
        except disnake.Forbidden:
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Sem permissão para criar cargo.", False))
            return
        except Exception as e:
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container(f"Erro: {e}", False))
            return

        await asyncio.sleep(_DISCORD_OP_DELAY)

        config = VipManager.get_config()
        bottom_raw = config.get("bottom_role_id")
        if bottom_raw:
            try:
                bottom_role = guild.get_role(int(bottom_raw))
            except (TypeError, ValueError):
                bottom_role = None
            if bottom_role:
                try:
                    fresh_roles = await guild.fetch_roles()
                    bottom_fresh = next((r for r in fresh_roles if r.id == bottom_role.id), None)
                    if bottom_fresh:
                        target_pos = bottom_fresh.position + 1
                        await role.edit(position=target_pos, reason="VIP: posicionar acima do separador base")
                        await asyncio.sleep(_DISCORD_OP_DELAY)
                except Exception as e:
                    print(f"[VIP] Falha ao posicionar cargo personalizado: {e}")

        try:
            await inter.user.add_roles(role, reason="VIP: dono do cargo personalizado")
        except Exception:
            pass

        data["custom_role_id"] = str(role.id)
        VipManager.save_user_vip(inter.user.id, data)
        await VipLogger.role_created(self.bot, inter.user, role)
        await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cargo personalizado criado!"))

    async def _delete_custom_role(self, inter, data):
        role_id = data.get("custom_role_id")
        if not role_id:
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Você não possui cargo personalizado.", False))
            return
        guild = inter.guild
        role = guild.get_role(int(role_id)) if guild else None
        role_name = role.name if role else "?"
        if role:
            _protection_pending_reverts(self.bot, role.id, True)
            try:
                await role.delete(reason="VIP: usuário deletou cargo")
            except Exception as e:
                print(f"[VIP] Falha ao deletar cargo: {e}")
            finally:
                await asyncio.sleep(1)
                _protection_pending_reverts(self.bot, role.id, False)
        data["custom_role_id"] = None
        data["role_members"] = []
        data["role_color"] = None
        VipManager.save_user_vip(inter.user.id, data)
        await VipLogger.role_deleted(self.bot, inter.user, role_name, "usuário deletou")
        await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cargo deletado."))

    async def _open_modal_role_name(self, inter, data):
        guild = inter.guild
        role_id = data.get("custom_role_id")
        role = guild.get_role(int(role_id)) if role_id and guild else None
        current = role.name if role else ""
        await inter.response.send_modal(
            title="Nome do Cargo",
            custom_id="VipUser_ModalCustomRoleName",
            components=[
                disnake.ui.TextInput(
                    label="Novo nome",
                    custom_id="name",
                    max_length=100,
                    value=current,
                )
            ],
        )

    async def _submit_role_name(self, inter, data):
        name = inter.text_values.get("name", "").strip()
        if not name:
            return
        guild = inter.guild
        role = guild.get_role(int(data.get("custom_role_id") or 0)) if guild else None
        if not role:
            return
        try:
            await role.edit(name=name, reason="VIP: usuário renomeou cargo")
        except Exception as e:
            print(f"[VIP] Falha ao renomear cargo: {e}")
        await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cargo renomeado."))

    async def _open_modal_role_color(self, inter, data):
        guild = inter.guild
        role = guild.get_role(int(data.get("custom_role_id") or 0)) if guild else None
        if not role:
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cargo não encontrado.", False))
            return
        current_primary = f"#{role.color.value:06X}" if role.color else ""
        stored = data.get("role_color") or {}
        color_type = stored.get("type", "normal")
        secondary = stored.get("secondary") or ""
        try:
            components = [
                disnake.ui.Label(
                    text="Tipo de cor",
                    component=disnake.ui.StringSelect(
                        custom_id="color_type",
                        placeholder="Selecione o tipo",
                        options=[
                            disnake.SelectOption(label="Cor Normal", value="normal", default=color_type == "normal"),
                            disnake.SelectOption(label="Gradiente", value="gradient", default=color_type == "gradient"),
                        ],
                    ),
                ),
                disnake.ui.Label(
                    text="Cor principal (hex)",
                    component=disnake.ui.TextInput(
                        custom_id="primary_color",
                        placeholder="#FF0000",
                        max_length=7,
                        value=current_primary,
                        required=True,
                    ),
                ),
                disnake.ui.Label(
                    text="Cor secundária (somente gradiente)",
                    component=disnake.ui.TextInput(
                        custom_id="secondary_color",
                        placeholder="#0000FF",
                        max_length=7,
                        value=secondary,
                        required=False,
                    ),
                ),
            ]
            await inter.response.send_modal(
                title="Cor do Cargo",
                custom_id="VipUser_ModalCustomRoleColor",
                components=components,
            )
        except Exception:
            await inter.response.send_modal(
                title="Cor do Cargo",
                custom_id="VipUser_ModalCustomRoleColor",
                components=[
                    disnake.ui.TextInput(
                        label="Cor (hex)",
                        custom_id="primary_color",
                        placeholder="#FF0000",
                        max_length=7,
                        value=current_primary,
                    )
                ],
            )

    async def _submit_role_color(self, inter, data):
        raw_values = getattr(inter, "resolved_values", None) or inter.text_values
        color_type = raw_values.get("color_type", "normal") if isinstance(raw_values, dict) else "normal"
        if isinstance(color_type, list):
            color_type = color_type[0] if color_type else "normal"
        primary = (raw_values.get("primary_color") or "").strip() if isinstance(raw_values, dict) else ""
        secondary = (raw_values.get("secondary_color") or "").strip() if isinstance(raw_values, dict) else ""

        if primary and not primary.startswith("#"):
            primary = f"#{primary}"
        if secondary and not secondary.startswith("#"):
            secondary = f"#{secondary}"
        if not primary:
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cor primária obrigatória.", False))
            return
        try:
            primary_int = int(primary.lstrip("#"), 16)
        except ValueError:
            await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Hex inválido.", False))
            return

        guild = inter.guild
        role = guild.get_role(int(data.get("custom_role_id") or 0)) if guild else None
        if not role:
            return
        _protection_pending_reverts(self.bot, role.id, True)
        try:
            color = disnake.Colour(primary_int)
            if color_type == "gradient" and secondary:
                try:
                    sec_int = int(secondary.lstrip("#"), 16)
                    try:
                        await role.edit(primary_color=color, secondary_color=disnake.Colour(sec_int), reason="VIP: cor atualizada")
                    except TypeError:
                        await role.edit(colour=color, reason="VIP: cor atualizada")
                except ValueError:
                    await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cor secundária inválida.", False))
                    return
            else:
                try:
                    await role.edit(primary_color=color, secondary_color=None, reason="VIP: cor atualizada")
                except TypeError:
                    await role.edit(colour=color, reason="VIP: cor atualizada")
            data["role_color"] = {
                "primary": primary.upper(),
                "secondary": secondary.upper() if color_type == "gradient" else None,
                "type": color_type,
            }
            VipManager.save_user_vip(inter.user.id, data)
        finally:
            await asyncio.sleep(1)
            _protection_pending_reverts(self.bot, role.id, False)
        await _render_and_edit(self.bot, inter, data, "custom_role", _feedback_container("Cor atualizada."))

    async def _edit_role_icon(self, inter, data):
        await _render_and_edit(
            self.bot,
            inter,
            data,
            "custom_role",
            _feedback_container(
                "Edição de ícone por upload não está disponível por enquanto. "
                "Configure pelo dashboard.",
                False,
            ),
        )

    async def _toggle_role_attr(self, inter, data, attr: str):
        guild = inter.guild
        role = guild.get_role(int(data.get("custom_role_id") or 0)) if guild else None
        if not role:
            await _render_and_edit(self.bot, inter, data, "custom_role_options", _feedback_container("Cargo não encontrado.", False))
            return
        new_value = not getattr(role, attr)
        _protection_pending_reverts(self.bot, role.id, True)
        try:
            kwargs = {attr: new_value, "reason": "VIP: usuário alterou opção"}
            await role.edit(**kwargs)
        finally:
            await asyncio.sleep(1)
            _protection_pending_reverts(self.bot, role.id, False)
        await _render_and_edit(self.bot, inter, data, "custom_role_options", _feedback_container("Opção atualizada."))

    async def _role_group_add(self, inter, data):
        features = VipManager.get_plan_features(data.get("plan"))
        limit = features.get("roleMemberLimit", 3)
        selected = [int(v) for v in inter.values]
        current = list(data.get("role_members") or [])
        new_ids = [uid for uid in selected if uid not in current and uid != inter.user.id]
        if not new_ids:
            await _render_and_edit(self.bot, inter, data, "custom_role_group")
            return
        if len(current) + len(new_ids) > limit:
            await _render_and_edit(self.bot, inter, data, "custom_role_group", _feedback_container(f"Limite de {limit} membros.", False))
            return

        current.extend(new_ids)
        data["role_members"] = current
        VipManager.save_user_vip(inter.user.id, data)

        guild = inter.guild
        role = guild.get_role(int(data.get("custom_role_id") or 0)) if guild else None
        for uid in new_ids:
            member = guild.get_member(uid) if guild else None
            if member and role:
                try:
                    await member.add_roles(role, reason="VIP: adicionado ao grupo do cargo")
                except Exception:
                    pass
            if member:
                await VipLogger.member_added_group(self.bot, inter.user, member, "Cargo")
            await asyncio.sleep(_DISCORD_OP_DELAY)

        await _render_and_edit(self.bot, inter, data, "custom_role_group", _feedback_container(f"{len(new_ids)} membro(s) no cargo."))

    async def _role_group_remove(self, inter, data):
        raw = inter.values[0] if inter.values else None
        if raw in (None, "none"):
            await _render_and_edit(self.bot, inter, data, "custom_role_group")
            return
        try:
            target_id = int(raw)
        except ValueError:
            return
        members = list(data.get("role_members") or [])
        if target_id not in members:
            return
        members.remove(target_id)
        data["role_members"] = members
        VipManager.save_user_vip(inter.user.id, data)

        guild = inter.guild
        role = guild.get_role(int(data.get("custom_role_id") or 0)) if guild else None
        target = guild.get_member(target_id) if guild else None
        if role and target and role in target.roles:
            try:
                await target.remove_roles(role, reason="VIP: removido do grupo do cargo")
            except Exception:
                pass
        await VipLogger.member_removed_group(self.bot, inter.user, target or f"ID: {target_id}", "Cargo")
        await _render_and_edit(self.bot, inter, data, "custom_role_group", _feedback_container("Membro removido."))

    async def _toggle_reaction(self, inter, data):
        reaction = dict(data.get("customReaction") or {})
        if not (reaction.get("emoji") and reaction.get("trigger")):
            await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Configure emoji + gatilho antes.", False))
            return
        reaction["enabled"] = not bool(reaction.get("enabled"))
        data["customReaction"] = reaction
        VipManager.save_user_vip(inter.user.id, data)
        if reaction["enabled"]:
            await VipLogger.reaction_enabled(self.bot, inter.user, reaction.get("emoji") or "—", reaction.get("trigger") or "—")
        else:
            await VipLogger.reaction_disabled(self.bot, inter.user)
        await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Reação atualizada."))

    async def _toggle_super_reaction(self, inter, data):
        reaction = dict(data.get("customReaction") or {})
        reaction["superReactionEnabled"] = not bool(reaction.get("superReactionEnabled"))
        data["customReaction"] = reaction
        VipManager.save_user_vip(inter.user.id, data)
        await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Super Reação alternada."))

    async def _reaction_select_emoji(self, inter, data):
        emoji_id = inter.values[0] if inter.values else None
        if not emoji_id:
            return
        emoji = self.bot.get_emoji(int(emoji_id))
        if not emoji:
            await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Emoji não encontrado.", False))
            return
        reaction = dict(data.get("customReaction") or {})
        reaction["emoji"] = str(emoji)
        data["customReaction"] = reaction
        VipManager.save_user_vip(inter.user.id, data)
        await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Emoji definido. Configure o gatilho."))

    async def _open_modal_reaction_trigger(self, inter, data):
        reaction = data.get("customReaction") or {}
        current = reaction.get("trigger") or ""
        await inter.response.send_modal(
            title="Gatilho da Reação",
            custom_id="VipUser_ModalReactionTrigger",
            components=[
                disnake.ui.TextInput(
                    label="Palavra/apelido que ativa a reação",
                    custom_id="trigger",
                    placeholder="Ex: kay, spuvk",
                    max_length=20,
                    value=current,
                )
            ],
        )

    async def _submit_reaction_trigger(self, inter, data):
        trigger = inter.text_values.get("trigger", "").strip().lower()
        if not trigger:
            await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Gatilho vazio.", False))
            return
        reaction = dict(data.get("customReaction") or {})
        reaction["trigger"] = trigger
        if reaction.get("emoji"):
            reaction["enabled"] = True
        data["customReaction"] = reaction
        VipManager.save_user_vip(inter.user.id, data)
        if reaction.get("enabled"):
            await VipLogger.reaction_enabled(self.bot, inter.user, reaction.get("emoji") or "—", trigger)
        await _render_and_edit(self.bot, inter, data, "reaction", _feedback_container("Gatilho salvo."))


def setup(bot: commands.Bot):
    bot.add_cog(VipCommands(bot))
