import asyncio
import random

import disnake
from disnake.ext import commands, tasks

from functions.servers import ServerManager
from .manager import VipManager
from .logger import VipLogger


_DISCORD_OP_DELAY = 0.3


class VipProtection(commands.Cog):
    """Protege cargos/canais VIP contra alterações fora do painel + housekeeping.
    - on_member_remove: deleta canal/cargo personalizado do dono que saiu.
    - on_guild_role_update: reverte mudanças proibidas (permissions/hoist/mentionable).
    - on_member_update: reaplica cargo VIP do plano se foi removido manualmente.
    - on_member_join: restaura cargo de grupo + permissão de canal pra membros autorizados.
    - cleanup_loop (24h): deleta cargos órfãos entre separadores + aplica roleMemberLimit.
    - startup: reposiciona separadores (top acima, bottom abaixo dos custom roles)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._pending_reverts: set[int] = set()
        self._startup_done = False

    async def _custom_role_map(self) -> dict[int, dict]:
        """role_id -> {owner, members}"""
        mapping: dict[int, dict] = {}
        try:
            active = await VipManager.list_active_vips()
        except Exception:
            return mapping
        for user_id, data in active:
            rid = data.get("custom_role_id")
            if not rid:
                continue
            try:
                rid_int = int(rid)
            except (TypeError, ValueError):
                continue
            members: list[int] = []
            for m in (data.get("role_members") or []):
                try:
                    members.append(int(m))
                except (TypeError, ValueError):
                    continue
            mapping[rid_int] = {"owner": user_id, "members": members}
        return mapping

    def _static_vip_role_ids(self) -> set[int]:
        ids: set[int] = set()
        for plan in VipManager.get_plans():
            rid = plan.get("roleId")
            if rid:
                try:
                    ids.add(int(rid))
                except (TypeError, ValueError):
                    pass
        config = VipManager.get_config()
        for key in ("top_role_id", "bottom_role_id"):
            raw = config.get(key)
            if raw:
                try:
                    ids.add(int(raw))
                except (TypeError, ValueError):
                    pass
        return ids

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.cleanup_loop.is_running():
            self.cleanup_loop.start()
        if not self._startup_done:
            self._startup_done = True
            try:
                await self._position_separators()
            except Exception as e:
                print(f"[VIP PROTECTION] Falha no posicionamento inicial de separadores: {e}")

    def cog_unload(self):
        self.cleanup_loop.cancel()

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        data = VipManager.get_user_vip(member.id)
        if not data:
            return
        guild = member.guild
        dirty = False

        channel_id = data.get("channel_id")
        if channel_id:
            try:
                channel = guild.get_channel(int(channel_id))
            except (TypeError, ValueError):
                channel = None
            if channel:
                try:
                    await channel.delete(reason="VIP: dono saiu do servidor")
                except Exception:
                    pass
                try:
                    await VipLogger.channel_deleted(self.bot, member, "dono saiu do servidor")
                except Exception:
                    pass
                await asyncio.sleep(_DISCORD_OP_DELAY)
            data["channel_id"] = None
            dirty = True

        role_id = data.get("custom_role_id")
        if role_id:
            try:
                role = guild.get_role(int(role_id))
            except (TypeError, ValueError):
                role = None
            if role:
                role_name = role.name
                try:
                    await role.delete(reason="VIP: dono saiu do servidor")
                except Exception:
                    pass
                try:
                    await VipLogger.role_deleted(self.bot, member, role_name, "dono saiu do servidor")
                except Exception:
                    pass
                await asyncio.sleep(_DISCORD_OP_DELAY)
            data["custom_role_id"] = None
            data["role_members"] = []
            dirty = True

        if dirty:
            VipManager.save_user_vip(member.id, data)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: disnake.Role, after: disnake.Role):
        if after.id in self._pending_reverts:
            return

        mapping = await self._custom_role_map()
        if after.id not in mapping:
            return

        needs_revert = False
        reasons: list[str] = []

        if before.permissions != after.permissions:
            needs_revert = True
            reasons.append("permissões")
        if before.hoist != after.hoist:
            needs_revert = True
            reasons.append("exibir separado")
        if before.mentionable != after.mentionable:
            needs_revert = True
            reasons.append("menção")

        if not needs_revert:
            return

        self._pending_reverts.add(after.id)
        try:
            await after.edit(
                permissions=before.permissions,
                hoist=before.hoist,
                mentionable=before.mentionable,
                reason=f"Proteção VIP: revertido ({', '.join(reasons)})",
            )
            print(f"[VIP PROTECTION] Cargo {after.name} ({after.id}): revertido {', '.join(reasons)}")
        except Exception as e:
            print(f"[VIP PROTECTION] Falha ao reverter {after.id}: {e}")
        finally:
            await asyncio.sleep(1)
            self._pending_reverts.discard(after.id)

    @commands.Cog.listener()
    async def on_member_update(self, before: disnake.Member, after: disnake.Member):
        if before.roles == after.roles:
            return
        await asyncio.sleep(1)
        await self.verify_member_vips(after)

    async def verify_member_vips(self, member: disnake.Member):
        """Garante que o cargo do plano VIP esteja aplicado se o VIP é ativo."""
        if member.bot:
            return
        data = VipManager.get_user_vip(member.id)
        if not data or not data.get("status") or VipManager.is_expired(data):
            return
        plan = VipManager.get_plan(data.get("plan"))
        if not plan or not plan.get("roleId"):
            return
        try:
            role = member.guild.get_role(int(plan["roleId"]))
        except (TypeError, ValueError):
            role = None
        if not role:
            return
        if role in member.roles:
            return
        try:
            await member.add_roles(role, reason="Proteção VIP: reaplicando cargo do plano")
        except Exception as e:
            print(f"[VIP PROTECTION] Falha ao reaplicar cargo VIP em {member.id}: {e}")

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        """Restaura estado do membro ao retornar ao servidor:
        1. Se dono de VIP ativo: reaplica cargo do plano + custom_role_id (se existe).
        2. Se membro autorizado em custom_role de outro VIP: reaplica o cargo.
        3. Se membro em allowed_users de outro VIP com canal: restaura permissão."""
        if member.bot:
            return
        guild = member.guild

        try:
            active = await VipManager.list_active_vips()
        except Exception as e:
            print(f"[VIP PROTECTION] Falha list_active_vips on_member_join: {e}")
            return

        own_data = None
        for user_id, data in active:
            if user_id == member.id:
                own_data = data
                break

        if own_data:
            plan = VipManager.get_plan(own_data.get("plan"))
            if plan and plan.get("roleId"):
                try:
                    plan_role = guild.get_role(int(plan["roleId"]))
                except (TypeError, ValueError):
                    plan_role = None
                if plan_role and plan_role not in member.roles:
                    try:
                        await member.add_roles(plan_role, reason="VIP Protection: retorno ao servidor (plano)")
                        await asyncio.sleep(_DISCORD_OP_DELAY)
                    except Exception as e:
                        print(f"[VIP PROTECTION] Falha reaplicar cargo de plano {member.id}: {e}")

            custom_rid = own_data.get("custom_role_id")
            if custom_rid:
                try:
                    own_role = guild.get_role(int(custom_rid))
                except (TypeError, ValueError):
                    own_role = None
                if own_role and own_role not in member.roles:
                    try:
                        await member.add_roles(own_role, reason="VIP Protection: retorno do dono (custom role)")
                        await asyncio.sleep(_DISCORD_OP_DELAY)
                    except Exception as e:
                        print(f"[VIP PROTECTION] Falha reaplicar custom role do dono {member.id}: {e}")

        for user_id, data in active:
            if user_id == member.id:
                continue

            role_members_raw = data.get("role_members") or []
            role_members: list[int] = []
            for m in role_members_raw:
                try:
                    role_members.append(int(m))
                except (TypeError, ValueError):
                    continue
            if member.id in role_members:
                custom_rid = data.get("custom_role_id")
                if custom_rid:
                    try:
                        role = guild.get_role(int(custom_rid))
                    except (TypeError, ValueError):
                        role = None
                    if role and role not in member.roles:
                        try:
                            await member.add_roles(role, reason="VIP Protection: retorno ao grupo de cargo")
                            await asyncio.sleep(_DISCORD_OP_DELAY)
                        except Exception as e:
                            print(f"[VIP PROTECTION] Falha restaurar custom role de {user_id} em {member.id}: {e}")

            allowed_raw = data.get("allowed_users") or []
            allowed: list[int] = []
            for u in allowed_raw:
                try:
                    allowed.append(int(u))
                except (TypeError, ValueError):
                    continue
            if member.id in allowed:
                channel_id = data.get("channel_id")
                if channel_id:
                    try:
                        channel = guild.get_channel(int(channel_id))
                    except (TypeError, ValueError):
                        channel = None
                    if channel:
                        locked = bool(data.get("locked"))
                        try:
                            await channel.set_permissions(
                                member,
                                connect=not locked,
                                view_channel=True,
                                reason="VIP Protection: retorno com permissão no canal",
                            )
                            await asyncio.sleep(_DISCORD_OP_DELAY)
                        except Exception as e:
                            print(f"[VIP PROTECTION] Falha restaurar permissão canal {channel_id} em {member.id}: {e}")

    async def _position_separators(self):
        """Move top_role_id acima e bottom_role_id abaixo dos custom roles.
        Só age se AMBOS estiverem configurados e existirem no guild."""
        guild = ServerManager.get_guild(self.bot, "main")
        if guild is None:
            guild = next(iter(self.bot.guilds), None)
        if guild is None:
            return

        config = VipManager.get_config()
        top_raw = config.get("top_role_id")
        bottom_raw = config.get("bottom_role_id")
        if not top_raw or not bottom_raw:
            return

        try:
            top_role = guild.get_role(int(top_raw))
            bottom_role = guild.get_role(int(bottom_raw))
        except (TypeError, ValueError):
            return
        if not top_role or not bottom_role:
            return

        mapping = await self._custom_role_map()
        custom_positions = [
            guild.get_role(rid).position
            for rid in mapping.keys()
            if guild.get_role(rid) is not None
        ]
        if not custom_positions:
            return

        highest_custom = max(custom_positions)
        lowest_custom = min(custom_positions)

        try:
            if top_role.position <= highest_custom:
                await top_role.edit(position=highest_custom + 1, reason="VIP: posicionar separador topo")
                await asyncio.sleep(_DISCORD_OP_DELAY)
            if bottom_role.position >= lowest_custom:
                new_pos = max(1, lowest_custom - 1)
                await bottom_role.edit(position=new_pos, reason="VIP: posicionar separador base")
                await asyncio.sleep(_DISCORD_OP_DELAY)
        except Exception as e:
            print(f"[VIP PROTECTION] Falha ao posicionar separadores: {e}")

    async def cleanup_orphan_custom_roles(self, guild: disnake.Guild) -> dict:
        """Deleta cargos que estão entre top e bottom mas não pertencem a nenhum VIP ativo.
        Retorna {"deleted": [names], "count": N}."""
        config = VipManager.get_config()
        top_raw = config.get("top_role_id")
        bottom_raw = config.get("bottom_role_id")
        if not top_raw or not bottom_raw:
            return {"deleted": [], "count": 0}

        try:
            top_role = guild.get_role(int(top_raw))
            bottom_role = guild.get_role(int(bottom_raw))
        except (TypeError, ValueError):
            return {"deleted": [], "count": 0}
        if not top_role or not bottom_role:
            return {"deleted": [], "count": 0}

        mapping = await self._custom_role_map()
        valid_ids: set[int] = set(mapping.keys())
        valid_ids.update(self._static_vip_role_ids())

        top_pos = top_role.position
        bottom_pos = bottom_role.position
        deleted: list[str] = []

        for role in guild.roles:
            if bottom_pos < role.position < top_pos and role.id not in valid_ids:
                try:
                    role_name = role.name
                    self._pending_reverts.add(role.id)
                    await role.delete(reason="VIP: cargo órfão entre separadores")
                    deleted.append(role_name)
                    print(f"[VIP PROTECTION] Cargo órfão deletado: {role_name} ({role.id})")
                    await asyncio.sleep(_DISCORD_OP_DELAY)
                except Exception as e:
                    print(f"[VIP PROTECTION] Falha ao deletar órfão {role.id}: {e}")
                finally:
                    self._pending_reverts.discard(role.id)

        return {"deleted": deleted, "count": len(deleted)}

    async def enforce_role_member_limits(self, guild: disnake.Guild) -> dict:
        """Para cada custom role ativo: se role_members excede plan.roleMemberLimit, remove excedentes."""
        try:
            active = await VipManager.list_active_vips()
        except Exception:
            return {}

        results: dict = {}
        for owner_id, data in active:
            rid_raw = data.get("custom_role_id")
            if not rid_raw:
                continue
            try:
                rid = int(rid_raw)
            except (TypeError, ValueError):
                continue

            role = guild.get_role(rid)
            if not role:
                continue

            plan = VipManager.get_plan(data.get("plan"))
            if not plan:
                continue
            features = plan.get("features") or {}
            try:
                limit = int(features.get("roleMemberLimit", 3))
            except (TypeError, ValueError):
                limit = 3

            members_raw = data.get("role_members") or []
            members: list[int] = []
            for m in members_raw:
                try:
                    members.append(int(m))
                except (TypeError, ValueError):
                    continue

            if len(members) <= limit:
                continue

            excess = len(members) - limit
            random.shuffle(members)
            to_remove = members[:excess]
            remaining = members[excess:]

            data["role_members"] = remaining
            VipManager.save_user_vip(owner_id, data)

            for uid in to_remove:
                target = guild.get_member(uid)
                if target and role in target.roles:
                    try:
                        await target.remove_roles(role, reason=f"VIP: limite de membros excedido ({limit})")
                    except Exception:
                        pass
                    await asyncio.sleep(0.1)

            results[rid] = {"owner_id": owner_id, "limit": limit, "removed": to_remove, "remaining": len(remaining)}
            print(f"[VIP PROTECTION] Cargo {rid}: {len(to_remove)} membros removidos (limite: {limit})")

        return results

    @tasks.loop(hours=24)
    async def cleanup_loop(self):
        try:
            guild = ServerManager.get_guild(self.bot, "main")
            if guild is None:
                guild = next(iter(self.bot.guilds), None)
            if guild is None:
                return
            await self.cleanup_orphan_custom_roles(guild)
            await self.enforce_role_member_limits(guild)
        except Exception as e:
            print(f"[VIP PROTECTION] cleanup_loop falhou: {e}")

    @cleanup_loop.before_loop
    async def before_cleanup_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(VipProtection(bot))
