"""Aplica `bot_config.presence` (escrito pela dashboard) na presence real do Discord.

Lê do cache (sincronizado por cache_sync.py) e chama bot.change_presence sempre
que algo muda. Se houver múltiplos `names`, alterna entre eles a cada 30s.
"""

import disnake
from disnake.ext import commands, tasks

from functions.database import Database


_STATUS_MAP = {
    "online": disnake.Status.online,
    "idle": disnake.Status.idle,
    "dnd": disnake.Status.dnd,
    "invisible": disnake.Status.invisible,
    "offline": disnake.Status.invisible,
}

_ACTIVITY_TYPE_MAP = {
    "playing": disnake.ActivityType.playing,
    "listening": disnake.ActivityType.listening,
    "watching": disnake.ActivityType.watching,
    "competing": disnake.ActivityType.competing,
}


def _build_activity(activity_type: str, name: str, stream_url: str):
    if not name or activity_type == "none":
        return None
    if activity_type == "streaming":
        url = stream_url or "https://twitch.tv/discord"
        return disnake.Streaming(name=name, url=url)
    a_type = _ACTIVITY_TYPE_MAP.get(activity_type, disnake.ActivityType.playing)
    return disnake.Activity(type=a_type, name=name)


class PresenceSyncModule(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_signature: str | None = None
        self._rotate_index: int = 0
        self._cached_names: list[str] = []
        self._cached_status = disnake.Status.online
        self._cached_activity_type = "playing"
        self._cached_stream_url = ""

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.presence_loop.is_running():
            self.presence_loop.start()

    def cog_unload(self):
        self.presence_loop.cancel()

    @tasks.loop(seconds=15)
    async def presence_loop(self):
        try:
            cfg = Database.get_document_ref("bot_config") or {}
            presence = cfg.get("presence") or {}

            status_str = str(presence.get("status") or "online").lower()
            activity_type = str(presence.get("activityType") or "playing").lower()
            stream_url = str(presence.get("streamUrl") or "")
            names_raw = presence.get("names") or []
            if not isinstance(names_raw, list):
                names_raw = []
            names = [str(n).strip() for n in names_raw if str(n).strip()]

            signature = f"{status_str}|{activity_type}|{stream_url}|{'~'.join(names)}"
            config_changed = signature != self._last_signature

            if config_changed:
                self._last_signature = signature
                self._cached_names = names
                self._cached_status = _STATUS_MAP.get(status_str, disnake.Status.online)
                self._cached_activity_type = activity_type
                self._cached_stream_url = stream_url
                self._rotate_index = 0
            elif len(self._cached_names) <= 1:
                # nada mudou e não há rotação a fazer
                return

            if not self._cached_names:
                await self.bot.change_presence(status=self._cached_status, activity=None)
                return

            name = self._cached_names[self._rotate_index % len(self._cached_names)]
            self._rotate_index = (self._rotate_index + 1) % max(1, len(self._cached_names))
            activity = _build_activity(self._cached_activity_type, name, self._cached_stream_url)
            await self.bot.change_presence(status=self._cached_status, activity=activity)
        except Exception as e:
            print(f"[PRESENCE_SYNC] Erro: {e}")

    @presence_loop.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(PresenceSyncModule(bot))
