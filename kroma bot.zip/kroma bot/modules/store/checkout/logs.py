import disnake
from typing import Any
from functions.database import Database
from functions.servers import ServerManager
from functions.servers import ServerManager


async def send_store_log(
    bot,
    log_type: str,
    data: dict[str, Any],
    inter: disnake.Interaction | None = None,
    ephemeral: bool = False,
    user_override: disnake.Member | None = None
) -> None:
    """
    Envia logs da loja para os canais configurados.

    Args:
        bot: Instância do bot.
        log_type: Tipo de log (public, private, cart, preview_*).
        data: Dados do log.
        inter: Interação opcional para preview.
        ephemeral: Se a mensagem deve ser efêmera.
        user_override: Membro para usar em vez do autor da interação.
    """
    from functions.media import ImageHandler

    prefs = Database.get_document("loja_preferences") or {}
    color_data = Database.get_document("custom_colors") or {}
    primary_hex = color_data.get("primary", "#5865F2")

    target_type = log_type.replace("preview_", "")
    is_preview = log_type.startswith("preview_")

    target_channel = None
    if not is_preview:
        channel_id = prefs.get(f"log_{target_type}_id")
        if not channel_id:
            return

        target_guild = ServerManager.get_guild(bot, "logs") or (inter.guild if inter else None)
        if not target_guild:
            return

        target_channel = target_guild.get_channel(int(channel_id))
    else:
        target_channel = inter.channel if inter else None

    msg_flags = disnake.MessageFlags(
        is_components_v2=True,
        ephemeral=(ephemeral or is_preview)
    )


    if target_type == "public":
        try:
            u = user_override or (inter.author if inter else None)
            u_name = u.display_name if u else "Cliente"
            u_handle = u.name if u else "cliente"
            u_avatar = u.display_avatar.url if u else bot.user.display_avatar.url

            items_text = data.get("Produto", "Produto").replace("**", "")
            val_raw = data.get("Valor", "0").replace("`R$ ", "").replace("`", "").replace(",", ".")
            try:
                total_val = float(val_raw)
            except Exception:
                total_val = 0.0

            img_buf = await ImageHandler.generate_purchase_image(
                user_name=u_name,
                user_avatar_url=u_avatar,
                items_summary=f"| {items_text} - R$ {total_val:.2f}",
                total_price=total_val,
                bot_name=bot.user.name,
                bot_avatar_url=bot.user.display_avatar.url,
                server_name=inter.guild.name if inter and inter.guild else (target_guild.name if target_guild else bot.user.name),
                user_handle=u_handle
            )

            file = disnake.File(img_buf, filename="purchase_log.png")
            components = []
            row = disnake.ui.ActionRow()

            buy_url = data.get("ProductURL") or "https://discord.com"
            row.add_button(label="Comprar", style=disnake.ButtonStyle.link, url=buy_url)

            feed_id = prefs.get("log_feedbacks_id")
            if feed_id and bot.get_channel(int(feed_id)):
                from functions.utils import Utils
                guild_id = inter.guild.id if inter and inter.guild else Utils.get_server_id()
                row.add_button(
                    label="Ver Feedbacks",
                    style=disnake.ButtonStyle.link,
                    url=f"https://discord.com/channels/{guild_id}/{feed_id}"
                )

            if is_preview:
                row.add_button(label="Próximo", style=disnake.ButtonStyle.grey, custom_id="Loja_Pref_LogPreview_Next:private")

            components.append(row)

            if is_preview and inter:
                kwargs = {"file": file, "components": components}
                if inter.response.is_done():
                    await inter.followup.send(**kwargs, ephemeral=True)
                else:
                    await inter.response.send_message(**kwargs, ephemeral=True)
            elif target_channel:
                await target_channel.send(file=file, components=components)
            return

        except Exception as e:
            print(f"[STORE LOG] Erro ao gerar imagem de log público: {e}")


    title_map = {
        "private": ("Registro de Venda", "Painel > Loja > Auditoria > **Vendas**"),
        "cart": ("Monitoramento de Carrinho", "Painel > Loja > Auditoria > **Carrinhos**")
    }
    main_name, breadcrumb = title_map.get(target_type, ("Log do Sistema", "Painel > Sistema > **Logs**"))

    container_components = [
        disnake.ui.TextDisplay(f"# {main_name}\n-# {breadcrumb}"),
        disnake.ui.Separator()
    ]

    info_lines = []
    for k, v in data.items():
        if k == "ProductURL":
            continue
        info_lines.append(f"**{k}:** {v}")

    if info_lines:
        container_components.append(disnake.ui.TextDisplay("\n".join(info_lines)))

    container = disnake.ui.Container(*container_components)
    components = [container]

    if is_preview:
        next_map = {"private": "cart", "cart": "public", "public": "private"}
        nxt = next_map.get(target_type, "public")
        components.append(disnake.ui.ActionRow(
            disnake.ui.Button(label="Próximo Exemplo", style=disnake.ButtonStyle.grey, custom_id=f"Loja_Pref_LogPreview_Next:{nxt}")
        ))

    try:
        if is_preview and inter:
            kwargs = {"components": components, "flags": msg_flags, "allowed_mentions": disnake.AllowedMentions.none()}
            if inter.response.is_done():
                await inter.followup.send(**kwargs)
            else:
                await inter.response.send_message(**kwargs)
        elif target_channel:
            await target_channel.send(components=components, flags=msg_flags, allowed_mentions=disnake.AllowedMentions.none())
    except Exception as e:
        print(f"[STORE LOG] Erro ao enviar log: {e}")
