import re
import disnake
import asyncio
import datetime
from typing import Any

from functions.database import Database
from modules.store.stock.manager import StockManager

def _parse_emoji(icon_str: str):
    if not icon_str:
        return None
    m = re.match(r'^<(a?):([^:]+):(\d+)>$', icon_str)
    if not m:
        return None
    return disnake.PartialEmoji(name=m.group(2), id=int(m.group(3)), animated=bool(m.group(1)))


async def get_cart_dashboard(cart_data: dict, user_id: int = None, is_disabled: bool = False, processing_action: str = None) -> dict:
    """
    Gera o dashboard do carrinho de compras.

    Args:
        cart_data: Dados do carrinho.
        user_id: ID do usuário (para verificação de permissões).
        is_disabled: Se True, todos os botões serão desabilitados.
        processing_action: Nome da ação em curso ('checkout' ou 'cancel') para mudar apenas o label específico.

    Returns:
        dict com components para o painel.
    """
    from functions.permissions import Permissions

    products = Database.get_document("loja_products")
    total = 0
    item_count = 0

    container_kwargs = {}

    cart_id = cart_data["cart_id"]

    dashboard_header = "### Carrinho de Compras"

    cancel_btn = disnake.ui.Button(
        label="Cancelar",
        style=disnake.ButtonStyle.red,
        custom_id=f"Cart_Cancel:{cart_id}",
        disabled=False
    )

    container_components = [
        disnake.ui.Section(
            disnake.ui.TextDisplay(dashboard_header),
            accessory=cancel_btn
        ),
    ]

    for i, item in enumerate(cart_data["items"]):
        p = products.get(item["product_id"], {})
        f = p.get("campos", {}).get(item["field_id"], {})
        qty = item["qty"]
        price = item["price"]
        sub = price * qty
        total += sub
        item_count += qty

        available = 999
        is_infinite = False
        field_data = p.get("campos", {}).get(item["field_id"], {})
        if field_data.get("infinite_stock", {}).get("enabled"):
            is_infinite = True
        else:
            available = StockManager.get_available_stock(item["product_id"], item["field_id"])

        p_name = p.get("name", "Produto")
        f_name = f.get("name", "")
        f_icon = f.get("icon", "")

        item_text = f"`{qty}x` **{p_name}**"
        if f_name:
            icon_prefix = f"{f_icon} " if f_icon else ""
            item_text += f" – {icon_prefix}{f_name}"

        stock_display = "∞" if is_infinite else str(available)
        item_text += f"\n-# Valor por item: `R${price:.2f}` | Subtotal: `R${sub:.2f}` | Estoque disponível: `{stock_display}`"

        edit_btn = disnake.ui.Button(
            label="Editar",
            style=disnake.ButtonStyle.grey,
            custom_id=f"Cart_EditItem:{cart_id}:{item['product_id']}:{item['field_id']}",
            disabled=is_disabled
        )

        container_components.append(disnake.ui.Separator())
        container_components.append(disnake.ui.Section(
            disnake.ui.TextDisplay(item_text),
            accessory=edit_btn
        ))

    container_components.append(disnake.ui.Separator())

    discount_percent = cart_data.get("discount_percent", 0)
    coupon_text = "nenhum cupom aplicado"
    if discount_percent > 0:
        coupon_name = cart_data.get("coupon_code", "CUPOM")
        coupon_text = f"**{coupon_name}** (`{discount_percent}%` de desconto)"

    additional_resources = cart_data.get("additional_resources", [])
    resources_text = "nenhum recurso adicionado"
    if additional_resources:
        resources_text = ", ".join([f"**{r['name']}**" for r in additional_resources])

    info_text = (
        f"**Informações adicionais do seu carrinho**\n"
        f"Cupom de desconto: {coupon_text}\n"
        f"Recursos adicionais: {resources_text}"
    )
    container_components.append(disnake.ui.TextDisplay(info_text))

    options = [disnake.SelectOption(label="Nenhum recurso disponível", value="none")]
    container_components.append(disnake.ui.ActionRow(
        disnake.ui.StringSelect(
            custom_id=f"Cart_AddResources:{cart_id}",
            placeholder="Selecione recursos adicionais desejados",
            options=options,
            disabled=True
        )
    ))

    container_components.append(disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Editar cupom de desconto",
            style=disnake.ButtonStyle.grey,
            custom_id=f"Cart_Coupon:{cart_id}",
            disabled=is_disabled
        ),
        disnake.ui.Button(
            label="Ler termos da loja",
            style=disnake.ButtonStyle.grey,
            custom_id=f"Cart_ShowTerms:{cart_id}",
            disabled=is_disabled
        )
    ))

    summary_components = []

    payment_method = cart_data.get("payment_method", "pix")
    method_names = {"pix": "PIX", "card": "Cartão de Crédito"}
    payment_display = method_names.get(payment_method, payment_method.upper())
    product_count = len(cart_data["items"])

    original_total = total
    discount_percent = cart_data.get("discount_percent", 0)
    discount_amount = 0
    if discount_percent > 0:
        discount_amount = original_total * (discount_percent / 100)
        total = original_total - discount_amount

    summary_text = f"**Informações do seu carrinho**\n"
    summary_text += f"Quantidade de produtos: `{product_count}` | Quantidade de itens: `{item_count}`\n"

    if discount_percent > 0:
        coupon_name = cart_data.get("coupon_code", "CUPOM")
        summary_text += f"Cupom de desconto: `{coupon_name}` (`{discount_percent}%` de desconto) | `-R${discount_amount:.2f}`\n"

    summary_text += f"Subtotal sem desconto: `R${original_total:.2f}` | Adicionais selecionados: `0`"
    summary_components.append(disnake.ui.TextDisplay(summary_text))

    summary_components.append(disnake.ui.Separator())

    checkout_label = "Prosseguir para o pagamento"
    if processing_action == "checkout":
        checkout_label = "Processando..."

    checkout_buttons = [
        disnake.ui.Button(
            label=f"Total da compra: R${total:.2f}",
            style=disnake.ButtonStyle.grey,
            custom_id=f"Cart_TotalInfo:{cart_id}",
            disabled=True
        ),
        disnake.ui.Button(
            label=checkout_label,
            style=disnake.ButtonStyle.green,
            custom_id=f"Cart_FinalizeTrigger:{cart_id}",
            disabled=is_disabled
        ),
    ]

    summary_components.append(disnake.ui.ActionRow(*checkout_buttons))

    return {
        "components": [
            disnake.ui.Container(*container_components, **container_kwargs),
            disnake.ui.Container(*summary_components, **container_kwargs),
        ]
    }


async def create_cart_thread(
    inter: disnake.MessageInteraction,
    product_id: str,
    field_id: str,
    support_code: str = None,
    mode: str = "buy",
    form_data: dict = None
) -> None:
    """
    Cria thread de carrinho para o usuário.

    Args:
        inter: Interação do Discord.
        product_id: ID do produto.
        field_id: ID do campo/variante.
        support_code: Código de apoiador (opcional).
        mode: Modo de compra (buy ou reserve).
        form_data: Dados do formulário preenchido (para tipo contas).
    """
    from .logs import send_store_log

    v2_flag = disnake.MessageFlags(is_components_v2=True, ephemeral=True)


    products = Database.get_document("loja_products")
    product = products.get(product_id)
    if not product:
        return

    if not field_id:
        campos = product.get("campos", {})
        if campos:
            field_id = list(campos.keys())[0]
        else:

            comp = [disnake.ui.Container(disnake.ui.TextDisplay("### ❌ Erro\n-# Este produto não possui opções de compra configuradas."))]
            if not inter.response.is_done():
                await inter.response.send_message(components=comp, ephemeral=True, flags=v2_flag)
            else:
                await inter.edit_original_message(components=comp, flags=v2_flag)
            return


    maint = Database.get_document("loja_maintenance") or {}
    if maint.get("enabled"):
        adm = maint.get("allow_admins", True)
        if not (adm and inter.author.guild_permissions.administrator):
            msg = maint.get("message", "Loja em manutenção.").format(user=inter.author.mention)
            return await inter.response.send_message(msg, ephemeral=True)

    prefs = Database.get_document("loja_preferences") or {}


    user_id = str(inter.user.id)
    loja_data = Database.get_document("loja_data") or {"carts": {}}
    for cid, c in loja_data.get("carts", {}).items():
        if str(c.get("user_id")) == user_id and c.get("status") == "cart":
            thread = inter.guild.get_thread(int(c.get("thread_id")))
            if thread:
                comp = [
                    disnake.ui.Container(disnake.ui.TextDisplay("Você já possui um carrinho aberto!")),
                    disnake.ui.ActionRow(disnake.ui.Button(label="Ver meu carrinho", url=thread.jump_url))
                ]
                if not inter.response.is_done():
                    await inter.response.send_message(components=comp, ephemeral=True, flags=v2_flag)
                else:
                    await inter.edit_original_message(content=None, components=comp, flags=v2_flag)
                return


    oh = prefs.get("office_hours", {})
    if oh.get("enabled"):
        try:
            import datetime as dt
            now = dt.datetime.now()
            c_day = ["seg", "ter", "qua", "qui", "sex", "sab", "dom"][now.weekday()]
            if c_day in oh.get("off_days", []):
                return await inter.response.send_message(
                    oh.get("message", "Loja fechada hoje.").format(start_time=oh.get("start_time"), end_time=oh.get("end_time")),
                    ephemeral=True
                )

            cur_t = now.strftime("%H:%M")
            if not (oh.get("start_time") <= cur_t <= oh.get("end_time")):
                return await inter.response.send_message(
                    oh.get("message", "Loja fechada agora.").format(start_time=oh.get("start_time"), end_time=oh.get("end_time")),
                    ephemeral=True
                )
        except Exception:
            pass


    loading_text = "Aguarde..."
    comp = [disnake.ui.Container(disnake.ui.TextDisplay(loading_text), )]

    if not inter.response.is_done():

        await inter.response.send_message(components=comp, flags=v2_flag)
    else:

        await inter.edit_original_message(content=None, components=comp, flags=v2_flag)


    def get_loading_comp(text):
        return [disnake.ui.Container(disnake.ui.TextDisplay(text), )]

    await inter.edit_original_message(components=get_loading_comp("Aguarde, verificando condições..."), flags=v2_flag)
    await inter.edit_original_message(components=get_loading_comp("Aguarde, verificando estoque..."), flags=v2_flag)
    await inter.edit_original_message(components=get_loading_comp("Aguarde, criando carrinho..."), flags=v2_flag)

    product = products.get(product_id)
    field = product["campos"].get(field_id)


    if await StockManager.get_available_stock_fresh(product_id, field_id) <= 0:
        return await inter.edit_original_message(
            content=None,
            components=[disnake.ui.Container(disnake.ui.TextDisplay("### ❌ Sem Estoque\n-# Desculpe, este item acabou de esgotar."))],
            flags=v2_flag
        )


    thread_name = f"🛒・{inter.user.name}・{inter.user.id}"
    target_channel = inter.channel
    if isinstance(target_channel, disnake.Thread):
        target_channel = target_channel.parent


    if isinstance(target_channel, (disnake.ForumChannel, disnake.MediaChannel)):

        overwrites = {
            inter.guild.default_role: disnake.PermissionOverwrite(read_messages=False),
            inter.user: disnake.PermissionOverwrite(read_messages=True, send_messages=True),
            inter.guild.me: disnake.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
        }

        thread = await inter.guild.create_text_channel(
            name=thread_name[:100],
            category=target_channel.category,
            overwrites=overwrites,
            reason=f"Carrinho aberto por {inter.user.name}"
        )
    else:

        create_kwargs = {"name": thread_name[:100]}

        if isinstance(target_channel, (disnake.TextChannel, disnake.NewsChannel)):
            create_kwargs["type"] = disnake.ChannelType.private_thread
            create_kwargs["invitable"] = False
        else:

            create_kwargs["content"] = f"### 🛒 Carrinho de {inter.user.mention}\n-# Este tópico foi criado para gerenciar sua compra."

        result = await target_channel.create_thread(**create_kwargs)
        thread = result.thread if isinstance(result, disnake.ThreadWithMessage) else result

    await inter.edit_original_message(
        content=None,
        components=[
            disnake.ui.Container(
                disnake.ui.TextDisplay("-# Seu carrinho foi criado com sucesso!"),

            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Ir para o carrinho", url=thread.jump_url, style=disnake.ButtonStyle.url)
            )
        ],
        flags=v2_flag
    )

    await thread.send(inter.user.mention, delete_after=1)


    original_price = field.get("price", 0)
    final_price = original_price

    if mode == "reserve":
        res_config = product.get("info", {}).get("reservation", {})
        percent = res_config.get("percentage", 33.33)
        final_price = original_price * (percent / 100)


    discount_percent = 0
    display_coupon = product.get("info", {}).get("display_coupon")
    if display_coupon:
        product_cupons = product.get("cupons", {})
        if display_coupon in product_cupons:
            coupon_data = product_cupons[display_coupon]
            max_usos = coupon_data.get("max_usos", 0)
            usos = coupon_data.get("usos", 0)
            if max_usos == 0 or usos < max_usos:
                discount_percent = coupon_data.get("porcentagem", 0)


    cart_id = str(thread.id)
    cart_data = {
        "cart_id": cart_id,
        "thread_id": thread.id,
        "user_id": inter.user.id,
        "guild_id": inter.guild.id,
        "items": [{"product_id": product_id, "field_id": field_id, "qty": 1, "price": final_price, "original_price": original_price}],
        "status": "cart",
        "mode": mode,
        "payment_method": "pix",
        "support_code": support_code,
        "discount_percent": discount_percent,
        "source_channel_id": inter.channel.id,
        "created_at": int(datetime.datetime.utcnow().timestamp()),
        "form_data": form_data
    }


    if discount_percent > 0 and display_coupon:
        product["cupons"][display_coupon]["usos"] = product["cupons"][display_coupon].get("usos", 0) + 1
        Database.save_document("loja_products", products)

    loja_data["carts"][cart_id] = cart_data
    Database.save_document("loja_data", loja_data)


    dashboard = await get_cart_dashboard(cart_data, inter.author.id)
    msg = await thread.send(**dashboard, flags=disnake.MessageFlags(is_components_v2=True))

    loja_data["carts"][cart_id]["message_id"] = msg.id
    Database.save_document("loja_data", loja_data)


    await send_store_log(inter.bot, "cart", {
        "Evento": "🛒 Carrinho Aberto",
        "Usuário": f"{inter.user.mention} (`{inter.user.id}`)",
        "Produto": f"**{product.get('name')}**",
        "Tópico": thread.mention
    })


async def start_checkout(inter: disnake.MessageInteraction, product_id: str, support_code: str = None, mode: str = "buy", form_data: dict = None) -> None:
    """
    Inicia o processo de checkout para um produto.

    Args:
        inter: Interação do Discord.
        product_id: ID do produto.
        support_code: Código de apoiador (opcional).
        mode: Modo de compra (buy ou reserve).
        form_data: Dados do formulário preenchido (para tipo contas).
    """
    products = Database.get_document("loja_products")
    product = products.get(product_id)

    if not product:
        await inter.response.send_message("Produto não encontrado.", ephemeral=True)
        return

    campos = product.get("campos", {})
    if not campos:
        await inter.response.send_message("Este produto não possui campos configurados.", ephemeral=True)
        return

    if len(campos) > 1:
        options = []
        for fid, f in campos.items():
            name = f.get("name", "Sem nome")
            price = f.get("price", 0)
            is_infinite = f.get("infinite_stock", {}).get("enabled", False)
            stock_count = await StockManager.get_available_stock_fresh(product_id, fid)
            stock_display = "∞" if is_infinite else str(stock_count)

            opt_kwargs = {"label": name, "description": f"R$ {price:.2f} | Estoque: {stock_display}", "value": fid}
            parsed = _parse_emoji(f.get("icon", ""))
            if parsed:
                opt_kwargs["emoji"] = parsed
            options.append(disnake.SelectOption(**opt_kwargs))


        form_data_key = ""
        if form_data:
            import time
            form_data_key = f"{inter.author.id}_{int(time.time())}"
            temp_forms = Database.get_document("temp_form_data") or {}
            temp_forms[form_data_key] = form_data
            Database.save_document("temp_form_data", temp_forms)

        await inter.response.send_message(
            components=[
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(custom_id=f"Checkout_FieldSelect:{product_id}:{support_code or ''}:{mode}:{form_data_key}", options=options, placeholder="Escolha uma opção")
                )
            ],
            ephemeral=True
        )
    else:
        field_id = list(campos.keys())[0]
        await create_cart_thread(inter, product_id, field_id, support_code=support_code, mode=mode, form_data=form_data)
