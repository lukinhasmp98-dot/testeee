import asyncio
import datetime
from typing import TYPE_CHECKING

from disnake.ext import tasks
from functions.database import Database

if TYPE_CHECKING:
    from disnake.ext.commands import Bot


class CheckoutTasks:

    def __init__(self, bot: "Bot", approve_cart_callback):
        self.bot = bot
        self.approve_cart = approve_cart_callback

    def start_tasks(self):
        if not self.check_expiring_carts.is_running():
            self.check_expiring_carts.start()
        if not self.check_active_payments.is_running():
            self.check_active_payments.start()

    def cog_unload(self):
        self.check_expiring_carts.cancel()
        self.check_active_payments.cancel()

    @tasks.loop(minutes=1)
    async def check_expiring_carts(self):
        loja_data = Database.get_document("loja_data")
        if not loja_data or "carts" not in loja_data:
            return

        prefs = Database.get_document("loja_preferences") or {}
        duration_minutes = prefs.get("cart_duration_minutes", 10)
        duration_seconds = duration_minutes * 60

        carts = loja_data["carts"]
        to_remove = []
        now = int(datetime.datetime.utcnow().timestamp())

        for cart_id, cart in list(carts.items()):
            if cart.get("status") == "approved":
                continue

            created_at = cart.get("created_at", now)
            payment_start = cart.get("payment_started_at")

            if not cart.get("reminded"):
                base_time = payment_start or created_at
                if (now - base_time) > (duration_seconds / 2):
                    thread = self.bot.get_channel(int(cart.get("thread_id")))
                    if thread:
                        try:
                            user_id = cart.get("user_id")
                            user = self.bot.get_user(int(user_id))
                            if not user:
                                try: user = await self.bot.fetch_user(int(user_id))
                                except Exception: user = None

                            user_mention = f"<@{user_id}>"

                            if cart.get("status") == "cart":
                                msg = (
                                    f"Olá {user_mention}!\n"
                                    "Notamos que você ainda não finalizou seu pedido. Deseja prosseguir para o pagamento ou precisa de alguma ajuda?\n\n"
                                    "-# **Atenção:** Seu pedido está reservado, mas o tempo está acabando!"
                                )
                            else:
                                msg = (
                                    f"Ei {user_mention}!\n"
                                    "Seu QR Code de pagamento ainda está ativo, mas o tempo está acabando. Não esqueça de finalizar sua compra para receber seu produto agora!\n\n"
                                    "-# **Dica:** O pagamento via PIX é aprovado instantaneamente."
                                )

                            await thread.send(msg)
                            cart["reminded"] = True
                            Database.save_document("loja_data", loja_data)
                        except Exception:
                            pass

            if cart.get("payment_provider") and payment_start:
                if (now - payment_start) > duration_seconds:
                    to_remove.append(cart_id)
                    await self._handle_cart_expiration(cart, cart_id)

            elif cart.get("status") == "cart" and (now - created_at) > duration_seconds:
                to_remove.append(cart_id)
                thread = self.bot.get_channel(int(cart.get("thread_id")))
                if thread:
                    try:
                        await thread.send(f"**Carrinho cancelado por inatividade após {duration_minutes} minutos.**")
                        asyncio.create_task(self._delayed_delete(thread, 5))
                    except Exception:
                        pass

        for cid in to_remove:
            if cid in carts:
                del carts[cid]

        if to_remove:
            Database.save_document("loja_data", loja_data)

    async def _handle_cart_expiration(self, cart: dict, cart_id: str):
        from .logs import send_store_log

        guild = self.bot.get_guild(cart.get("guild_id"))
        if guild:
            user_id = cart.get("user_id")
            await send_store_log(self.bot, "cart", {
                "Evento": "Carrinho Expirado",
                "Usuário": f"<@{user_id}> (`{user_id}`)",
                "Carrinho ID": f"`{cart_id}`"
            })

            thread = guild.get_thread(int(cart.get("thread_id")))
            if thread:
                try:
                    await thread.send("**O tempo de pagamento expirou.** Este tópico será deletado em 10 segundos.")
                    asyncio.create_task(self._delayed_delete(thread, 10))
                except Exception:
                    pass

    @staticmethod
    async def _delayed_delete(thread, seconds: int):
        await asyncio.sleep(seconds)
        try:
            await thread.delete()
        except Exception:
            pass

    @tasks.loop(seconds=5)
    async def check_active_payments(self):
        try:
            loja_data = Database.get_document("loja_data")

            if not loja_data or "carts" not in loja_data:
                return

            carts = loja_data["carts"]

            for cart_id, cart in list(carts.items()):
                status = cart.get("status")
                delivered = cart.get("delivered", False)

                if status == "approved" and not delivered:
                    try:
                        success = await self.approve_cart(cart)

                        if success:
                            loja_data = Database.get_document("loja_data")
                            if cart_id in loja_data.get("carts", {}):
                                loja_data["carts"][cart_id]["delivered"] = True
                                Database.save_document("loja_data", loja_data)
                    except Exception as e:
                        print(f"[CHECKOUT ERROR] Erro ao processar carrinho {cart_id}: {e}")
                        import traceback
                        traceback.print_exc()
                    continue

                if status == "approved" and delivered:
                    continue

                # PIX manual is intentionally approved by a staff member via
                # Cart_ConfirmPayment after checking the receipt.
                if status == "pending_payment":
                    continue
        except Exception as e:
            print(f"[CHECKOUT ERROR] Erro geral na task: {e}")

            import traceback
            traceback.print_exc()

    @check_expiring_carts.before_loop
    async def before_check_expiring_carts(self):
        await self.bot.wait_until_ready()

    @check_active_payments.before_loop
    async def before_check_active_payments(self):
        await self.bot.wait_until_ready()
