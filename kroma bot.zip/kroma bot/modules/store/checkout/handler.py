import re
import datetime
import disnake
import asyncio
from disnake.ext import commands, tasks

from functions.database import Database
from functions.panels import PanelMixin

from .cart import start_checkout, create_cart_thread, get_cart_dashboard
from .logs import send_store_log
from .tasks import CheckoutTasks
from modules.store.stock.manager import StockManager

def _parse_emoji(icon_str: str):
    if not icon_str:
        return None
    m = re.match(r'^<(a?):([^:]+):(\d+)>$', icon_str)
    if not m:
        return None
    return disnake.PartialEmoji(name=m.group(2), id=int(m.group(3)), animated=bool(m.group(1)))


class CheckoutHandler(commands.Cog, PanelMixin):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._tasks = CheckoutTasks(bot, self.approve_cart)
        self._buy_cooldowns = {}

    @commands.Cog.listener()
    async def on_ready(self):
        self._tasks.start_tasks()
        if not self._cleanup_cooldowns.is_running():
            self._cleanup_cooldowns.start()

    def cog_unload(self):
        self._tasks.cog_unload()
        self._cleanup_cooldowns.cancel()


    @staticmethod
    async def send_store_log(bot, log_type: str, data: dict, inter=None, ephemeral=False, user_override=None):
        await send_store_log(bot, log_type, data, inter, ephemeral, user_override)

    @staticmethod
    async def start_checkout(inter: disnake.MessageInteraction, product_id: str):
        await start_checkout(inter, product_id)

    @staticmethod
    async def create_cart_thread(inter: disnake.MessageInteraction, product_id: str, field_id: str):
        await create_cart_thread(inter, product_id, field_id)

    @staticmethod
    async def get_cart_dashboard(cart_data: dict, user_id: int = None) -> dict:
        return await get_cart_dashboard(cart_data, user_id)


    @tasks.loop(minutes=5)
    async def _cleanup_cooldowns(self):
        import time
        current_time = time.time()
        expired = [uid for uid, timestamp in self._buy_cooldowns.items() if current_time - timestamp > 300]
        for uid in expired:
            del self._buy_cooldowns[uid]


    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        try:
            loja_data = Database.get_document("loja_data")
            if not loja_data or "carts" not in loja_data:
                return

            user_id = str(member.id)
            carts_to_remove = []

            for cart_id, cart in list(loja_data.get("carts", {}).items()):
                if str(cart.get("user_id")) != user_id:
                    continue

                if cart.get("delivered"):
                    continue

                carts_to_remove.append(cart_id)


                thread_id = cart.get("thread_id")
                if thread_id:
                    try:
                        thread = member.guild.get_thread(int(thread_id)) or member.guild.get_channel(int(thread_id))
                        if thread:
                            await thread.delete()
                    except Exception:
                        pass

            if carts_to_remove:
                for cart_id in carts_to_remove:
                    del loja_data["carts"][cart_id]
                Database.save_document("loja_data", loja_data)
                print(f"[CHECKOUT] {len(carts_to_remove)} carrinho(s) removido(s) - Membro saiu: {member} ({member.id})")
        except Exception as e:
            print(f"[CHECKOUT ERROR] Erro ao limpar carrinhos de membro que saiu: {e}")


    async def _delayed_delete(self, channel, delay: int):
        await asyncio.sleep(delay)
        try:
            await channel.delete()
        except Exception:
            pass

    async def approve_cart(self, cart: dict) -> bool:
        try:
            from modules.store.stock.manager import StockManager
            from functions.utils import Utils

            cart_id = cart.get("cart_id")
            user_id = cart.get("user_id")
            guild_id = cart.get("guild_id")

            guild = self.bot.get_guild(guild_id)
            if not guild:
                return False

            member = guild.get_member(user_id)
            if not member:
                try:
                    member = await guild.fetch_member(user_id)
                except Exception:
                    pass

            products = Database.get_document("loja_products") or {}
            loja_data = Database.get_document("loja_data") or {"carts": {}}


            if cart_id in loja_data["carts"]:
                loja_data["carts"][cart_id]["status"] = "approved"
                loja_data["carts"][cart_id]["approved_at"] = int(datetime.datetime.utcnow().timestamp())
                # Persiste o total computado pra que o backend (dashboard
                # /stats) possa agregar receita sem reprocessar items.
                try:
                    items_total = sum(it.get("price", 0) * it.get("qty", 1) for it in cart.get("items", []))
                    discount_pct = float(cart.get("discount_percent", 0) or 0)
                    if discount_pct > 0:
                        items_total = items_total * (1 - discount_pct / 100)
                    loja_data["carts"][cart_id]["total"] = round(items_total, 2)
                except Exception:
                    pass
                Database.save_document("loja_data", loja_data)


            if cart.get("mode") == "reserve":
                return await self._handle_reservation_approval(cart, products)


            total = 0
            items_delivered_names = []
            stock_results = []
            manual_items = []
            has_auto_product = False
            has_manual_product = False


            discount_coupon_code = cart.get("coupon_code")
            applied_coupon_p_id = None

            for item in cart.get("items", []):
                p_id = item.get("product_id")
                f_id = item.get("field_id")
                qty = item.get("qty", 1)
                price = item.get("price", 0)

                product = products.get(p_id, {})
                field = product.get("campos", {}).get(f_id, {})
                total += price * qty


                if discount_coupon_code and not applied_coupon_p_id:
                    if discount_coupon_code in product.get("cupons", {}):
                        applied_coupon_p_id = p_id

                        if "cupons" in products[p_id] and discount_coupon_code in products[p_id]["cupons"]:
                            products[p_id]["cupons"][discount_coupon_code]["usos"] = products[p_id]["cupons"].get(discount_coupon_code, {}).get("usos", 0) + 1
                            Database.save_document("loja_products", products)

                delivery_type = product.get("info", {}).get("delivery_type", "automatic")
                items_delivered_names.append(f"{product.get('name')} x{qty}")

                if delivery_type == "manual":

                    has_manual_product = True
                    manual_items.append(f"{product.get('name')} x{qty}")
                else:

                    has_auto_product = True
                    items = await StockManager.get_stock_items_fresh(p_id, f_id, qty)

                    if items:
                        items_text = "\n".join(items)
                        stock_results.append(f"**Produto:** {product.get('name')}\n**Itens:**\n```\n{items_text}\n```")
                    else:
                        stock_results.append(f"**Produto:** {product.get('name')}\nFalha ao recuperar itens do estoque.")

            full_delivery_text = "\n\n".join(stock_results)
            discount_percent = cart.get("discount_percent", 0)
            if discount_percent > 0:
                total = total * (1 - discount_percent / 100)


            v2_flag = disnake.MessageFlags(is_components_v2=True)


            dm_success = True
            if has_auto_product and stock_results:
                container_delivery = [
                    disnake.ui.TextDisplay(f"## 🎉 Compra Aprovada!\n-# Pedido: `{cart_id}`"),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(full_delivery_text)
                ]

                delivery_payload = {
                    "components": [disnake.ui.Container(*container_delivery)],
                    "flags": v2_flag
                }

                if member:
                    try:
                        await member.send(**delivery_payload)
                    except Exception:
                        dm_success = False


            if has_auto_product and dm_success and member:
                try:
                    bot_name = self.bot.user.name if self.bot.user else "a loja"
                    review_container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"**Avalie o serviço de** `{bot_name}` **sobre este produto.**\n-# Sua avaliação é muito importante para a reputação dessa loja."),
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Ruim :(", style=disnake.ButtonStyle.red, custom_id=f"Review_Submit:{cart_id}:ruim"),
                            disnake.ui.Button(label="Mediano", style=disnake.ButtonStyle.grey, custom_id=f"Review_Submit:{cart_id}:mediano"),
                            disnake.ui.Button(label="Muito Bom!", style=disnake.ButtonStyle.blurple, custom_id=f"Review_Submit:{cart_id}:bom"),
                        ),
                    )
                    await member.send(components=[review_container], flags=v2_flag)
                except Exception:
                    pass


            thread_id = cart.get("thread_id")
            thread = guild.get_thread(int(thread_id)) or guild.get_channel(int(thread_id)) if thread_id else None

            if thread:

                try:
                    msg_id = cart.get("message_id")
                    if msg_id:
                        msg = await thread.fetch_message(msg_id)
                        status_text = "Aguardando entrega manual..." if has_manual_product and not has_auto_product else "Os itens foram processados com sucesso."
                        approve_container = disnake.ui.Container(
                            disnake.ui.TextDisplay(f"## Pagamento Aprovado!\n-# Venda: `{cart_id}`"),
                            disnake.ui.Separator(),
                            disnake.ui.TextDisplay(f"Obrigado pela compra, {member.mention if member else 'Cliente'}!\n\n{status_text}"),
                        )
                        await msg.edit(content=None, components=[approve_container], attachments=[], flags=v2_flag)
                except Exception: pass

                if has_manual_product:

                    try: await thread.edit(name=f"Pendente - {member.name if member else 'cliente'} - {user_id}")
                    except Exception: pass

                    manual_list = "\n".join(f"- {item}" for item in manual_items)
                    pending_container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## ⏳ Entrega Manual Pendente\n-# Pedido: `{cart_id}`"),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Itens aguardando entrega:**\n{manual_list}\n\n**Comprador:** {member.mention if member else f'<@{user_id}>'}\n\n-# Clique no botão abaixo após entregar o produto."),
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Marcar como Entregue", style=disnake.ButtonStyle.success, custom_id=f"Cart_ManualDeliver:{cart_id}"),
                        ),
                    )
                    await thread.send(components=[pending_container], flags=v2_flag)


                    if has_auto_product:
                        if dm_success:
                            await thread.send(f"-# Itens automáticos já foram entregues via DM.")
                        elif stock_results:
                            thread_delivery_container = disnake.ui.Container(
                                disnake.ui.TextDisplay(f"# Entrega Automática via Thread\n-# DM fechada. Itens automáticos abaixo:"),
                                disnake.ui.Separator(),
                                disnake.ui.TextDisplay(full_delivery_text),
                            )
                            await thread.send(components=[thread_delivery_container], flags=v2_flag)

                else:

                    try: await thread.edit(name=f"Concluída - {member.name if member else 'cliente'} - {user_id}")
                    except Exception: pass

                    if dm_success:
                        expire_ts_30s = int(disnake.utils.utcnow().timestamp() + 30)
                        await thread.send(f"Pagamento confirmado. Itens enviados via DM. Este tópico será fechado <t:{expire_ts_30s}:R>.")
                        asyncio.create_task(self._delayed_delete(thread, 30))
                    else:
                        if has_auto_product:
                            expire_ts_1h = int(disnake.utils.utcnow().timestamp() + 3600)
                            thread_delivery_container = disnake.ui.Container(
                                disnake.ui.TextDisplay(f"# Entrega via Thread\n-# Sua DM está fechada. Os itens estão abaixo:"),
                                disnake.ui.Separator(),
                                disnake.ui.TextDisplay(full_delivery_text),
                                disnake.ui.Separator(),
                                disnake.ui.TextDisplay(f"-# Este tópico será fechado <t:{expire_ts_1h}:R>."),
                            )
                            await thread.send(components=[thread_delivery_container], flags=v2_flag)
                            asyncio.create_task(self._delayed_delete(thread, 3600))


            try:
                from modules.store.wallet import WalletModule
                await WalletModule.add_sale(total, cart_id)
            except Exception as wallet_e:
                print(f"[CHECKOUT ERROR] Falha ao registrar saldo interno: {wallet_e}")


            await send_store_log(self.bot, "private", {
                "Evento": "Venda Aprovada",
                "Usuário": f"<@{user_id}> (`{user_id}`)",
                "Produto": ", ".join(items_delivered_names),
                "Valor": f"`R$ {total:.2f}`",
                "Pagamento": cart.get("payment_provider", "pix").upper(),
                "Entrega": "Manual (Pendente)" if has_manual_product and not has_auto_product else ("DM (Sucesso)" if dm_success else "Thread (DM Fechada)")
            })


            # Resolve URL do produto pra botao "Comprar" no log publico
            # apontar pro post original (era discord.com generico)
            product_url = "https://discord.com"
            try:
                product_id = cart.get("product_id")
                if product_id:
                    products_doc = Database.get_document("loja_products") or {}
                    product_data = products_doc.get(product_id, {})
                    msgs = product_data.get("messages", [])
                    if msgs and msgs[0].get("message_id"):
                        m = msgs[0]
                        product_url = f"https://discord.com/channels/{m.get('guild_id', '@me')}/{m.get('channel_id', '')}/{m.get('message_id', '')}"
            except Exception:
                pass

            await send_store_log(self.bot, "public", {
                    "Usuário": f"<@{user_id}>",
                    "Produto": ", ".join(items_delivered_names),
                    "Valor": f"`R$ {total:.2f}`",
                    "ProductURL": product_url,
                }, user_override=member)


            # Atribui cargo de cliente (definido em /store/preferences > Cargo de Cliente).
            # Vive na collection 'cargos' como cargo_cliente.
            if member:
                try:
                    cargos = Database.get_document("cargos") or {}
                    cargo_cliente_id = cargos.get("cargo_cliente")
                    if cargo_cliente_id:
                        cliente_role = guild.get_role(int(cargo_cliente_id))
                        if cliente_role and cliente_role not in member.roles:
                            await member.add_roles(cliente_role, reason="Compra realizada — cargo de cliente")
                except Exception as cliente_e:
                    print(f"[CHECKOUT ERROR] Falha ao atribuir cargo de cliente: {cliente_e}")

            prefs = Database.get_document("loja_preferences") or {}
            top_clients = prefs.get("top_clients", [])

            if top_clients and member:
                try:

                    customers = Database.get_document("loja_customers") or {"spent": {}}
                    spent_data = customers.get("spent", {})
                    user_total_spent = float(spent_data.get(str(user_id), 0))


                    roles_to_add = []
                    all_top_role_ids = [int(tc["role_id"]) for tc in top_clients if tc.get("role_id")]

                    for tc in top_clients:
                        role_id = tc.get("role_id")
                        min_value = float(tc.get("threshold", 0))
                        if not role_id: continue

                        if user_total_spent >= min_value:
                            roles_to_add.append(int(role_id))


                    if roles_to_add:
                        for rid in roles_to_add:
                            role = guild.get_role(rid)
                            if role and role not in member.roles:
                                await member.add_roles(role, reason=f"Top Cliente Tier - Gasto: R$ {user_total_spent:.2f}")
                except Exception as role_e:
                    print(f"[CHECKOUT ERROR] Falha ao atribuir cargos Top Cliente: {role_e}")


            return True

        except Exception as e:
            print(f"[CHECKOUT ERROR] Erro ao aprovar carrinho: {e}")
            return False


    @commands.Cog.listener("on_button_click")
    async def on_checkout_button(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id

        if not cid.startswith(("Cart_", "Checkout_", "Store_")):
            return

        parts = cid.split(":")
        action = parts[0]

        try:
            if action == "Cart_FinalizeTrigger":
                cart_id = parts[1]
                await self._handle_finalize_trigger(inter, cart_id)

            elif action == "Cart_Coupon":
                cart_id = parts[1]
                await self._handle_coupon(inter, cart_id)

            elif action == "Cart_ManageItems":
                cart_id = parts[1]
                await self._handle_manage_items(inter, cart_id)

            elif action == "Cart_EditItem":
                cart_id, product_id, field_id = parts[1], parts[2], parts[3]
                await self._handle_manage_items(inter, cart_id, product_id, field_id)

            elif action == "Cart_Supporter":
                cart_id = parts[1]
                await self._handle_supporter(inter, cart_id)

            elif action == "Cart_CopyPix":
                cart_id = parts[1]
                await self._handle_copy_pix(inter, cart_id)

            elif action == "Cart_ConfirmPayment":
                cart_id = parts[1]
                await self._handle_confirm_payment(inter, cart_id)

            elif action == "Cart_ManualDeliver":
                cart_id = parts[1]
                await self._handle_manual_deliver(inter, cart_id)

            elif action == "Cart_Cancel":
                cart_id = parts[1]
                await self._handle_cancel(inter, cart_id)

            elif action == "Cart_Qty":
                cart_id, item_idx, op = parts[1], int(parts[2]), parts[3]
                await self._handle_qty_change(inter, cart_id, item_idx, op)

            elif action == "Cart_Remove":
                cart_id, item_idx = parts[1], int(parts[2])
                await self._handle_remove_item(inter, cart_id, item_idx)

            elif action == "Store_Buy":
                product_id = parts[1]

                import time
                user_id = inter.author.id
                current_time = time.time()

                if user_id in self._buy_cooldowns:
                    last_click = self._buy_cooldowns[user_id]
                    if current_time - last_click < 3:
                        return await inter.response.send_message(
                            "Aguarde um momento antes de clicar novamente.",
                            ephemeral=True
                        )

                self._buy_cooldowns[user_id] = current_time
                await self._handle_initial_buy(inter, product_id, mode="buy")

            elif action == "Store_Reserve":
                product_id = parts[1]

                import time
                user_id = inter.author.id
                current_time = time.time()

                if user_id in self._buy_cooldowns:
                    last_click = self._buy_cooldowns[user_id]
                    if current_time - last_click < 3:
                        return await inter.response.send_message(
                            "Aguarde um momento antes de clicar novamente.",
                            ephemeral=True
                        )

                self._buy_cooldowns[user_id] = current_time
                await self._handle_initial_buy(inter, product_id, mode="reserve")

            elif action == "Store_ShowOptions":
                product_id = parts[1]
                await self._handle_show_options(inter, product_id)

            elif action == "Cart_Supporter":
                cart_id = parts[1]
                await self._handle_supporter_modal(inter, cart_id)

            elif action == "Cart_ShowTerms":
                await self._handle_show_terms(inter)

        except Exception as e:
            print(f"[CHECKOUT ERROR] Erro no botão {cid}: {e}")

    @commands.Cog.listener("on_dropdown")
    async def on_checkout_dropdown(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id

        if cid.startswith("Checkout_FieldSelect:"):
            parts = cid.split(":")
            product_id = parts[1]
            support_code = parts[2] if len(parts) > 2 and parts[2] != "" else None
            mode = parts[3] if len(parts) > 3 else "buy"
            form_data_key = parts[4] if len(parts) > 4 and parts[4] != "" else None
            field_id = inter.values[0]


            v2_flag = disnake.MessageFlags(is_components_v2=True, ephemeral=True)
            await inter.response.edit_message(
                components=[disnake.ui.Container(disnake.ui.TextDisplay("Aguarde, verificando carrinho..."))],
                flags=v2_flag
            )


            form_data = None
            if form_data_key:
                temp_forms = Database.get_document("temp_form_data") or {}
                form_data = temp_forms.pop(form_data_key, None)
                Database.save_document("temp_form_data", temp_forms)

            await create_cart_thread(inter, product_id, field_id, mode=mode, form_data=form_data)


    async def _handle_finalize_trigger(self, inter: disnake.MessageInteraction, cart_id: str):
        await self._handle_checkout(inter, cart_id)

    async def _handle_initial_buy(self, inter: disnake.MessageInteraction, product_id: str, mode: str = "buy"):
        products = Database.get_document("loja_products") or {}
        product = products.get(product_id)

        if not product:
            return await inter.response.send_message("Produto não encontrado.", ephemeral=True)


        product_type = product.get("type", "normal")
        formulario = product.get("info", {}).get("formulario", {})
        has_form = product_type == "contas" and formulario.get("enabled", False) and formulario.get("campos", [])

        if has_form:

            campos = formulario.get("campos", [])[:5]
            components = []
            for i, campo in enumerate(campos):
                components.append(
                    disnake.ui.TextInput(
                        label=campo.get("label", f"Campo {i+1}")[:45],
                        custom_id=f"form_field_{i}",
                        placeholder=campo.get("placeholder", "")[:100] or None,
                        required=campo.get("required", True),
                        max_length=200
                    )
                )

            await inter.response.send_modal(
                title="Preencha os dados",
                custom_id=f"Store_FormModal:{product_id}:{mode}",
                components=components
            )
        else:


            await create_cart_thread(inter, product_id, None, mode=mode)

    async def _handle_show_options(self, inter: disnake.MessageInteraction, product_id: str):
        products = Database.get_document("loja_products") or {}
        product = products.get(product_id)

        if not product:
            await inter.response.send_message("Produto não encontrado.", ephemeral=True)
            return

        campos = product.get("campos", {})
        if not campos:
            await inter.response.send_message("Nenhuma opção disponível.", ephemeral=True)
            return

        options = []
        for fid, f in campos.items():
            price_f = f.get("price", 0)
            is_infinite = f.get("infinite_stock", {}).get("enabled", False)
            stock_count = StockManager.get_available_stock(product_id, fid)
            stock_display = "∞" if is_infinite else str(stock_count)

            opt_kwargs = {"label": f.get("name", "Opção"), "description": f"R$ {price_f:.2f} | Estoque: {stock_display}", "value": fid}
            parsed = _parse_emoji(f.get("icon", ""))
            if parsed:
                opt_kwargs["emoji"] = parsed
            options.append(disnake.SelectOption(**opt_kwargs))

        await inter.response.send_message(
            components=[
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id=f"Checkout_FieldSelect:{product_id}",
                        options=options,
                        placeholder="Escolha uma opção..."
                    )
                )
            ],
            ephemeral=True
        )

    async def _handle_checkout(self, inter: disnake.Interaction, cart_id: str):
        v2_flag = disnake.MessageFlags(is_components_v2=True, ephemeral=True)


        if not inter.response.is_done():
            await inter.response.defer(ephemeral=True)

        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart:
            await inter.followup.send("Carrinho não encontrado.", ephemeral=True)
            return

        try:

            dashboard = await get_cart_dashboard(cart, inter.author.id, is_disabled=True, processing_action="checkout")
            await inter.edit_original_message(**dashboard, flags=v2_flag)
        except Exception as e:
            print(f"[DEBUG] Erro ao desabilitar botões no checkout: {e}")

        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart:
            await inter.followup.send("Carrinho não encontrado.", ephemeral=True)
            return


        total = sum(item["price"] * item["qty"] for item in cart["items"])
        discount = cart.get("discount_percent", 0)
        if discount > 0:
            total = total * (1 - discount / 100)


        manual_pix = Database.get_config().get("manual_pix", {})
        pix_key = str(manual_pix.get("key") or "").strip()
        if not manual_pix.get("enabled") or not pix_key:
            await inter.followup.send("O PIX manual da Kroma Studio ainda não foi configurado.", ephemeral=True)
            return
        payment_result = {"txid": f"MANUAL-{cart_id}", "pix_copy_paste": pix_key}
        provider = "manual_pix"

        pix_copy = payment_result.get("pix_copy_paste") or payment_result.get("qr_code")


        import datetime
        cart["payment_provider"] = provider
        cart["payment_txid"] = payment_result.get("txid")
        cart["payment_copy_paste"] = pix_copy
        cart["payment_started_at"] = int(datetime.datetime.utcnow().timestamp())
        cart["status"] = "pending_payment"
        Database.save_document("loja_data", loja_data)


        from functions.qr_code import QRGenerator
        import io
        qr_image_url = payment_result.get("qr_code_url")
        file_to_send = None


        if pix_copy:
            try:
                qr_bytes = await QRGenerator.generate(pix_copy)
                if qr_bytes:
                    file_to_send = disnake.File(io.BytesIO(qr_bytes), filename="qrcode.png")
                    qr_image_url = "attachment://qrcode.png"
            except Exception as e:
                print(f"[CHECKOUT ERROR] Falha ao gerar QR Code: {e}")


        if not qr_image_url:
            qr_code_raw = payment_result.get("qr_code_base64") or payment_result.get("qr_code")
            if qr_code_raw:
                if qr_code_raw.startswith("http"):
                    qr_image_url = qr_code_raw
                else:
                    try:
                        import base64
                        clean_b64 = qr_code_raw
                        if "," in clean_b64: clean_b64 = clean_b64.split(",")[1]
                        file_data = base64.b64decode(clean_b64)
                        file_to_send = disnake.File(io.BytesIO(file_data), filename="qrcode.png")
                        qr_image_url = "attachment://qrcode.png"
                    except Exception:
                        pass

        v2_flag = disnake.MessageFlags(is_components_v2=True, ephemeral=True)


        expire_ts = int(cart["payment_started_at"] + (10 * 60))

        instructions = (
            "1. Abra o aplicativo de seu banco\n"
            "2. Acesse a área de pagamentos PIX\n"
            "3. Escaneie o QR Code ou copie e cole o código abaixo\n"
            "4. Envie o comprovante neste atendimento\n"
            "5. Aguarde a confirmação da equipe"
        )

        container_items = [
            disnake.ui.TextDisplay(f"**Pague agora com PIX**"),
            disnake.ui.TextDisplay(instructions),
            disnake.ui.Separator(),
        ]

        if qr_image_url:
            container_items.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=qr_image_url)))

        container_items.append(disnake.ui.Separator())
        container_items.append(disnake.ui.TextDisplay(f"-# Ambiente seguro - Pagamento protegido - [Reporte aqui](https://discord.gg/bot)"))

        components = [
            disnake.ui.Container(*container_items, ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Copiar chave PIX", style=disnake.ButtonStyle.grey, custom_id=f"Cart_CopyPix:{cart_id}"),
                disnake.ui.Button(label="Confirmar pagamento", style=disnake.ButtonStyle.success, custom_id=f"Cart_ConfirmPayment:{cart_id}")
            )
        ]

        await inter.edit_original_message(components=components, file=file_to_send, flags=v2_flag)


        async def _update_name():
            try:
                new_name = f"Pagamento - {inter.author.name} - {inter.author.id}"
                await inter.channel.edit(name=new_name)
            except Exception:
                pass

        asyncio.create_task(_update_name())

    async def _handle_copy_pix(self, inter: disnake.MessageInteraction, cart_id: str):
        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart:
            return await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)

        pix_code = cart.get("payment_copy_paste")
        if not pix_code:

            return await inter.response.send_message("Código PIX não disponível.", ephemeral=True)

        await inter.response.send_message(f"### Código PIX Copia e Cola\n```\n{pix_code}\n```", ephemeral=True)

    async def _handle_confirm_payment(self, inter: disnake.MessageInteraction, cart_id: str):
        from functions.permissions import Permissions
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("Somente a equipe pode confirmar pagamentos.", ephemeral=True)
        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data.get("carts", {}).get(cart_id)
        if not cart: return await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)
        if cart.get("status") == "approved": return await inter.response.send_message("Este pedido já foi confirmado.", ephemeral=True)
        await inter.response.defer(ephemeral=True)
        if not await self.approve_cart(cart): return await inter.followup.send("Não foi possível aprovar esse pedido.", ephemeral=True)
        total = float(loja_data["carts"].get(cart_id, {}).get("total", 0) or 0)
        sales = Database.get_document("kroma_sales") or []
        sales.append({"id": cart_id, "amount": total, "customer_id": cart.get("user_id"), "description": "Compra pela loja", "approved_at": int(datetime.datetime.utcnow().timestamp())})
        Database.save_document("kroma_sales", sales)
        await inter.followup.send("Pagamento confirmado e pedido liberado.", ephemeral=True)

    async def _handle_manual_deliver(self, inter: disnake.MessageInteraction, cart_id: str):
        await inter.response.defer(ephemeral=True)

        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart:
            return await inter.followup.send("Carrinho não encontrado.", ephemeral=True)


        loja_data["carts"][cart_id]["manual_delivered"] = True
        loja_data["carts"][cart_id]["manual_delivered_by"] = inter.author.id
        Database.save_document("loja_data", loja_data)

        v2_flag = disnake.MessageFlags(is_components_v2=True)


        try:
            done_container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"## ✅ Entrega Concluída\n-# Pedido: `{cart_id}`"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(f"Entregue por {inter.author.mention}."),
            )
            await inter.message.edit(components=[done_container], flags=v2_flag)
        except Exception:
            pass


        user_id = cart.get("user_id")
        guild = inter.guild
        member = guild.get_member(user_id) if guild and user_id else None
        if not member and guild and user_id:
            try: member = await guild.fetch_member(user_id)
            except Exception: pass

        if member:
            try:
                notify_container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## 🎉 Seu pedido foi entregue!\n-# Pedido: `{cart_id}`"),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay("Sua compra foi entregue manualmente. Caso tenha dúvidas, entre em contato com o suporte."),
                )
                await member.send(components=[notify_container], flags=v2_flag)


                bot_name = self.bot.user.name if self.bot.user else "a loja"
                review_container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"**Avalie o serviço de** `{bot_name}` **sobre este produto.**\n-# Sua avaliação é muito importante para a reputação dessa loja."),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(label="Ruim :(", style=disnake.ButtonStyle.red, custom_id=f"Review_Submit:{cart_id}:ruim"),
                        disnake.ui.Button(label="Mediano", style=disnake.ButtonStyle.grey, custom_id=f"Review_Submit:{cart_id}:mediano"),
                        disnake.ui.Button(label="Muito Bom!", style=disnake.ButtonStyle.blurple, custom_id=f"Review_Submit:{cart_id}:bom"),
                    ),
                )
                await member.send(components=[review_container], flags=v2_flag)
            except Exception:
                pass


        try:
            await inter.channel.edit(name=f"Concluída - {member.name if member else 'cliente'} - {user_id}")
        except Exception: pass

        expire_ts = int(disnake.utils.utcnow().timestamp() + 30)
        await inter.channel.send(f"Entrega manual concluída por {inter.author.mention}. Este tópico será fechado <t:{expire_ts}:R>.")
        asyncio.create_task(self._delayed_delete(inter.channel, 30))

        await inter.followup.send("Entrega marcada como concluída!", ephemeral=True)

    async def _handle_cancel(self, inter: disnake.MessageInteraction, cart_id: str):

        if not inter.response.is_done():
            await inter.response.defer(ephemeral=True)

        loja_data = Database.get_document("loja_data") or {"carts": {}}


        if cart_id in loja_data["carts"]:
            del loja_data["carts"][cart_id]
            Database.save_document("loja_data", loja_data)


        try:
            await inter.channel.delete()
        except Exception:
            pass

    async def _handle_qty_change(self, inter: disnake.MessageInteraction, cart_id: str, item_idx: int, operation: str):
        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart or item_idx >= len(cart["items"]):
            return

        if operation == "inc":
            cart["items"][item_idx]["qty"] += 1
        elif operation == "dec" and cart["items"][item_idx]["qty"] > 1:
            cart["items"][item_idx]["qty"] -= 1

        Database.save_document("loja_data", loja_data)

        dashboard = await get_cart_dashboard(cart, inter.author.id)
        await inter.response.edit_message(**dashboard, flags=disnake.MessageFlags(is_components_v2=True))

    async def _handle_remove_item(self, inter: disnake.MessageInteraction, cart_id: str, item_idx: int):
        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart or item_idx >= len(cart["items"]):
            return

        cart["items"].pop(item_idx)

        if not cart["items"]:

            del loja_data["carts"][cart_id]
            Database.save_document("loja_data", loja_data)
            await inter.response.send_message("Carrinho vazio. Cancelando...", ephemeral=True)
            import asyncio
            await asyncio.sleep(2)
            try:
                await inter.channel.delete()
            except Exception:
                pass
            return

        Database.save_document("loja_data", loja_data)

        dashboard = await get_cart_dashboard(cart, inter.author.id)
        await inter.response.edit_message(**dashboard, flags=disnake.MessageFlags(is_components_v2=True))

    async def _handle_manage_items(self, inter: disnake.MessageInteraction, cart_id: str, product_id: str = None, field_id: str = None):
        loja_data = Database.get_document("loja_data") or {"carts": {}}
        cart = loja_data["carts"].get(cart_id)

        if not cart or not cart["items"]:
            return await inter.response.send_message("Carrinho vazio ou não encontrado.", ephemeral=True)

        item = cart["items"][0]
        current_qty = item["qty"]

        await inter.response.send_modal(
            title="Editar Quantidade",
            custom_id=f"Cart_ManageModal:{cart_id}:0",
            components=[
                disnake.ui.TextInput(
                    label="Quantidade (0 para remover)",
                    custom_id="qty",
                    placeholder=f"Quantidade atual: {current_qty}",
                    min_length=1,
                    max_length=5,
                    required=True
                )
            ]
        )

    async def _handle_coupon(self, inter: disnake.MessageInteraction, cart_id: str):
        await inter.response.send_modal(
            title="Aplicar Cupom de Desconto",
            custom_id=f"Cart_CouponModal:{cart_id}",
            components=[
                disnake.ui.TextInput(label="Código do Cupom", custom_id="coupon_code", placeholder="Digite o código do cupom", max_length=50, required=True)
            ]
        )

    async def _handle_supporter(self, inter: disnake.MessageInteraction, cart_id: str):
        await self._handle_supporter_modal(inter, cart_id)

    async def _handle_supporter_modal(self, inter: disnake.MessageInteraction, cart_id: str):
        await inter.response.send_modal(
            title="Apoiar um Afiliado",
            custom_id=f"Cart_SupporterModal:{cart_id}",
            components=[
                disnake.ui.TextInput(
                    label="Código do Apoiador (Opcional)",
                    custom_id="support_code",
                    placeholder="Digite o código se tiver, ou deixe vazio",
                    max_length=50,
                    required=False
                )
            ]
        )

    async def _handle_show_terms(self, inter: disnake.MessageInteraction):
        prefs = Database.get_document("loja_preferences") or {}
        terms_data = prefs.get("terms", {})
        terms_text = terms_data.get("content", "") if isinstance(terms_data, dict) else str(terms_data)

        if not terms_text:
            terms_text = "Os termos da loja não foram configurados."

        container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"### Termos da Loja\n\n{terms_text}"),
        )
        await inter.response.send_message(components=[container], ephemeral=True, flags=disnake.MessageFlags(is_components_v2=True))

    @commands.Cog.listener("on_modal_submit")
    async def on_checkout_modal(self, inter: disnake.ModalInteraction):
        cid = inter.custom_id
        if not cid.startswith(("Cart_", "Store_")):
            return

        if cid.startswith("Store_FormModal:"):

            parts = cid.split(":")
            product_id = parts[1]
            mode = parts[2] if len(parts) > 2 else "buy"


            form_data = {}
            products = Database.get_document("loja_products") or {}
            product = products.get(product_id)
            if product:
                campos = product.get("info", {}).get("formulario", {}).get("campos", [])
                for i, campo in enumerate(campos):
                    field_value = inter.text_values.get(f"form_field_{i}", "")
                    form_data[campo.get("label", f"Campo {i+1}")] = field_value


            await start_checkout(inter, product_id, support_code=None, mode=mode, form_data=form_data)

        elif cid.startswith("Store_BuyModal:"):
            parts = cid.split(":")
            product_id = parts[1]
            mode = parts[2] if len(parts) > 2 else "buy"
            support_code = inter.text_values.get("support_code", "").strip().upper()

            if support_code:
                from modules.affiliate.manager import AffiliateManager
                affiliate = AffiliateManager.get_affiliate_by_code(support_code)
                if not affiliate:
                    return await inter.response.send_message("Código de apoiador não encontrado ou inválido!", ephemeral=True)


            await start_checkout(inter, product_id, support_code=support_code, mode=mode)

        elif cid.startswith("Cart_FinalizeModal:"):
            cart_id = cid.split(":")[1]
            support_code = inter.text_values.get("support_code", "").strip().upper()

            loja_data = Database.get_document("loja_data") or {"carts": {}}
            cart = loja_data["carts"].get(cart_id)

            if not cart:
                return await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)

            if support_code:
                from modules.affiliate.manager import AffiliateManager
                affiliate = AffiliateManager.get_affiliate_by_code(support_code)

                if not affiliate:
                    return await inter.response.send_message("Código de apoiador não encontrado ou inválido!", ephemeral=True)

                cart["support_code"] = support_code
                Database.save_document("loja_data", loja_data)


            await inter.response.defer(ephemeral=True)
            await self._handle_checkout(inter, cart_id)

        elif cid.startswith("Cart_SupporterModal:"):

            cart_id = cid.split(":")[1]
            support_code = inter.text_values.get("support_code", "").strip().upper()

            loja_data = Database.get_document("loja_data") or {"carts": {}}
            cart = loja_data["carts"].get(cart_id)

            if not cart:
                return await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)

            if support_code:
                from modules.affiliate.manager import AffiliateManager
                affiliate = AffiliateManager.get_affiliate_by_code(support_code)

                if not affiliate:
                    return await inter.response.send_message("Código de apoiador não encontrado ou inválido!", ephemeral=True)

                cart["support_code"] = support_code
                Database.save_document("loja_data", loja_data)


                dashboard = await get_cart_dashboard(cart, inter.author.id)
                v2_flag_eph = disnake.MessageFlags(is_components_v2=True, ephemeral=True)
                await inter.response.edit_message(**dashboard, flags=v2_flag_eph)
            else:
                await inter.response.send_message("Nenhum código informado.", ephemeral=True)

        elif cid.startswith("Cart_ManageModal:"):
            parts = cid.split(":")
            cart_id, item_idx = parts[1], int(parts[2])
            qty_str = inter.text_values.get("qty", "0")

            try:
                new_qty = int(qty_str)
                if new_qty < 0: raise ValueError
            except Exception:
                return await inter.response.send_message("Quantidade inválida.", ephemeral=True)

            loja_data = Database.get_document("loja_data") or {"carts": {}}
            cart = loja_data["carts"].get(cart_id)

            if not cart:
                return await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)

            if new_qty == 0:

                cart["items"].pop(item_idx)
                if not cart["items"]:
                    del loja_data["carts"][cart_id]
                    Database.save_document("loja_data", loja_data)
                    try: await inter.channel.delete()
                    except Exception: pass
                    return
            else:

                item = cart["items"][item_idx]
                from modules.store.stock.manager import StockManager
                available = StockManager.get_available_stock(item["product_id"], item["field_id"])

                if new_qty > available:
                    return await inter.response.send_message(f"Estoque insuficiente. Atualmente temos apenas `{available}` disponível(is).", ephemeral=True)

                item["qty"] = new_qty

            Database.save_document("loja_data", loja_data)
            dashboard = await get_cart_dashboard(cart, inter.author.id)
            await inter.response.edit_message(**dashboard, flags=disnake.MessageFlags(is_components_v2=True))


        elif cid.startswith("Cart_CouponModal:"):
            cart_id = inter.custom_id.split(":")[1]
            coupon_code = inter.text_values.get("coupon_code", "").strip().upper()


            loja_data = Database.get_document("loja_data") or {"carts": {}}
            cart = loja_data["carts"].get(cart_id)

            if not cart:
                await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)
                return

            products = Database.get_document("loja_products") or {}
            coupon_found = None


            for item in cart.get("items", []):
                product = products.get(item["product_id"], {})
                product_cupons = product.get("cupons", {})
                if coupon_code in product_cupons:
                    coupon_found = product_cupons[coupon_code]
                    break

            if not coupon_found:
                await inter.response.send_message("Cupom inválido.", ephemeral=True)
                return


            max_usos = coupon_found.get("max_usos", 0)
            usos = coupon_found.get("usos", 0)
            if max_usos > 0 and usos >= max_usos:
                await inter.response.send_message("Este cupom já atingiu o limite de usos.", ephemeral=True)
                return


            if cart:
                cart["discount_percent"] = coupon_found.get("porcentagem", 0)
                cart["coupon_code"] = coupon_code
                Database.save_document("loja_data", loja_data)

                dashboard = await get_cart_dashboard(cart, inter.author.id)
                await inter.response.edit_message(**dashboard, flags=disnake.MessageFlags(is_components_v2=True))
            else:
                await inter.response.send_message("Carrinho não encontrado.", ephemeral=True)

    async def _handle_reservation_approval(self, cart: dict, products: dict) -> bool:
        from modules.store.checkout.logs import send_store_log

        guild_id = cart.get("guild_id")
        user_id = cart.get("user_id")
        cart_id = cart.get("cart_id")
        source_cid = cart.get("source_channel_id")

        guild = self.bot.get_guild(guild_id)
        if not guild: return False

        member = guild.get_member(user_id)
        if not member:
            try: member = await guild.fetch_member(user_id)
            except Exception: pass


        res_names = []
        total = 0
        for item in cart.get("items", []):
            p = products.get(item["product_id"], {})
            res_names.append(p.get("name", "Produto"))
            total += item["price"]


        if source_cid:
            channel = guild.get_channel(source_cid)
            if channel:
                try:

                    if isinstance(channel, disnake.Thread):
                        await channel.edit(locked=True, name=f"🔒・RESERVADO・{res_names[0]}")
                        await channel.send(f"### 🔒 Reservado por {member.mention}\n-# Este item foi reservado mediante pagamento de sinal.")
                    else:

                        overwrites = channel.overwrites
                        overwrites[guild.default_role] = disnake.PermissionOverwrite(read_messages=False)
                        overwrites[member] = disnake.PermissionOverwrite(read_messages=True, send_messages=True)
                        await channel.edit(overwrites=overwrites, name=f"🔒-{res_names[0][:20]}")
                        await channel.send(f"### 🔒 Reservado por {member.mention}\n-# Este canal agora é privado para a finalização da compra.")
                except Exception as e:
                    print(f"[RESERVE ERROR] Erro ao privar canal: {e}")


        v2_flag = disnake.MessageFlags(is_components_v2=True, ephemeral=True)
        container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"## 🔒 Reserva Aprovada!\n-# Você reservou: **{', '.join(res_names)}**"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                f"O pagamento do sinal (`R$ {total:.2f}`) foi confirmado.\n"
                "O item agora está reservado para você. Entre em contato com o suporte para pagar o restante e retirar o produto."
            ),

        )

        try: await member.send(components=[container], flags=v2_flag)
        except Exception: pass


        thread = guild.get_thread(int(cart.get("thread_id")))
        if thread:
            try:
                msg_id = cart.get("message_id")
                if msg_id:
                    msg = await thread.fetch_message(msg_id)
                    await msg.edit(components=[container], flags=v2_flag)
            except Exception: pass

            await thread.send(f"Pagamento do sinal confirmado! O produto foi reservado. Tópico fechando em 60s.")
            asyncio.create_task(self._delayed_delete(thread, 60))


        await send_store_log(self.bot, "private", {
            "Evento": "🔒 Produto Reservado",
            "Usuário": f"<@{user_id}>",
            "Produto": ", ".join(res_names),
            "Valor do Sinal": f"R$ {total:.2f}",
            "Canal": f"<#{source_cid}>"
        })

        return True

    @commands.Cog.listener("on_button_click")
    async def on_review_submit(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id
        if not cid.startswith("Review_Submit:"):
            return

        parts = cid.split(":")
        cart_id = parts[1]
        rating = parts[2]

        rating_labels = {
            "ruim": "[1] Ruim",
            "mediano": "[2] Mediano",
            "bom": "[3] Muito Bom!"
        }
        rating_colors = {
            "ruim": disnake.Color.red(),
            "mediano": disnake.Color.gold(),
            "bom": disnake.Color.green()
        }


        v2_flag = disnake.MessageFlags(is_components_v2=True, ephemeral=True)
        thank_container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"**Obrigado pela sua avaliação!**\n-# Você avaliou: **{rating_labels.get(rating, rating)}**"),

        )
        await inter.response.edit_message(components=[thank_container], flags=v2_flag)


        prefs = Database.get_document("store_preferences") or {}
        feedback_channel_id = prefs.get("log_feedbacks_id")

        if feedback_channel_id:
            try:
                channel = self.bot.get_channel(int(feedback_channel_id))
                if channel:

                    carts = Database.get_document("loja_carts") or {}
                    cart = carts.get(cart_id, {})

                    items = cart.get("items", [])
                    products = Database.get_document("loja_products") or {}
                    product_names = []
                    for item in items:
                        p = products.get(item.get("product_id"), {})
                        product_names.append(p.get("name", "Produto"))

                    feedback_container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## Nova avaliação!\n-# Nº do pedido: `{cart_id}`"),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(
                            f"**Usuário:** {inter.author.mention} (`{inter.author.id}`)\n"
                            f"**Avaliação:** {rating_labels.get(rating, rating)}\n"
                            f"**Produto(s):** {', '.join(product_names) or 'N/A'}"
                        ),

                    )

                    await channel.send(components=[feedback_container], flags=v2_flag)
            except Exception as e:
                print(f"[REVIEW] Erro ao enviar feedback: {e}")


def setup(bot: commands.Bot):
    bot.add_cog(CheckoutHandler(bot))
