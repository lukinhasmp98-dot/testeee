import asyncio
import disnake
import threading
import requests as http_requests
from datetime import datetime
from disnake.ext import commands, tasks
from functions.database import Database
from functions.utils import Utils
from modules.store.stock.manager import StockManager

class ProductPublisher(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._sync_lock = asyncio.Lock()

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.auto_repost_loop.is_running():
            self.auto_repost_loop.start()
        if not self.dashboard_sync_loop.is_running():
            self.dashboard_sync_loop.start()

    def cog_unload(self):
        self.auto_repost_loop.cancel()
        self.dashboard_sync_loop.cancel()

    @tasks.loop(seconds=2)
    async def dashboard_sync_loop(self):
        if self._sync_lock.locked():
            return
        async with self._sync_lock:
            try:
                products = await Database.refresh_document("loja_products") or {}


                pending_products = []
                for pid, product in products.items():
                    if not isinstance(product, dict):
                        continue
                    has_sync_flag = product.get("_sync_pending")
                    has_pending_msgs = any(
                        m.get("pending") for m in product.get("messages", []) if isinstance(m, dict)
                    )
                    if has_sync_flag or has_pending_msgs:
                        pending_products.append((pid, product, has_sync_flag))

                if not pending_products:
                    return


                await Database.refresh_document("loja_stock")

                changed = False
                synced_ids = []

                for pid, product, has_sync_flag in pending_products:
                    if has_sync_flag:
                        product.pop("_sync_pending", None)
                        changed = True


                    to_delete = product.pop("_messages_to_delete", None)
                    if to_delete:
                        changed = True
                        for msg_del in to_delete:
                            try:
                                guild = self.bot.get_guild(int(msg_del["guild_id"]))
                                if guild:
                                    ch = guild.get_channel(int(msg_del["channel_id"]))
                                    if ch:
                                        msg = await ch.fetch_message(int(msg_del["message_id"]))
                                        await msg.delete()
                            except Exception as e:
                                print(f"[DashboardSync] Erro ao deletar mensagem: {e}")

                    messages = product.get("messages", [])
                    if not messages:
                        synced_ids.append(pid)
                        continue


                    await ProductPublisher.sync_messages(self.bot, pid, product)
                    synced_ids.append(pid)
                    changed = True

                if changed:

                    await Database.save_document_await("loja_products", products)


                for pid in synced_ids:
                    ProductPublisher._notify_sync(pid)

            except Exception as e:
                print(f"[DashboardSync] Erro: {e}")

    @dashboard_sync_loop.before_loop
    async def before_dashboard_sync_loop(self):
        await self.bot.wait_until_ready()

    @tasks.loop(minutes=1)
    async def auto_repost_loop(self):
        if self._sync_lock.locked():
            return
        async with self._sync_lock:
            products = Database.get_document("loja_products") or {}
            global_config = Database.get_document("product_repost") or {}


            use_global = global_config.get("enabled", False)
            global_interval_hours = global_config.get("interval", 24)
            global_last_repost = global_config.get("last_repost", 0)

            multiplier = {"minutes": 60, "hours": 3600, "days": 86400}
            now = datetime.now().timestamp()


            is_global_time = False
            if use_global:
                unit = global_config.get("unit", "hours")
                global_interval_seconds = global_interval_hours * multiplier.get(unit, 3600)
                if now - global_last_repost >= global_interval_seconds:
                    is_global_time = True

            changed_products = False
            for product_id, product in products.items():
                if not isinstance(product, dict):
                    continue
                try:
                    messages = product.get("messages", [])
                    if not messages:
                        continue

                    repost_config = product.get("info", {}).get("auto_repost", {})
                    per_product_enabled = repost_config.get("enabled", False)

                    should_repost = False

                    if per_product_enabled:

                        interval = repost_config.get("interval", 1)
                        unit = repost_config.get("unit", "hours")
                        last_repost = repost_config.get("last_repost", 0)

                        interval_seconds = interval * multiplier.get(unit, 3600)
                        if now - last_repost >= interval_seconds:
                            should_repost = True
                    elif use_global and is_global_time:

                        should_repost = True

                    if not should_repost:
                        continue


                    reposted_any = False
                    for msg_info in messages:
                        try:
                            guild_id = int(msg_info["guild_id"])
                            channel_id = int(msg_info["channel_id"])

                            guild = self.bot.get_guild(guild_id)
                            if not guild:
                                continue

                            channel = guild.get_channel(channel_id)
                            if not channel:
                                continue

                            old_msg_id = int(msg_info["message_id"]) if msg_info.get("message_id") else None


                            if old_msg_id:
                                try:
                                    old_msg = await channel.fetch_message(old_msg_id)
                                    await old_msg.delete()
                                except Exception:
                                    pass


                            template = msg_info.get("template", "standard")
                            msg_options = msg_info.get("options", {})
                            payload = await self.get_publish_payload(product, product_id, guild, template, msg_options)

                            send_kwargs = {
                                "components": payload.get("components"),
                                "flags": disnake.MessageFlags(is_components_v2=True),
                            }

                            new_msg = await channel.send(**send_kwargs)


                            msg_info["message_id"] = str(new_msg.id)
                            reposted_any = True

                        except Exception as e:
                            print(f"[AutoRepost] Erro ao repostar {product_id}: {e}")


                    if reposted_any:
                        changed_products = True


                    if per_product_enabled and reposted_any:
                        if "info" not in product: product["info"] = {}
                        if "auto_repost" not in product["info"]: product["info"]["auto_repost"] = {}
                        product["info"]["auto_repost"]["last_repost"] = now

                except Exception as e:
                    print(f"[AutoRepost] Erro geral: {e}")


            if changed_products:
                await Database.save_document_await("loja_products", products)


            if use_global and is_global_time:
                global_config["last_repost"] = now
                await Database.save_document_await("product_repost", global_config)

    @auto_repost_loop.before_loop
    async def before_auto_repost_loop(self):
        await self.bot.wait_until_ready()

    @staticmethod
    async def sync_all_products(bot: commands.Bot):
        products = Database.get_document("loja_products") or {}
        for pid in products:
            await ProductPublisher.sync_messages(bot, pid)

    @staticmethod
    def get_public_component(product_id: str, label_override: str = None, style_override: str = None, emoji_override: str = None) -> list:
        products = Database.get_document("loja_products")
        product = products.get(product_id)
        if not product: return []

        info = product.get("info", {})
        btn_conf = info.get("buy_button", {})

        has_stock = True

        campos = product.get("campos", {})
        total_stock = 0
        has_infinite = False
        for fid, fdn in campos.items():
            if fdn.get("infinite_stock", {}).get("enabled"):
                has_infinite = True
                break
            total_stock += StockManager.get_available_stock(product_id, fid)

        if not has_infinite and total_stock <= 0:
            has_stock = False

        label = label_override or btn_conf.get("label", "Comprar Produto")
        if not has_stock:
            label = "Esgotado"


        emoji = emoji_override or btn_conf.get("emoji", "")
        if not emoji or emoji.strip() == "":
            emoji = None

        style_map = {
            "green": disnake.ButtonStyle.green,
            "blurple": disnake.ButtonStyle.blurple,
            "grey": disnake.ButtonStyle.grey,
            "red": disnake.ButtonStyle.red
        }

        raw_style = style_override or btn_conf.get("style", "green")
        style = style_map.get(raw_style, disnake.ButtonStyle.green)

        button_kwargs = {
            "label": label,
            "style": style,
            "custom_id": f"Store_Buy:{product_id}",
            "disabled": not has_stock
        }
        if emoji and has_stock:
            button_kwargs["emoji"] = emoji

        button_list = [disnake.ui.Button(**button_kwargs)]


        reserva = info.get("reservation", {})
        if reserva.get("enabled"):
            button_list.append(disnake.ui.Button(
                label="Reservar",
                style=disnake.ButtonStyle.grey,
                custom_id=f"Store_Reserve:{product_id}",
                disabled=not has_stock
            ))

        return button_list

    async def get_publish_payload(self, product: dict, product_id: str, guild: disnake.Guild, template: str = "standard", options: dict = None):
        if options is None:
            options = {}

        if template == "legacy":
            template = "standard"

        name = product.get("name")
        desc = product.get("info", {}).get("description") or ""
        banner_url = product.get("info", {}).get("banner_url") or product.get("info", {}).get("banner")
        thumb_url = product.get("info", {}).get("thumbnail_url")

        campos = product.get("campos", {})
        has_options = len(campos) > 1
        prices = [c.get("price", 0) for c in campos.values()]

        display_coupon_code = product.get("info", {}).get("display_coupon")
        coupon_data = product.get("cupons", {}).get(display_coupon_code) if display_coupon_code else None

        if not prices:
            price_text = "R$ 0,00"
        elif coupon_data and len(campos) == 1:
            old_price = prices[0]
            discount = coupon_data.get("porcentagem", 0)
            new_price = old_price * (1 - discount / 100)
            price_text = f"~~{Utils.format_price_brl(old_price)}~~ {Utils.format_price_brl(new_price)}"
        else:
            price_text = Utils.format_price_brl(min(prices))

        gallery_items = []
        store_files = []

        if banner_url:
            bw = product.get("info", {}).get("banner_width")
            bh = product.get("info", {}).get("banner_height")
            if bw or bh:
                from functions.media import ImageHandler
                buf = await ImageHandler.resize_banner(banner_url, width=int(bw) if bw else None, height=int(bh) if bh else None)
                if buf:
                    store_files.append(disnake.File(buf, filename="store_banner.png"))
                    gallery_items.append(disnake.MediaGalleryItem(media="attachment://store_banner.png"))
                else:
                    gallery_items.append(disnake.MediaGalleryItem(media=banner_url))
            else:
                gallery_items.append(disnake.MediaGalleryItem(media=banner_url))

        if template == "premium":


            auto_bullet = product.get("info", {}).get("auto_bullet", False)
            if auto_bullet:
                topics = desc.split("\n")
                formatted_desc = "\n".join([f"* {t.strip()}" for t in topics if t.strip()])
            else:
                formatted_desc = desc


            if formatted_desc.strip():
                header_content = f"### {name}\n{formatted_desc}"
            else:
                header_content = f"### {name}"

            header_text = disnake.ui.TextDisplay(header_content)


            opt_include_icon = options.get("include_icon", True)
            opt_floating_banner = options.get("floating_banner", False)
            opt_floating_footer = options.get("floating_footer", False)
            opt_invisible_color = options.get("invisible_color", False)
            opt_color = options.get("color")
            opt_btn_style = options.get("button_style")
            opt_btn_emoji = options.get("button_emoji")


            if thumb_url and opt_include_icon:
                container_components = [
                    disnake.ui.Section(
                        header_text,
                        accessory=disnake.ui.Thumbnail(media=thumb_url)
                    ),
                ]
            else:
                container_components = [
                    header_text,
                ]


            if banner_url and not opt_floating_banner:
                container_components.insert(0, disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=banner_url)))
                container_components.insert(1, disnake.ui.Separator())

            total_stock = 0
            has_infinite = False
            for fid, fdn in campos.items():
                if fdn.get("infinite_stock", {}).get("enabled"):
                    has_infinite = True

                total_stock += StockManager.get_available_stock(product_id, fid)

            has_options = len(campos) > 1

            previews = product.get("info", {}).get("previews", [])
            has_previews = len(previews) > 0


            container_kwargs = {}
            if not opt_invisible_color:
                if opt_color:
                    try:
                        container_kwargs["accent_colour"] = disnake.Colour(int(opt_color.lstrip("#"), 16))
                    except Exception:
                        pass
                else:
                    hex_color = product.get("info", {}).get("hex_color")
                    if hex_color:
                        try:
                            container_kwargs["accent_colour"] = disnake.Colour(int(hex_color.lstrip("#"), 16))
                        except Exception:
                            pass

            all_components = self.get_public_component(product_id, style_override=opt_btn_style, emoji_override=opt_btn_emoji)
            buy_button = all_components[0]
            reserve_button = all_components[1] if len(all_components) > 1 else None


            pre_components = []

            if banner_url and opt_floating_banner:
                pre_components.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=banner_url)))

            if has_options:

                style_map = {
                    "green": disnake.ButtonStyle.green,
                    "blurple": disnake.ButtonStyle.blurple,
                    "grey": disnake.ButtonStyle.grey,
                    "red": disnake.ButtonStyle.red
                }
                btn_s = style_map.get(opt_btn_style or "green", disnake.ButtonStyle.green)
                options_btn_kwargs = {
                    "label": "Ver Opções",
                    "style": btn_s,
                    "custom_id": f"Store_ShowOptions:{product_id}"
                }
                if opt_btn_emoji:
                    options_btn_kwargs["emoji"] = opt_btn_emoji
                options_btn = disnake.ui.Button(**options_btn_kwargs)

                bottom_text = f"Apartir de **{price_text}**\n-# Clique no botão \"Ver Opções\""

                if opt_floating_footer:

                    payload = {
                        "components": [
                            *pre_components,
                            disnake.ui.Container(*container_components, **container_kwargs),
                            disnake.ui.Section(
                                disnake.ui.TextDisplay(bottom_text),
                                accessory=options_btn
                            ),
                            disnake.ui.Separator(),
                        ]
                    }
                else:

                    container_components.append(disnake.ui.Separator())
                    container_components.append(disnake.ui.Section(
                        disnake.ui.TextDisplay(bottom_text),
                        accessory=options_btn
                    ))
                    payload = {
                        "components": [
                            *pre_components,
                            disnake.ui.Container(*container_components, **container_kwargs),
                        ]
                    }
            else:

                if has_infinite:
                    bottom_text = f"**{price_text}**\n-# Clique no botão para comprar."
                else:
                    bottom_text = f"**{price_text}**\n-# Restam apenas **{total_stock}** unidades"

                if opt_floating_footer:
                    payload = {
                        "components": [
                            *pre_components,
                            disnake.ui.Container(*container_components, **container_kwargs),
                            disnake.ui.Section(
                                disnake.ui.TextDisplay(bottom_text),
                                accessory=buy_button
                            ),
                            disnake.ui.Separator(),
                        ]
                    }
                else:
                    container_components.append(disnake.ui.Separator())
                    container_components.append(disnake.ui.Section(
                        disnake.ui.TextDisplay(bottom_text),
                        accessory=buy_button
                    ))
                    payload = {
                        "components": [
                            *pre_components,
                            disnake.ui.Container(*container_components, **container_kwargs),
                        ]
                    }

            if reserve_button:
                payload["components"].append(
                    disnake.ui.ActionRow(reserve_button)
                )

            extra_info = product.get("info", {}).get("extra_info")
            extra_buttons = []
            is_contas = product.get("type") == "contas"
            if has_previews and is_contas:
                extra_buttons.append(disnake.ui.Button(label="Ver Skins", style=disnake.ButtonStyle.grey, custom_id=f"Store_Preview:{product_id}"))
            if extra_info:
                extra_buttons.append(disnake.ui.Button(label="Mais Informações", style=disnake.ButtonStyle.grey, custom_id=f"Store_ExtraInfo:{product_id}"))
            if extra_buttons:
                payload["components"].append(disnake.ui.ActionRow(*extra_buttons))

        else:


            opt_include_icon = options.get("include_icon", True)
            opt_invisible_color = options.get("invisible_color", False)
            opt_color = options.get("color")
            opt_btn_style = options.get("button_style")
            opt_btn_emoji = options.get("button_emoji")

            all_components = self.get_public_component(product_id, style_override=opt_btn_style, emoji_override=opt_btn_emoji)
            buy_button = all_components[0]
            reserve_button = all_components[1] if len(all_components) > 1 else None


            if desc.strip():
                header_content = f"# {name}\n{desc}"
            else:
                header_content = f"# {name}"

            header_td = disnake.ui.TextDisplay(header_content)

            if thumb_url and opt_include_icon:
                header_component = disnake.ui.Section(
                    header_td,
                    accessory=disnake.ui.Thumbnail(media=thumb_url)
                )
            else:
                header_component = header_td

            if has_options:

                style_map = {
                    "green": disnake.ButtonStyle.green,
                    "blurple": disnake.ButtonStyle.blurple,
                    "grey": disnake.ButtonStyle.grey,
                    "red": disnake.ButtonStyle.red
                }
                btn_s = style_map.get(opt_btn_style or "green", disnake.ButtonStyle.green)
                options_btn_kwargs = {
                    "label": "Ver Opções",
                    "style": btn_s,
                    "custom_id": f"Store_ShowOptions:{product_id}"
                }
                if opt_btn_emoji:
                    options_btn_kwargs["emoji"] = opt_btn_emoji
                options_btn = disnake.ui.Button(**options_btn_kwargs)

                container_components = [header_component]
                container_components.append(disnake.ui.Separator())
                container_components.append(disnake.ui.Section(disnake.ui.TextDisplay(f"**Preços a partir de:** {price_text}"), accessory=options_btn))
            else:
                container_components = [header_component]
                container_components.append(disnake.ui.Separator())
                container_components.append(disnake.ui.Section(disnake.ui.TextDisplay(f"**Preço:** {price_text}"), accessory=buy_button))

            if reserve_button:
                container_components.append(disnake.ui.Separator())
                container_components.append(disnake.ui.Section(disnake.ui.TextDisplay("-# Reserve o item agora:"), accessory=reserve_button))

            if gallery_items:
                container_components.insert(0, disnake.ui.MediaGallery(*gallery_items))


            container_kwargs = {}
            if not opt_invisible_color:
                if opt_color:
                    try:
                        container_kwargs["accent_colour"] = disnake.Colour(int(opt_color.lstrip("#"), 16))
                    except Exception:
                        pass
                else:
                    hex_color = product.get("info", {}).get("hex_color")
                    if hex_color:
                        try:
                            container_kwargs["accent_colour"] = disnake.Colour(int(hex_color.lstrip("#"), 16))
                        except Exception:
                            pass

            payload = {"components": [disnake.ui.Container(*container_components, **container_kwargs)]}

            previews = product.get("info", {}).get("previews", [])
            extra_info = product.get("info", {}).get("extra_info")

            extra_buttons = []
            is_contas = product.get("type") == "contas"
            if previews and is_contas:
                extra_buttons.append(disnake.ui.Button(label="Visualizar Previews", style=disnake.ButtonStyle.grey, custom_id=f"Store_Preview:{product_id}"))
            if extra_info:
                extra_buttons.append(disnake.ui.Button(label="Mais Informações", style=disnake.ButtonStyle.grey, custom_id=f"Store_ExtraInfo:{product_id}"))

            if extra_buttons:
                payload["components"].append(disnake.ui.ActionRow(*extra_buttons))

        if store_files:
            payload["files"] = store_files
        return payload

    @staticmethod
    async def sync_messages(bot: commands.Bot, product_id: str, product: dict = None):
        """Sincroniza todas as mensagens publicadas de um produto com os dados atuais.

        Se product for passado, usa diretamente (evita re-leitura do cache).
        Quando chamado pelo dashboard_sync_loop, o save e notify são feitos pelo loop.
        Quando chamado externamente (sem product), faz save e notify aqui.
        """
        called_externally = product is None

        if called_externally:
            products = Database.get_document("loja_products")
            product = products.get(product_id)

        if not product:
            return

        messages = product.get("messages", [])
        if not messages:
            return

        publisher = bot.get_cog("ProductPublisher")
        if not publisher:
            return

        to_remove = []
        changed = False

        for i, msg_info in enumerate(messages):
            try:
                guild_id = int(msg_info["guild_id"])
                channel_id = int(msg_info["channel_id"])

                guild = bot.get_guild(guild_id)
                if not guild:
                    try: guild = await bot.fetch_guild(guild_id)
                    except Exception as e:
                        print(f"[SyncMessages] Guild {guild_id} não encontrada: {e}")
                        continue

                channel = guild.get_channel(channel_id)
                if not channel:
                    try: channel = await bot.fetch_channel(channel_id)
                    except Exception as e:
                        print(f"[SyncMessages] Canal {channel_id} não encontrado: {e}")
                        continue

                template = msg_info.get("template", "standard")
                msg_options = msg_info.get("options", {})
                payload = await publisher.get_publish_payload(product, product_id, guild, template, msg_options)


                if msg_info.get("pending") or not msg_info.get("message_id"):

                    if msg_info.get("_retry_count", 0) >= 3:
                        continue

                    send_kwargs = {
                        "components": payload.get("components"),
                        "flags": disnake.MessageFlags(is_components_v2=True),
                    }

                    try:
                        new_msg = await channel.send(**send_kwargs)
                        msg_info["message_id"] = str(new_msg.id)
                        msg_info.pop("pending", None)
                        msg_info.pop("_retry_count", None)
                        changed = True
                    except Exception as send_err:
                        msg_info["_retry_count"] = msg_info.get("_retry_count", 0) + 1
                        print(f"[SyncMessages] Erro ao publicar mensagem pendente {i} do produto {product_id} (tentativa {msg_info['_retry_count']}): {send_err}")
                        changed = True
                    continue


                try:
                    msg = await channel.fetch_message(int(msg_info["message_id"]))
                except Exception:
                    to_remove.append(msg_info)
                    continue

                edit_kwargs = {
                    "content": payload.get("content"),
                    "embed": None,
                    "components": payload.get("components"),
                    "flags": disnake.MessageFlags(is_components_v2=True),
                }

                await msg.edit(**edit_kwargs)

            except Exception as e:
                print(f"[SyncMessages] Erro ao sincronizar mensagem {i} do produto {product_id}: {e}")

        if to_remove:
            for rm in to_remove:
                if rm in product["messages"]:
                    product["messages"].remove(rm)
            changed = True


        if called_externally and changed:
            products[product_id] = product
            await Database.save_document_await("loja_products", products)
            ProductPublisher._notify_sync(product_id)

    @staticmethod
    def _notify_sync(product_id: str):
        config = Database.get_config()
        api_url = config.get("api_url")
        bot_id = config.get("bot_id")
        bot_token = config.get("bot_token")
        if not api_url or not bot_id:
            return

        def _send():
            try:
                headers = {"Content-Type": "application/json"}
                if bot_token:
                    headers["Authorization"] = str(bot_token)
                http_requests.post(
                    f"{api_url}/api/bot/{bot_id}/store/sync-notify",
                    json={"product_id": product_id},
                    headers=headers,
                    timeout=5,
                )
            except Exception as e:
                print(f"[SyncNotify] Erro ao notificar backend: {e}")

        threading.Thread(target=_send, daemon=True).start()

    @commands.Cog.listener("on_button_click")
    async def on_buy_sync_clicks(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id

        if cid.startswith("Store_Preview:"):
            product_id = cid.split(":")[1]
            products = Database.get_document("loja_products")
            product = products.get(product_id)
            if not product:
                await inter.response.send_message("Produto não encontrado.", ephemeral=True)
                return

            previews = product.get("info", {}).get("previews", [])
            if not previews:
                await inter.response.send_message("Este produto não possui imagens de preview.", ephemeral=True)
                return


            gallery_items = [disnake.MediaGalleryItem(media=url) for url in previews[:10]]

            container = disnake.ui.Container(
                disnake.ui.MediaGallery(*gallery_items)
            )

            accent = disnake.Colour(0x5865F2)
            if accent:
                pass

            await inter.response.send_message(components=[container], flags=disnake.MessageFlags(is_components_v2=True, ephemeral=True))

        elif cid.startswith("Store_ExtraInfo:"):
            product_id = cid.split(":")[1]
            products = Database.get_document("loja_products")
            product = products.get(product_id)
            if not product:
                await inter.response.send_message("Produto não encontrado.", ephemeral=True)
                return

            extra_info = product.get("info", {}).get("extra_info", "")
            if not extra_info:
                await inter.response.send_message("Este produto não possui informações extras.", ephemeral=True)
                return

            await inter.response.send_message(extra_info, ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(ProductPublisher(bot))
