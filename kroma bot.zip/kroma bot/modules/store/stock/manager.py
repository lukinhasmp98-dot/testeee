import disnake
from typing import Optional
from functions.database import Database


class StockManager:
    KEY_STOCK = "database/store/stock.json"

    @staticmethod
    def _load_stock() -> dict:
        return Database.get_document("loja_stock") or {}

    @staticmethod
    async def _load_stock_fresh() -> dict:
        return await Database.refresh_document("loja_stock") or {}

    @staticmethod
    def _save_stock(stock_data: dict):
        Database.save_document("loja_stock", stock_data)

    @staticmethod
    async def _save_stock_await(stock_data: dict):
        # Caminho critico: deducao apos compra. Espera persistir no Mongo
        # antes de continuar pra evitar race com publisher.refresh_document
        # que poderia ler estoque antigo enquanto a fire-and-forget esta no ar.
        await Database.save_document_await("loja_stock", stock_data)

    @staticmethod
    async def refresh_products():
        await Database.refresh_document("loja_products")

    @staticmethod
    def get_available_stock(product_id: str, field_id: str) -> int:
        products = Database.get_document_ref("loja_products") or {}
        product = products.get(product_id, {})
        field = product.get("campos", {}).get(field_id, {})

        if field.get("infinite_stock", {}).get("enabled"):
            return 999999

        stock = Database.get_document_ref("loja_stock") or {}
        product_stock = stock.get(product_id, {})
        field_stock = product_stock.get(field_id, [])
        return len(field_stock) if isinstance(field_stock, list) else 0

    @staticmethod
    async def get_available_stock_fresh(product_id: str, field_id: str) -> int:
        await Database.refresh_document("loja_products")
        products = Database.get_document("loja_products") or {}
        product = products.get(product_id, {})
        field = product.get("campos", {}).get(field_id, {})

        if field.get("infinite_stock", {}).get("enabled"):
            return 999999

        stock = await StockManager._load_stock_fresh()
        product_stock = stock.get(product_id, {})
        field_stock = product_stock.get(field_id, [])
        return len(field_stock) if isinstance(field_stock, list) else 0

    @staticmethod
    async def get_stock_items_fresh(product_id: str, field_id: str, quantity: int) -> Optional[list[str]]:
        await Database.refresh_document("loja_products")
        products = Database.get_document("loja_products") or {}
        product = products.get(product_id, {})
        field = product.get("campos", {}).get(field_id, {})

        infinite_stock = field.get("infinite_stock", {})
        if infinite_stock.get("enabled"):
            value = infinite_stock.get("value", "Infinite Stock Item")
            return [value] * quantity

        stock = await StockManager._load_stock_fresh()

        if product_id not in stock:
            stock[product_id] = {}
        if field_id not in stock[product_id]:
            stock[product_id][field_id] = []

        field_stock = stock[product_id][field_id]

        if not isinstance(field_stock, list) or len(field_stock) < quantity:
            print(f"[STOCK] Insuficiente: produto={product_id} field={field_id} pedido={quantity} disponivel={len(field_stock) if isinstance(field_stock, list) else 0}")
            return None

        items = field_stock[:quantity]
        stock[product_id][field_id] = field_stock[quantity:]
        await StockManager._save_stock_await(stock)
        print(f"[STOCK] Deduzido: produto={product_id} field={field_id} qty={quantity} restante={len(stock[product_id][field_id])}")
        return items

    @staticmethod
    def get_stock_items(product_id: str, field_id: str, quantity: int, peek: bool = False) -> Optional[list[str]]:
        products = Database.get_document("loja_products") or {}
        product = products.get(product_id, {})
        field = product.get("campos", {}).get(field_id, {})

        infinite_stock = field.get("infinite_stock", {})
        if infinite_stock.get("enabled"):
            value = infinite_stock.get("value", "Infinite Stock Item")
            return [value] * quantity

        stock = StockManager._load_stock()

        if product_id not in stock:
            stock[product_id] = {}
        if field_id not in stock[product_id]:
            stock[product_id][field_id] = []

        field_stock = stock[product_id][field_id]

        if not isinstance(field_stock, list) or len(field_stock) < quantity:
            return None

        items = field_stock[:quantity]
        if not peek:
            stock[product_id][field_id] = field_stock[quantity:]
            StockManager._save_stock(stock)
        return items

    @staticmethod
    def add_stock_items(product_id: str, field_id: str, items: list[str]):
        stock = StockManager._load_stock()

        had_stock = False
        if product_id in stock and field_id in stock[product_id]:
            existing_stock = stock[product_id][field_id]
            if isinstance(existing_stock, list):
                had_stock = len(existing_stock) > 0

        if product_id not in stock:
            stock[product_id] = {}
        if field_id not in stock[product_id]:
            stock[product_id][field_id] = []

        if isinstance(stock[product_id][field_id], list):
            stock[product_id][field_id].extend(items)
        else:
            stock[product_id][field_id] = items

        StockManager._save_stock(stock)

        if not had_stock and len(items) > 0:
            return True
        return False

    @staticmethod
    def return_stock_items(product_id: str, field_id: str, items: list[str]):
        StockManager.add_stock_items(product_id, field_id, items)

    @staticmethod
    async def notify_stock_available(bot, product_id: str, field_id: str):
        if not bot:
            return

        products = Database.get_document("loja_products")
        product = products.get(product_id, {})
        if not product:
            return

        notifications_doc = Database.get_document("loja_stock_notifications") or {}
        notifications = notifications_doc.get("notifications", {})

        to_notify = []
        for key, data in notifications.items():
            if (data.get("product_id") == product_id and
                data.get("campo_id") == field_id and
                not data.get("notified", False)):
                to_notify.append(key)

        if not to_notify:
            return

        product_name = product.get("name", "Product")
        fields = product.get("campos", {})
        field = fields.get(field_id, {})
        field_name = field.get("name", field_id)

        for key in to_notify:
            data = notifications[key]
            user_id = data.get("user_id")
            if not user_id:
                continue

            try:
                user = await bot.fetch_user(int(user_id))
                message_content = f"Olá {user.mention}, o campo **{field_name}** do produto **{product_name}** acabou de receber reestoque!"

                container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"# Estoque Disponível!\n\n{message_content}"),
                    disnake.ui.Separator(),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(label="Desativar Notificação", style=disnake.ButtonStyle.red, custom_id=f"disable_stock_notification:{product_id}:{field_id}")
                    ),
                )

                await user.send(components=[container], flags=disnake.MessageFlags(is_components_v2=True))

                data["notified"] = True
                data["notified_at"] = int(disnake.utils.utcnow().timestamp())
                notifications[key] = data
            except Exception:
                pass

        notifications_doc["notifications"] = notifications
        Database.save_document("loja_stock_notifications", notifications_doc)
