import disnake
from disnake.ext import commands, tasks
from functions.database import Database


class ClientsModule(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.sync_roles.is_running():
            self.sync_roles.start()

    def cog_unload(self):
        self.sync_roles.cancel()

    @tasks.loop(minutes=30)
    async def sync_roles(self):
        await self.bot.wait_until_ready()
        customers = Database.get_document("loja_customers") or {"decorations": [], "spent": {}}
        decs = sorted(customers.get("decorations", []), key=lambda x: x["min"], reverse=True)
        spent_data = customers.get("spent", {})
        if not decs:
            return

        for guild in self.bot.guilds:
            for user_id, total in spent_data.items():
                member = guild.get_member(int(user_id))
                if not member:
                    continue
                for d in decs:
                    if total >= d["min"]:
                        role = guild.get_role(d["role_id"])
                        if role and role not in member.roles:
                            try:
                                await member.add_roles(role)
                            except Exception:
                                pass
                        break


def setup(bot: commands.Bot):
    bot.add_cog(ClientsModule(bot))
