import disnake
from disnake.ext import commands
from functions.database import Database
import datetime


class WalletModule(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def format_value(value: float) -> str:
        return f"{value:.2f}"

    @staticmethod
    def get_internal_balance() -> float:
        doc = Database.get_document("wallet_internal") or {}
        return doc.get("balance", 0.0)

    @staticmethod
    async def add_sale(amount: float, cart_id: str = None):
        doc = Database.get_document("wallet_internal") or {
            "balance": 0.0,
            "total_sales": 0.0,
            "sales_count": 0
        }


        transaction_fee = 0.50
        net_amount = max(0.0, amount - transaction_fee)

        doc["balance"] = doc.get("balance", 0.0) + net_amount
        doc["total_sales"] = doc.get("total_sales", 0.0) + amount
        doc["sales_count"] = doc.get("sales_count", 0) + 1
        Database.save_document("wallet_internal", doc)


        # There is no automatic withdrawal in a manual PIX operation.

    @staticmethod
    async def check_auto_withdraw():
        return None

    @staticmethod
    def deduct_balance(amount: float):
        doc = Database.get_document("wallet_internal") or {"balance": 0.0}
        doc["balance"] = max(0.0, doc.get("balance", 0.0) - amount)
        Database.save_document("wallet_internal", doc)


def setup(bot: commands.Bot):
    bot.add_cog(WalletModule(bot))
