import disnake
from disnake.ext import commands, tasks
from functions.database import Database
from modules.store.checkout.handler import CheckoutHandler
import random
import asyncio
import datetime

class FakeLogsModule(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.run_fake_logs.is_running():
            self.run_fake_logs.start()

    def cog_unload(self):
        self.run_fake_logs.cancel()

    @tasks.loop(seconds=10)
    async def run_fake_logs(self):
        try:
            prefs = Database.get_document("loja_preferences") or {}
            fake_logs = prefs.get("fake_logs", {})

            if not fake_logs.get("enabled", False):
                return

            now = int(datetime.datetime.utcnow().timestamp())
            next_run = fake_logs.get("next_run", 0)

            if now < next_run:
                return


            await self.generate_fake_log(fake_logs)


            min_d = fake_logs.get("min_delay", 30)
            max_d = fake_logs.get("max_delay", 120)
            delay = random.randint(min_d, max_d)


            prefs = Database.get_document("loja_preferences") or {}
            fake_logs = prefs.get("fake_logs", {})
            fake_logs["next_run"] = now + (delay * 60) + random.randint(0, 59)
            Database.save_document("loja_preferences", prefs)

        except Exception as e:
            print(f"[FAKE_LOGS] Erro no loop: {e}")

    async def generate_fake_log(self, config: dict):
        guild_id = Database.get_config("server_id")
        guild = self.bot.get_guild(int(guild_id)) if guild_id else None

        if not guild:
            if not self.bot.guilds:
                print("[FAKE_LOGS] Nenhum servidor disponível")
                return
            guild = self.bot.guilds[0]

        prefs = Database.get_document("loja_preferences") or {}
        log_channel_id = prefs.get("log_public_id")
        if not log_channel_id:
            return


        loja_products = Database.get_document("loja_products") or {}
        if not loja_products:
            return

        available_products = [
            p for p in loja_products.values()
            if isinstance(p, dict) and p.get("campos")
        ]
        if not available_products:
            return

        selected_product = random.choice(available_products)
        product_name = selected_product.get("name", "Produto")

        campos = selected_product.get("campos", {})
        if not campos:
            print(f"[FAKE_LOGS] Produto '{product_name}' sem campos")
            return

        field_id = random.choice(list(campos.keys()))
        field = campos[field_id]

        price = field.get("price", 0.0)
        field_name = field.get("name", "")
        if field_name:
             product_name = f"{product_name} ({field_name})"

        price_str = f"{price:.2f}".replace(".", ",")


        members = [m for m in guild.members if not m.bot]
        if not members:
            try:
                members = [m async for m in guild.fetch_members(limit=100) if not m.bot]
            except Exception as e:
                print(f"[FAKE_LOGS] Erro ao buscar membros: {e}")
        if not members:
            print("[FAKE_LOGS] Nenhum membro encontrado no servidor")
            return
        member = random.choice(members)


        p_url = "https://discord.com"
        if selected_product.get("messages"):
            m = selected_product["messages"][0]
            g_id = m.get('guild_id')
            ch_id = m.get('channel_id')
            msg_id = m.get('message_id')
            if g_id and ch_id and msg_id:
                p_url = f"https://discord.com/channels/{g_id}/{ch_id}/{msg_id}"

        data = {
            "Cliente": member.mention,
            "Produto": f"**{product_name}**",
            "Valor": f"`R$ {price_str}`",
            "ProductURL": p_url
        }


        try:
            await CheckoutHandler.send_store_log(self.bot, "public", data, inter=None, user_override=member)
            print(f"[FAKE_LOGS] Log fake enviado: {product_name} — R$ {price_str}")
        except Exception as e:
            print(f"[FAKE_LOGS] Erro ao enviar log fake: {e}")
            import traceback
            traceback.print_exc()


def setup(bot: commands.Bot):
    bot.add_cog(FakeLogsModule(bot))
