"""Manual payment helpers for Kroma Studio.

There is intentionally no gateway client here. Payment confirmation is a
staff action after the customer sends a PIX receipt.
"""
from functions.database import Database


class PaymentWrapper:
    @staticmethod
    async def check_any_payment(provider: str, config: dict, txid: str) -> bool:
        return False

    @staticmethod
    async def create_manual_pix(amount: float, cart_id: str) -> dict:
        pix = Database.get_config().get("manual_pix", {})
        if not pix.get("enabled") or not pix.get("key"):
            raise RuntimeError("PIX manual não configurado")
        return {"txid": f"MANUAL-{cart_id}", "pix_copy_paste": str(pix["key"])}
