import disnake
from disnake.ext import commands
from .utils import LogManager
from datetime import datetime

class MemberLogs(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_member_join")
    async def on_member_join(self, member: disnake.Member):
        account_age = disnake.utils.utcnow() - member.created_at
        days = account_age.days

        fields = [
            {"name": "Informações", "value": f"-# Membro: {member.mention}\n-# ID: `{member.id}`\n-# Conta criada há: {days} dias"}
        ]

        await LogManager.send_log(
            member.guild,
            "canal_de_logs_de_entradas",
            "Entrada Separada",
            fields
        )

    @commands.Cog.listener("on_member_remove")
    async def on_member_remove(self, member: disnake.Member):
        fields = [
            {"name": "Informações", "value": f"-# Membro: {member.mention}\n-# ID: `{member.id}`\n-# Tag: `{member.name}`"}
        ]

        await LogManager.send_log(
            member.guild,
            "canal_de_logs_de_saidas",
            "Saída Separada",
            fields
        )

    @commands.Cog.listener("on_member_update")
    async def on_member_update(self, before: disnake.Member, after: disnake.Member):

        if before.nick != after.nick:
            fields = [
                {"name": "Informações", "value": f"-# Membro: {after.mention}\n-# Antigo Nick: `{before.nick or 'Nenhum'}`\n-# Novo Nick: `{after.nick or 'Nenhum'}`"},
            ]
            await LogManager.send_log(after.guild, "canal_de_logs_de_mensagens", "Atualização de Nick", fields)

        if len(before.roles) != len(after.roles):

            added = [r for r in after.roles if r not in before.roles]
            removed = [r for r in before.roles if r not in after.roles]

            executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.member_role_update, after.id)
            executor_str = f"{executor.mention} (`{executor.id}`)" if executor else "Sistema ou não identificado"

            for role in added:
                fields = [
                    {"name": "Informações", "value": f"-# Membro: {after.mention}\n-# Cargo: {role.mention}\n-# Executor: {executor_str}"},
                ]
                await LogManager.send_log(after.guild, "canal_de_logs_de_cargos_adicionados", "Cargo Adicionado", fields)

            for role in removed:
                fields = [
                    {"name": "Informações", "value": f"-# Membro: {after.mention}\n-# Cargo: {role.mention}\n-# Executor: {executor_str}"},
                ]
                await LogManager.send_log(after.guild, "canal_de_logs_de_cargos_removidos", "Cargo Removido", fields)

def setup(bot: commands.Bot):
    bot.add_cog(MemberLogs(bot))
