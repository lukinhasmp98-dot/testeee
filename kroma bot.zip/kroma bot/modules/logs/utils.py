import disnake
import asyncio
from functions.database import Database

PERM_TRANSLATIONS = {
    "add_reactions": "Adicionar Reações",
    "administrator": "Administrador",
    "attach_files": "Anexar Arquivos",
    "ban_members": "Banir Membros",
    "change_nickname": "Alterar Apelido",
    "connect": "Conectar",
    "create_events": "Criar Eventos",
    "create_expressions": "Criar Expressões",
    "create_forum_threads": "Criar Tópicos de Fórum",
    "create_instant_invite": "Criar Convite Instantâneo",
    "create_private_threads": "Criar Tópicos Privados",
    "create_public_threads": "Criar Tópicos Públicos",
    "deafen_members": "Ensurdecer Membros",
    "embed_links": "Inserir Links",
    "external_emojis": "Usar Emojis Externos",
    "external_stickers": "Usar Figurinhas Externas",
    "kick_members": "Expulsar Membros",
    "manage_channels": "Gerenciar Canais",
    "manage_emojis": "Gerenciar Emojis",
    "manage_emojis_and_stickers": "Gerenciar Emojis e Figurinhas",
    "manage_events": "Gerenciar Eventos",
    "manage_expressions": "Gerenciar Expressões",
    "manage_guild": "Gerenciar Servidor",
    "manage_messages": "Gerenciar Mensagens",
    "manage_nicknames": "Gerenciar Apelidos",
    "manage_permissions": "Gerenciar Permissões",
    "manage_roles": "Gerenciar Cargos",
    "manage_threads": "Gerenciar Tópicos",
    "manage_webhooks": "Gerenciar Webhooks",
    "mention_everyone": "Mencionar Everyone",
    "moderate_members": "Moderar Membros",
    "move_members": "Mover Membros",
    "mute_members": "Silenciar Membros",
    "priority_speaker": "Voz Prioritária",
    "read_message_history": "Ver Histórico de Mensagens",
    "read_messages": "Ver Canal",
    "request_to_speak": "Pedir para Falar",
    "send_messages": "Enviar Mensagens",
    "send_messages_in_threads": "Enviar Mensagens em Tópicos",
    "send_tts_messages": "Enviar Mensagens TTS",
    "send_voice_messages": "Enviar Mensagens de Voz",
    "speak": "Falar",
    "start_embedded_activities": "Iniciar Atividades",
    "stream": "Transmitir",
    "use_application_commands": "Usar Comandos de Aplicativos",
    "use_embedded_activities": "Usar Atividades",
    "use_external_emojis": "Usar Emojis Externos",
    "use_external_sounds": "Usar Sons Externos",
    "use_external_stickers": "Usar Figurinhas Externas",
    "use_slash_commands": "Usar Comandos de Barra",
    "use_soundboard": "Usar Soundboard",
    "use_voice_activation": "Usar Detecção de Voz",
    "view_audit_log": "Ver Registro de Auditoria",
    "view_channel": "Ver Canal",
    "view_creator_monetization_analytics": "Ver Análises de Monetização",
    "view_guild_insights": "Ver Insights do Servidor",
}

CHANNEL_TYPE_TRANSLATIONS = {
    "text": "Texto",
    "voice": "Voz",
    "category": "Categoria",
    "news": "Anúncios",
    "stage_voice": "Palco",
    "forum": "Fórum",
    "private": "Privado",
    "group": "Grupo",
    "public_thread": "Tópico Público",
    "private_thread": "Tópico Privado",
    "news_thread": "Tópico de Anúncios",
}

class LogManager:
    @staticmethod
    def translate_perm(perm: str) -> str:
        return PERM_TRANSLATIONS.get(perm, perm.replace("_", " ").title())

    @staticmethod
    def translate_channel_type(channel_type) -> str:
        tipo = str(channel_type).replace("ChannelType.", "")
        return CHANNEL_TYPE_TRANSLATIONS.get(tipo, tipo.title())

    @staticmethod
    async def send_log(guild: disnake.Guild, config_key: str, title: str, fields: list, **kwargs):
        config = Database.get_document("canais")
        channel_id = config.get(config_key)
        fallback_key = kwargs.get("fallback_key")
        if not channel_id and fallback_key:
            channel_id = config.get(fallback_key)
        if not channel_id:
            return

        channel = guild.get_channel(int(channel_id))
        if not channel:
            try:
                channel = await guild.fetch_channel(int(channel_id))
            except Exception:
                return

        if not channel:
            return

        container_components = [
            disnake.ui.TextDisplay(f"# {title}\n-# Sistema de Monitoramento"),
            disnake.ui.Separator(),
        ]

        for field in fields:
            container_components.append(disnake.ui.TextDisplay(f"**{field['name']}**\n{field['value']}"))

        try:
            await channel.send(
                components=[disnake.ui.Container(*container_components)],
                flags=disnake.MessageFlags(is_components_v2=True),
                allowed_mentions=disnake.AllowedMentions.none()
            )
        except Exception as e:
            print(f"[LogManager] Erro ao enviar log: {e}")

    @staticmethod
    async def get_executor(guild: disnake.Guild, action: disnake.AuditLogAction, target_id: int = None):
        try:
            await asyncio.sleep(0.5)
            async for entry in guild.audit_logs(limit=1, action=action):
                if target_id and entry.target.id != target_id:
                    continue
                return entry.user
        except Exception:
            pass
        return None
