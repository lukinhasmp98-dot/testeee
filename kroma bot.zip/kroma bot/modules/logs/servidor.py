import disnake
from disnake.ext import commands
from .utils import LogManager

class ServerLogs(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_guild_role_create")
    async def on_guild_role_create(self, role: disnake.Role):
        executor = await LogManager.get_executor(role.guild, disnake.AuditLogAction.role_create)
        fields = [
            {"name": "Informações", "value": f"-# Cargo: {role.mention}\n-# ID: `{role.id}`\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
        ]
        await LogManager.send_log(role.guild, "canal_de_logs_de_cargos_criados", "Cargo Criado", fields)

    @commands.Cog.listener("on_guild_role_delete")
    async def on_guild_role_delete(self, role: disnake.Role):
        executor = await LogManager.get_executor(role.guild, disnake.AuditLogAction.role_delete)
        fields = [
            {"name": "Informações", "value": f"-# Nome: `{role.name}`\n-# ID: `{role.id}`\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
        ]
        await LogManager.send_log(role.guild, "canal_de_logs_de_cargos_excluidos", "Cargo Excluído", fields)

    @commands.Cog.listener("on_guild_role_update")
    async def on_guild_role_update(self, before: disnake.Role, after: disnake.Role):
        changes = []

        if before.name != after.name:
            changes.append(f"**Nome:** `{before.name}` ➔ `{after.name}`")

        if before.color != after.color:
            changes.append(f"**Cor:** `{before.color}` ➔ `{after.color}`")

        if before.hoist != after.hoist:
            changes.append(f"**Exibir separadamente:** `{'Sim' if after.hoist else 'Não'}`")

        if before.mentionable != after.mentionable:
            changes.append(f"**Mencionável:** `{'Sim' if after.mentionable else 'Não'}`")

        if changes:
            executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.role_update, after.id)
            fields = [
                {"name": "Informações", "value": f"-# Cargo: {after.mention}\n-# ID: `{after.id}`\n-# Executor: {executor.mention if executor else 'Não identificado'}"},
                {"name": "Modificações", "value": "\n".join(changes)}
            ]
            await LogManager.send_log(after.guild, "canal_de_logs_de_cargos_editados", "Cargo Editado", fields)

        if before.permissions != after.permissions:
            executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.role_update, after.id)

            added = [p[0] for p in after.permissions if p[1] and not getattr(before.permissions, p[0])]
            removed = [p[0] for p in before.permissions if p[1] and not getattr(after.permissions, p[0])]

            changes = []
            if added:
                changes.append(f"**Acesso Concedido:** {', '.join([f'`{LogManager.translate_perm(a)}`' for a in added])}")
            if removed:
                changes.append(f"**Acesso Revogado:** {', '.join([f'`{LogManager.translate_perm(r)}`' for r in removed])}")

            fields = [
                {"name": "Informações", "value": f"-# Cargo: {after.mention}\n-# Executor: {executor.mention if executor else 'Não identificado'}"},
                {"name": "Mudanças de Permissões", "value": "\n".join(changes) if changes else "Mudança de ordem ou permissões internas."}
            ]
            await LogManager.send_log(after.guild, "canal_de_logs_de_cargos_editados", "Permissões de Cargo Alteradas", fields)

    @commands.Cog.listener("on_guild_channel_create")
    async def on_guild_channel_create(self, channel: disnake.abc.GuildChannel):
        executor = await LogManager.get_executor(channel.guild, disnake.AuditLogAction.channel_create)
        fields = [
            {"name": "Informações", "value": f"-# Canal: {channel.mention}\n-# Tipo: `{LogManager.translate_channel_type(channel.type)}`\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
        ]
        await LogManager.send_log(channel.guild, "canal_de_logs_de_canais_criados", "Canal Criado", fields)

    @commands.Cog.listener("on_guild_channel_delete")
    async def on_guild_channel_delete(self, channel: disnake.abc.GuildChannel):
        executor = await LogManager.get_executor(channel.guild, disnake.AuditLogAction.channel_delete)
        fields = [
            {"name": "Nome", "value": f"`{channel.name}`"},
            {"name": "Tipo", "value": f"`{LogManager.translate_channel_type(channel.type)}`"},
            {"name": "Executor", "value": f"{executor.mention if executor else 'Não identificado'}"}
        ]
        await LogManager.send_log(channel.guild, "canal_de_logs_de_canais_excluidos", "Canal Excluído", fields)

    @commands.Cog.listener("on_guild_channel_update")
    async def on_guild_channel_update(self, before: disnake.abc.GuildChannel, after: disnake.abc.GuildChannel):
        executor = None
        changes = []

        if before.name != after.name:
            changes.append(f"**Nome:** `{before.name}` ➔ `{after.name}`")

        if hasattr(before, "topic") and hasattr(after, "topic"):
            if before.topic != after.topic:
                changes.append(f"**Tópico:** `{before.topic or 'Nenhum'}` ➔ `{after.topic or 'Nenhum'}`")

        if hasattr(before, "nsfw") and hasattr(after, "nsfw"):
            if before.nsfw != after.nsfw:
                changes.append(f"**NSFW:** `{'Ativado' if after.nsfw else 'Desativado'}`")

        if hasattr(before, "slowmode_delay") and hasattr(after, "slowmode_delay"):
            if before.slowmode_delay != after.slowmode_delay:
                changes.append(f"**Modo Lento:** `{before.slowmode_delay}s` ➔ `{after.slowmode_delay}s`")

        if before.category != after.category:
            changes.append(f"**Categoria:** `{before.category.name if before.category else 'Nenhuma'}` ➔ `{after.category.name if after.category else 'Nenhuma'}`")

        if changes:
            executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.channel_update, after.id)
            fields = [
                {"name": "Informações", "value": f"-# Canal: {after.mention}\n-# Tipo: `{LogManager.translate_channel_type(after.type)}`\n-# Executor: {executor.mention if executor else 'Não identificado'}"},
                {"name": "Modificações", "value": "\n".join(changes)}
            ]
            await LogManager.send_log(after.guild, "canal_de_logs_de_canais_editados", "Canal Editado", fields)

        if before.overwrites != after.overwrites:

            before_targets = set(before.overwrites.keys())
            after_targets = set(after.overwrites.keys())

            if after_targets > before_targets:
                executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.overwrite_create, after.id)
                target = (after_targets - before_targets).pop()
                target_mention = target.mention if hasattr(target, 'mention') else f"`{target.name}`"
                target_type = "Cargo" if isinstance(target, disnake.Role) else "Membro"

                new_overwrite = after.overwrites.get(target)
                perm_changes = []
                if new_overwrite:
                    allow, deny = new_overwrite.pair()
                    for perm, _ in disnake.Permissions.all():
                        if getattr(allow, perm):
                            perm_changes.append(f"`{LogManager.translate_perm(perm)}` → Concedido")
                        elif getattr(deny, perm):
                            perm_changes.append(f"`{LogManager.translate_perm(perm)}` → Negado")

                fields = [
                    {"name": "Informações", "value": f"-# Canal: {after.mention}\n-# Tipo de Alvo: `{target_type}`\n-# Alvo: {target_mention}\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
                ]
                if perm_changes:
                    fields.append({"name": "Permissões Configuradas", "value": "\n".join(perm_changes[:15]) + ("\n..." if len(perm_changes) > 15 else "")})

                await LogManager.send_log(after.guild, "canal_de_logs_de_permissoes_adicionadas", "Permissão Adicionada ao Canal", fields)

            elif before_targets > after_targets:
                executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.overwrite_delete, after.id)
                target = (before_targets - after_targets).pop()
                target_mention = target.mention if hasattr(target, 'mention') else f"`{target.name}`"
                target_type = "Cargo" if isinstance(target, disnake.Role) else "Membro"

                old_overwrite = before.overwrites.get(target)
                perm_removed = []
                if old_overwrite:
                    allow, deny = old_overwrite.pair()
                    for perm, _ in disnake.Permissions.all():
                        if getattr(allow, perm):
                            perm_removed.append(f"`{LogManager.translate_perm(perm)}` (estava Concedido)")
                        elif getattr(deny, perm):
                            perm_removed.append(f"`{LogManager.translate_perm(perm)}` (estava Negado)")

                fields = [
                    {"name": "Informações", "value": f"-# Canal: {after.mention}\n-# Tipo de Alvo: `{target_type}`\n-# Alvo: {target_mention}\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
                ]
                if perm_removed:
                    fields.append({"name": "Permissões Removidas", "value": "\n".join(perm_removed[:15]) + ("\n..." if len(perm_removed) > 15 else "")})

                await LogManager.send_log(after.guild, "canal_de_logs_de_permissoes_removidas", "Permissão Removida do Canal", fields)

            else:
                executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.overwrite_update, after.id)

                target_mention = "Alvo não identificado"
                target_type = "Desconhecido"
                changes = []

                for target, after_overwrite in after.overwrites.items():
                    before_overwrite = before.overwrites.get(target)
                    if before_overwrite and before_overwrite != after_overwrite:
                        target_mention = target.mention if hasattr(target, 'mention') else f"`{target.name}`"
                        target_type = "Cargo" if isinstance(target, disnake.Role) else "Membro"

                        allow_after, deny_after = after_overwrite.pair()
                        allow_before, deny_before = before_overwrite.pair()

                        for perm, _ in disnake.Permissions.all():
                            val_before = "allow" if getattr(allow_before, perm) else ("deny" if getattr(deny_before, perm) else "neutral")
                            val_after = "allow" if getattr(allow_after, perm) else ("deny" if getattr(deny_after, perm) else "neutral")

                            if val_before != val_after:
                                status_map = {"allow": "Concedido", "deny": "Negado", "neutral": "Neutro"}
                                changes.append(f"`{LogManager.translate_perm(perm)}`: {status_map[val_before]} ➔ {status_map[val_after]}")
                        break

                fields = [
                    {"name": "Informações", "value": f"-# Canal: {after.mention}\n-# Tipo de Alvo: `{target_type}`\n-# Alvo: {target_mention}\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
                ]
                if changes:
                    fields.append({"name": "Mudanças nas Permissões", "value": "\n".join(changes[:15]) + ("\n..." if len(changes) > 15 else "")})

                await LogManager.send_log(after.guild, "canal_de_logs_de_canais_editados", "Permissões de Canal Alteradas", fields)

def setup(bot: commands.Bot):
    bot.add_cog(ServerLogs(bot))
