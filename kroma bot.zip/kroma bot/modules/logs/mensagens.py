import disnake
from disnake.ext import commands
from .utils import LogManager

class MessageLogs(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_message_delete")
    async def on_message_delete(self, message: disnake.Message):
        if message.guild is None or message.author.bot:
            return

        executor = await LogManager.get_executor(
            message.guild,
            disnake.AuditLogAction.message_delete,
            message.author.id
        )

        executor_str = f"{executor.mention} (`{executor.id}`)" if executor else "Auto-excluiu ou não identificado"
        conteudo = message.content[:1000] if message.content else "(vazio ou apenas embed/anexo)"

        fields = [
            {"name": "Informações", "value": f"-# Canal: {message.channel.mention}\n-# Autor: {message.author.mention} (`{message.author.id}`)\n-# Executor: {executor_str}"},
            {"name": "Conteúdo", "value": f"```\n{conteudo}\n```"}
        ]

        await LogManager.send_log(
            message.guild,
            "canal_de_logs_de_mensagens_deletadas",
            "Mensagem Deletada",
            fields,
        )

    @commands.Cog.listener("on_message_edit")
    async def on_message_edit(self, before: disnake.Message, after: disnake.Message):
        if before.author.bot or before.content == after.content:
            return

        fields = [
            {"name": "Informações", "value": f"-# Canal: {before.channel.mention}\n-# Autor: {before.author.mention} (`{before.author.id}`)"},
            {"name": "Antes", "value": f"```\n{before.content[:500]}\n```"},
            {"name": "Depois", "value": f"```\n{after.content[:500]}\n```"}
        ]

        await LogManager.send_log(
            before.guild,
            "canal_de_logs_de_mensagens_editadas",
            "Mensagem Editada",
            fields,
        )

def setup(bot: commands.Bot):
    bot.add_cog(MessageLogs(bot))
