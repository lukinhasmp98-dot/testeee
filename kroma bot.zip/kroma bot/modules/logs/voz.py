import disnake
from disnake.ext import commands
from .utils import LogManager

class VoiceLogs(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_voice_state_update")
    async def on_voice_state_update(self, member: disnake.Member, before: disnake.VoiceState, after: disnake.VoiceState):
        if member.bot:
            return

        if before.channel is None and after.channel is not None:
            fields = [
                {"name": "Informações", "value": f"-# Membro: {member.mention} (`{member.id}`)\n-# Canal: {after.channel.mention}"}
            ]
            await LogManager.send_log(member.guild, "canal_de_logs_de_trafego_em_call", "Entrou em Call", fields)

        elif before.channel is not None and after.channel is None:
            fields = [
                {"name": "Informações", "value": f"-# Membro: {member.mention} (`{member.id}`)\n-# Canal: {before.channel.mention}"}
            ]
            await LogManager.send_log(member.guild, "canal_de_logs_de_trafego_em_call", "Saiu da Call", fields)

        elif before.channel is not None and after.channel is not None and before.channel.id != after.channel.id:
            fields = [
                {"name": "Informações", "value": f"-# Membro: {member.mention} (`{member.id}`)\n-# Saiu de: {before.channel.mention}\n-# Entrou em: {after.channel.mention}"}
            ]
            await LogManager.send_log(member.guild, "canal_de_logs_de_trafego_em_call", "Mudou de Call", fields)

def setup(bot: commands.Bot):
    bot.add_cog(VoiceLogs(bot))
