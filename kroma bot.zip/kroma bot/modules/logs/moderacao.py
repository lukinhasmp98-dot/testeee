import disnake
from disnake.ext import commands
from .utils import LogManager

class ModerationLogs(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_member_ban")
    async def on_member_ban(self, guild: disnake.Guild, user: disnake.User):
        executor = await LogManager.get_executor(guild, disnake.AuditLogAction.ban, user.id)
        executor_str = f"{executor.mention} (`{executor.id}`)" if executor else "Sistema ou não identificado"

        reason = "Não informado"
        try:
            async for entry in guild.audit_logs(limit=1, action=disnake.AuditLogAction.ban):
                if entry.target.id == user.id:
                    reason = entry.reason or "Não informado"
                    break
        except Exception:
            pass

        fields = [
            {"name": "Informações", "value": f"-# Membro: {user.mention} (`{user.id}`)\n-# Executor: {executor_str}\n-# Motivo: `{reason}`"}
        ]

        await LogManager.send_log(
            guild,
            "canal_de_logs_de_banimentos",
            "Membro Banido",
            fields
        )

    @commands.Cog.listener("on_member_unban")
    async def on_member_unban(self, guild: disnake.Guild, user: disnake.User):
        executor = await LogManager.get_executor(guild, disnake.AuditLogAction.unban, user.id)
        executor_str = f"{executor.mention} (`{executor.id}`)" if executor else "Sistema ou não identificado"

        fields = [
            {"name": "Informações", "value": f"-# Membro: {user.mention} (`{user.id}`)\n-# Executor: {executor_str}"}
        ]

        await LogManager.send_log(
            guild,
            "canal_de_logs_de_banimentos",
            "Membro Desbanido",
            fields
        )

    @commands.Cog.listener("on_member_remove")
    async def on_member_kick(self, member: disnake.Member):

        executor = await LogManager.get_executor(member.guild, disnake.AuditLogAction.kick, member.id)
        if executor:
            fields = [
                {"name": "Informações", "value": f"-# Membro: {member.mention} (`{member.id}`)\n-# Executor: {executor.mention} (`{executor.id}`)"}
            ]
            await LogManager.send_log(member.guild, "canal_de_logs_de_expulsoes", "Membro Expulso (Kick)", fields)

    @commands.Cog.listener("on_member_update")
    async def on_member_timeout(self, before: disnake.Member, after: disnake.Member):

        if before.current_timeout != after.current_timeout:
            if after.current_timeout:
                executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.member_update, after.id)
                expire_ts = int(after.current_timeout.timestamp())
                fields = [
                    {"name": "Informações", "value": f"-# Membro: {after.mention} (`{after.id}`)\n-# Expira: <t:{expire_ts}:R>\n-# Executor: {executor.mention if executor else 'Não identificado'}"}
                ]
                await LogManager.send_log(after.guild, "canal_de_logs_de_castigos", "Membro Castigado", fields)
            else:
                executor = await LogManager.get_executor(after.guild, disnake.AuditLogAction.member_update, after.id)
                fields = [
                    {"name": "Informações", "value": f"-# Membro: {after.mention} (`{after.id}`)\n-# Castigo removido por: {executor.mention if executor else 'Não identificado'}"}
                ]
                await LogManager.send_log(after.guild, "canal_de_logs_de_castigos", "Membro Descastigado", fields)

def setup(bot: commands.Bot):
    bot.add_cog(ModerationLogs(bot))
