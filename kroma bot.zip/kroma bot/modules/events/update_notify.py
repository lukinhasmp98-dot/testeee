import disnake
import asyncio
from disnake.ext import commands
from functions.database import Database
import functions.log_reporter as log_reporter
import time


_MAX_WAIT_SECONDS = 30

_MAX_CHANNEL_RETRIES = 5


class UpdateNotify(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._sent = False

    @commands.Cog.listener()
    async def on_ready(self):
        if self._sent:
            return
        self._sent = True


        self.bot.loop.create_task(self._check_and_notify())

    async def _wait_until_ready(self):
        waited = 0
        while waited < _MAX_WAIT_SECONDS:
            if Database._loaded and getattr(self.bot, '_fully_ready', False):
                return True
            await asyncio.sleep(0.5)
            waited += 0.5
        return False

    async def _find_channel(self, channel_id: str):
        for attempt in range(_MAX_CHANNEL_RETRIES):
            for guild in self.bot.guilds:
                channel = guild.get_channel(int(channel_id))
                if channel:
                    return channel

            for guild in self.bot.guilds:
                try:
                    channel = await guild.fetch_channel(int(channel_id))
                    if channel:
                        return channel
                except Exception:
                    pass
            if attempt < _MAX_CHANNEL_RETRIES - 1:
                await asyncio.sleep(2 * (attempt + 1))
        return None

    async def _check_and_notify(self):
        try:

            ready = await self._wait_until_ready()
            if not ready:
                log_reporter.warn("Timeout esperando DB/bot ficarem prontos para notificação de atualização", "UPDATE")
                return


            bot_config = Database.get_document("bot_config")
            notify = bot_config.get("_update_notify")

            if not notify:
                bot_config = await Database.refresh_document("bot_config")
                notify = bot_config.get("_update_notify")

            if not notify:
                return

            version = notify.get("version", "desconhecida")
            custom_message = notify.get("message")


            canais = Database.get_document("canais")
            channel_id = canais.get("canal_de_atualizacoes")

            if not channel_id:
                log_reporter.info(f"Atualização v{version} recebida, mas nenhum canal de atualizações configurado", "UPDATE")
                await self._clear_notify()
                return


            channel = await self._find_channel(channel_id)

            if not channel:
                log_reporter.warn(f"Canal de atualizações {channel_id} não encontrado após {_MAX_CHANNEL_RETRIES} tentativas", "UPDATE")
                await self._clear_notify()
                return


            ts = int(time.time())

            components_list = [
                disnake.ui.TextDisplay(f"# Atualização do Sistema\n-# Versão {version}"),
                disnake.ui.Separator(),
            ]

            if custom_message:
                components_list.append(disnake.ui.TextDisplay(f"**Notas da Atualização**\n{custom_message}"))
                components_list.append(disnake.ui.Separator())

            components_list.append(disnake.ui.TextDisplay(
                f"**Informações**\n"
                f"-# Status: Atualizado e reiniciado com sucesso\n"
                f"-# Data: <t:{ts}:F>"
            ))

            await channel.send(
                components=[disnake.ui.Container(*components_list)],
                flags=disnake.MessageFlags(is_components_v2=True),
                allowed_mentions=disnake.AllowedMentions.none()
            )

            log_reporter.success(f"Notificação de atualização v{version} enviada no canal {channel_id}", "UPDATE")


            await self._clear_notify()

        except Exception as e:
            log_reporter.error(f"Erro ao enviar notificação de atualização: {e}", "UPDATE")

    async def _clear_notify(self):
        try:
            bot_config = Database.get_document("bot_config")
            if "_update_notify" in bot_config:
                del bot_config["_update_notify"]
                Database.save_document("bot_config", bot_config)
        except Exception:
            pass


def setup(bot: commands.Bot):
    bot.add_cog(UpdateNotify(bot))
