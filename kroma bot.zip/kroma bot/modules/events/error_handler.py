import disnake
import traceback
import sys
from disnake.ext import commands

class ErrorHandler(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_slash_command_error(self, inter: disnake.ApplicationCommandInteraction, error: Exception):
        if isinstance(error, commands.CommandInvokeError):
            original = error.original
        else:
            original = error


        if isinstance(original, (commands.CommandOnCooldown, commands.MissingPermissions)):
            try:
                await inter.send(f"⚠️ {str(original)}", ephemeral=True)
            except Exception:
                pass
            return


        tb = "".join(traceback.format_exception(type(original), original, original.__traceback__))
        print(f"[COMANDO ERRO] /{inter.application_command.name} chamou um erro: \n{tb}", file=sys.stderr)


        user_msg = "❌ Ocorreu um erro inesperado ao executar este comando. Os desenvolvedores foram notificados."
        try:
            if inter.response.is_done():
                await inter.followup.send(user_msg, ephemeral=True)
            else:
                await inter.response.send_message(user_msg, ephemeral=True)
        except Exception as defer_error:
            print(f"[ERRO HANDLER] Não rolou responder o usuário final: {defer_error}")


        if self.bot.owner_id:
            try:
                owner = await self.bot.fetch_user(self.bot.owner_id)
                if owner:
                    chunks = [tb[i:i+1900] for i in range(0, len(tb), 1900)]
                    await owner.send(f"⚠️ **Erro Detectado no Comando `/{inter.application_command.name}`**\nUsuário: {inter.author} ({inter.author.id})\nServidor: {inter.guild.name if inter.guild else 'DM'}")
                    for chunk in chunks:
                        await owner.send(f"```py\n{chunk}\n```")
            except Exception as owner_err:
                print(f"[ERRO HANDLER] Falha ao enviar DM para o owner: {owner_err}")


    @commands.Cog.listener()
    async def on_button_click_error(self, inter: disnake.MessageInteraction, error: Exception):

        pass

def setup(bot: commands.Bot):
    bot.add_cog(ErrorHandler(bot))
