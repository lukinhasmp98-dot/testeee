"""Controles diretos no Discord para boas-vindas, cargos e sorteios."""
from __future__ import annotations

import uuid

import disnake
from disnake.ext import commands

from functions.database import Database
from functions.giveaways import GiveawaysManager
from functions.permissions import Permissions


FLAGS = disnake.MessageFlags(is_components_v2=True)


def card(title: str, text: str, color=disnake.Colour(0x43DBD0)):
    return [disnake.ui.Container(
        disnake.ui.TextDisplay(f"# {title}"), disnake.ui.Separator(),
        disnake.ui.TextDisplay(text), accent_colour=color,
    )]


class CommunityControls(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _guard(self, inter) -> bool:
        if await Permissions.check_user(inter.user.id):
            return True
        await inter.response.send_message(
            components=card("ACESSO RESTRITO", "Somente a administração pode alterar esta configuração.", disnake.Colour.red()),
            flags=FLAGS, ephemeral=True,
        )
        return False

    @commands.slash_command(name="boas_vindas", description="Configura a mensagem de boas-vindas do servidor.", default_member_permissions=disnake.Permissions(manage_guild=True))
    async def boas_vindas(self, inter, canal: disnake.TextChannel, mensagem: str, mencionar_usuario: bool = True):
        if not await self._guard(inter):
            return
        Database.save_document("welcome_message", {
            "enabled": True, "channel_id": str(canal.id), "message_type": "plain",
            "content": mensagem[:1900], "mention_user": mencionar_usuario,
        })
        await inter.response.send_message(
            components=card("BOAS-VINDAS ATIVADAS", f"Novos membros receberão a mensagem em {canal.mention}.\n\nPlaceholders: `{{user.mention}}`, `{{user.name}}`, `{{server.name}}`, `{{server.member_count}}`."),
            flags=FLAGS, ephemeral=True,
        )

    @commands.slash_command(name="autorole", description="Define o cargo recebido por novos membros.", default_member_permissions=disnake.Permissions(manage_guild=True))
    async def autorole(self, inter, cargo: disnake.Role):
        if not await self._guard(inter):
            return
        if cargo >= inter.guild.me.top_role:
            return await inter.response.send_message(
                components=card("CARGO INVÁLIDO", "O cargo do bot precisa estar acima do cargo que ele vai atribuir.", disnake.Colour.red()), flags=FLAGS, ephemeral=True,
            )
        Database.save_document("auto_role", {"role_id": str(cargo.id)})
        await inter.response.send_message(components=card("AUTOROLE ATIVO", f"Novos membros receberão {cargo.mention}."), flags=FLAGS, ephemeral=True)

    @commands.slash_command(name="sorteio", description="Cria e publica um sorteio com botão de participação.", default_member_permissions=disnake.Permissions(manage_guild=True))
    async def sorteio(self, inter, canal: disnake.TextChannel, premio: str, horas: float, vencedores: int = 1):
        if not await self._guard(inter):
            return
        if not 0.05 <= horas <= 720 or not 1 <= vencedores <= 20:
            return await inter.response.send_message(
                components=card("VALORES INVÁLIDOS", "Use entre `0,05` e `720` horas, e entre `1` e `20` vencedores.", disnake.Colour.red()), flags=FLAGS, ephemeral=True,
            )
        giveaway_id = GiveawaysManager.gerar_id()
        task_id = uuid.uuid4().hex[:10]
        data = {
            "name": premio[:100], "mode": "real", "min_participants": 0,
            "allowed_roles": [], "forbidden_roles": [], "min_account_age_days": 0,
            "min_invites": 0, "bonus_roles": {},
            "button": {"label": "Participar", "style": "blurple"},
            "container": {"content": f"# SORTEIO / KROMA STUDIO\n**Prêmio:** {premio[:500]}\n\nClique no botão abaixo para participar!\n-# Participantes: {{participants}} · Ganhadores: {{winners}} · Termina: {{end_time}}"},
            "tasks": [{"id": task_id, "channel_id": str(canal.id), "duration_hours": horas, "max_winners": vencedores, "participants": [], "status": "scheduled", "draws": []}],
        }
        GiveawaysManager.salvar_giveaway(giveaway_id, data)
        await inter.response.send_message(
            components=card("SORTEIO CRIADO", f"**{premio[:100]}** será publicado em {canal.mention} em alguns segundos e ficará aberto por `{horas:g}` hora(s)."), flags=FLAGS, ephemeral=True,
        )


def setup(bot: commands.Bot):
    bot.add_cog(CommunityControls(bot))
