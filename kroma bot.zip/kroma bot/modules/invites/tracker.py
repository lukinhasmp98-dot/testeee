import disnake
from disnake.ext import commands, tasks
import datetime

from . import helpers
from functions.database import Database
from modules.store.stock.manager import StockManager

class InviteTrackerSystem(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.invites = {}
        self.locks = {}
        self._welcome_cache = {}

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.ranking_task.is_running():
            self.ranking_task.start()

    def cog_unload(self):
        self.ranking_task.cancel()

    def get_lock(self, guild_id: int):
        import asyncio
        if guild_id not in self.locks:
            self.locks[guild_id] = asyncio.Lock()
        return self.locks[guild_id]

    @tasks.loop(minutes=1)
    async def ranking_task(self):
        config = helpers.get_config()
        channel_id = config.get("ranking_channel_id")
        message_id = config.get("ranking_message_id")

        if not channel_id or not message_id:
            return

        try:
            channel = self.bot.get_channel(int(channel_id))
            if not channel: return

            from .core import InviteTrackerModule
            module = self.bot.get_cog("InviteTrackerModule")
            if not module: return

            guild = channel.guild
            components = await module.generate_ranking_components(guild)

            try:
                msg = await channel.fetch_message(int(message_id))
                await msg.edit(components=components, flags=disnake.MessageFlags(is_components_v2=True))

            except disnake.NotFound:

                config["ranking_message_id"] = None
                helpers.save_config(config)
        except Exception as e:
            err_msg = str(e).split("<!DOCTYPE html>")[0].strip()
            print(f"[RANKING TASK ERROR] {err_msg}")

    @commands.Cog.listener("on_ready")
    async def on_ready(self):
        await self.bot.wait_until_ready()
        import asyncio
        for guild in self.bot.guilds:
            try:
                self.invites[guild.id] = await guild.invites()
                await asyncio.sleep(1.5)
            except disnake.Forbidden:
                print(f"[INVITE TRACKER] Sem permissao MANAGE_GUILD em '{guild.name}' ({guild.id}) — rastreamento de convites desativado.")
            except Exception as e:
                print(f"[INVITE TRACKER] Erro ao carregar convites da guild {guild.id}: {e}")


        await self._sync_staff_channels()

    @commands.Cog.listener("on_guild_join")
    async def on_guild_join(self, guild: disnake.Guild):
        try:
            self.invites[guild.id] = await guild.invites()
        except disnake.Forbidden:
            print(f"[INVITE TRACKER] Sem permissao MANAGE_GUILD em '{guild.name}' ({guild.id}) ao entrar — rastreamento ficara inativo ate ganhar permissao.")

    @commands.Cog.listener("on_guild_remove")
    async def on_guild_remove(self, guild: disnake.Guild):
        if guild.id in self.invites:
            del self.invites[guild.id]

    @commands.Cog.listener("on_invite_create")
    async def on_invite_create(self, invite: disnake.Invite):
        if invite.guild.id in self.invites:
            self.invites[invite.guild.id].append(invite)

        config = helpers.get_config()
        if not config.get("invite_dm_enabled", True):
            return

        inviter = invite.inviter
        if not inviter:
            return


        try:
            ts = int((disnake.utils.utcnow() + datetime.timedelta(hours=4)).timestamp())
            expiration_ts = f"<t:{ts}:R>"

            template = config.get("invite_dm_message", "")
            if not template:
                return

            msg = template.format(
                member=inviter.mention,
                membername=inviter.name,
                url=invite.url,
                expiration=expiration_ts
            )

            container = disnake.ui.Container(
                disnake.ui.TextDisplay(msg)
            )

            accent = disnake.Colour(0x5865F2)
            if accent:
                pass

            await inviter.send(components=[container], flags=disnake.MessageFlags(is_components_v2=True))
        except Exception:
            pass


        if config.get("invite_auto_delete_enabled", True):
            async def auto_delete_task():
                await asyncio.sleep(4 * 3600)
                try:
                    await invite.delete(reason="Sage: Exclusão automática de convite após 4 horas.")
                except Exception:
                    pass

            import asyncio
            self.bot.loop.create_task(auto_delete_task())

    @commands.Cog.listener("on_invite_delete")
    async def on_invite_delete(self, invite: disnake.Invite):
        if invite.guild.id in self.invites:
            self.invites[invite.guild.id] = [
                i for i in self.invites[invite.guild.id] if i.code != invite.code
            ]

    async def _check_and_give_rewards(self, guild: disnake.Guild, inviter_id_str: str, valid_invites: int):
        if inviter_id_str == "Vanity Url" or not inviter_id_str:
            return

        config = helpers.get_config()
        if not config.get("rewards_enabled", False):
            return

        try:
            inviter_member = guild.get_member(int(inviter_id_str))
            if not inviter_member:
                return

            earned_rewards = helpers.get_earned_rewards(valid_invites)

            for reward in earned_rewards:
                r_type = reward.get("type", "role")
                r_id = reward.get("id")
                r_data = reward.get("data", {})

                if r_type == "role":
                    try:
                        role = guild.get_role(int(r_id))
                        if role and role not in inviter_member.roles:
                            await inviter_member.add_roles(role, reason=f"Invite Tracker: Atingiu {valid_invites} convites")
                    except Exception: pass


                elif r_type == "product":
                    field_id = r_data.get("field_id")
                    if field_id:
                        stock = StockManager.get_stock_items(r_id, field_id, 1)
                        if stock:
                            try:
                                products = Database.get_document("loja_products")
                                p_name = products.get(r_id, {}).get("name", "Produto")
                                msg = f"Você ganhou o produto **{p_name}** por atingir **{valid_invites}** convites!\n\n**Entrega:**\n`{stock[0]}`"
                                await inviter_member.send(msg)
                            except Exception: pass
        except Exception as e:
            print(f"[REWARDS ERROR] {e}")

    async def _check_goal_role(self, guild: disnake.Guild, inviter_id_str: str, valid_invites: int):
        if inviter_id_str == "Vanity Url" or not inviter_id_str:
            return

        config = helpers.get_config()
        if not config.get("goal_role_enabled", False):
            return

        goal_role_id = config.get("goal_role_id")
        goal_invites = config.get("goal_role_invites", 0)

        if not goal_role_id or goal_invites <= 0:
            return

        if valid_invites < goal_invites:
            return

        try:
            inviter_member = guild.get_member(int(inviter_id_str))
            if not inviter_member:
                return

            role = guild.get_role(int(goal_role_id))
            if role and role not in inviter_member.roles:
                await inviter_member.add_roles(role, reason=f"Invite Tracker: Atingiu meta de {goal_invites} convites")
        except Exception as e:
            print(f"[GOAL ROLE ERROR] {e}")

    async def _update_staff_stats(self, guild: disnake.Guild, user_id: int):
        config = helpers.get_config()
        staff_channels = config.get("staff_channels", {})
        uid_str = str(user_id)

        if uid_str in staff_channels:
            channel_id = staff_channels[uid_str]

            from functions.servers import ServerManager
            target_guild = ServerManager.get_guild(self.bot, "staff") or guild

            channel = target_guild.get_channel(int(channel_id))
            member = guild.get_member(user_id)
            if channel and member:

                module = self.bot.get_cog("InviteTrackerModule")
                if module:
                    await module.update_staff_channel_panel(channel, member, config)

    async def _sync_staff_channels(self):
        config = helpers.get_config()
        staff_channels = config.get("staff_channels", {})
        staff_role_id = config.get("staff_role_id")

        if not staff_channels:
            return

        from functions.servers import ServerManager
        main_guild = ServerManager.get_guild(self.bot, "main")
        staff_guild = ServerManager.get_guild(self.bot, "staff") or main_guild

        if not main_guild or not staff_guild:
            return

        module = self.bot.get_cog("InviteTrackerModule")
        if not module:
            return


        staff_role = main_guild.get_role(int(staff_role_id)) if staff_role_id else None
        staff_member_ids = {str(m.id) for m in staff_role.members} if staff_role else set()


        deleted = 0
        channels_to_remove = []
        for uid_str, channel_id in staff_channels.items():

            if staff_role and uid_str not in staff_member_ids:
                channel = staff_guild.get_channel(int(channel_id))
                if channel:
                    try:
                        await channel.delete(reason="Invite Tracker - Membro não possui mais o cargo de staff")
                        deleted += 1
                    except Exception as e:
                        print(f"[INVITE SYNC] Erro ao deletar canal de {uid_str}: {e}")
                channels_to_remove.append(uid_str)


        for uid_str in channels_to_remove:
            staff_channels.pop(uid_str, None)

        if channels_to_remove:
            config["staff_channels"] = staff_channels
            helpers.save_config(config)

        updated = 0
        for uid_str, channel_id in staff_channels.items():
            try:
                channel = staff_guild.get_channel(int(channel_id))
                member = main_guild.get_member(int(uid_str))

                if channel and member:
                    await module.update_staff_channel_panel(channel, member, config)
                    updated += 1
            except Exception as e:
                print(f"[INVITE SYNC] Erro ao sincronizar canal de {uid_str}: {e}")

        if deleted > 0:
            print(f"[INVITE TRACKER] {deleted} canais de meta removidos (membros sem cargo)")
        if updated > 0:
            pass

    @commands.Cog.listener("on_member_join")
    async def on_member_join(self, member: disnake.Member):
        if member.bot:
            return

        lock = self.get_lock(member.guild.id)
        async with lock:
            try:
                old_invites = self.invites.get(member.guild.id, [])
                new_invites = await member.guild.invites()
                self.invites[member.guild.id] = new_invites
            except disnake.HTTPException as e:
                if e.status == 429:
                    print(f"[INVITE TRACKER] Rate limit atingido na guild {member.guild.id}. Pulando rastreamento.")
                else:
                    print(f"[INVITE TRACKER] HTTPException {e.status} ao buscar convites guild {member.guild.id}: {e}")
                return
            except disnake.Forbidden:
                print(f"[INVITE TRACKER] Sem permissao MANAGE_GUILD em '{member.guild.name}' ({member.guild.id}) ao processar entrada de {member.id} — convite NAO sera rastreado. Concede MANAGE_GUILD ao bot.")
                return
            except Exception as e:
                print(f"[INVITE TRACKER] Erro inesperado ao buscar convites: {e}")
                return

        inviter = None
        used_invite = None
        is_vanity_url = False

        # Estrategia 1: invite que existia antes e teve uses incrementado
        for invite in new_invites:
            found = next((i for i in old_invites if i.code == invite.code), None)
            if found and invite.uses > found.uses:
                inviter = invite.inviter
                used_invite = invite
                break

        # Estrategia 2: invite NOVO (criado enquanto bot offline / cache stale).
        # Aparece em new_invites mas nao em old_invites e ja tem uses>0 — provavelmente
        # foi este o usado pelo membro que acabou de entrar.
        if not used_invite:
            new_only = [i for i in new_invites if not any(o.code == i.code for o in old_invites)]
            candidates = [i for i in new_only if i.uses > 0]
            if len(candidates) == 1:
                inviter = candidates[0].inviter
                used_invite = candidates[0]
                print(f"[INVITE TRACKER] Match via fallback NEW-INVITE em '{member.guild.name}' ({member.guild.id}): code={used_invite.code} inviter={inviter.id if inviter else 'None'}")
            elif len(candidates) > 1:
                print(f"[INVITE TRACKER] Ambiguidade NEW-INVITE em {member.guild.id}: {len(candidates)} candidatos — nao da pra identificar inviter")

        # Estrategia 3: invite com max_uses atingido foi auto-deletado pelo Discord.
        # Estava em old, sumiu de new, e tinha uses == max_uses-1 (consumido na entrada).
        if not used_invite:
            disappeared = [o for o in old_invites if not any(n.code == o.code for n in new_invites)]
            cap_hits = [o for o in disappeared if getattr(o, 'max_uses', 0) > 0 and (o.uses + 1) == o.max_uses]
            if len(cap_hits) == 1:
                inviter = cap_hits[0].inviter
                used_invite = cap_hits[0]
                print(f"[INVITE TRACKER] Match via fallback CAP-DELETED em '{member.guild.name}' ({member.guild.id}): code={used_invite.code} inviter={inviter.id if inviter else 'None'}")
            elif len(cap_hits) > 1:
                print(f"[INVITE TRACKER] Ambiguidade CAP-DELETED em {member.guild.id}: {len(cap_hits)} candidatos")

        if not used_invite:
            print(f"[INVITE TRACKER] Sem match de invite em '{member.guild.name}' ({member.guild.id}) pra {member.id} — assumindo Vanity URL")
            is_vanity_url = True
            inviter_id_str = "Vanity Url"
        elif inviter is None:
            inviter_id_str = None
            is_vanity_url = False
        else:
            inviter_id_str = str(inviter.id)
            is_vanity_url = False

        inviter_data = None
        if inviter_id_str and inviter_id_str != "Vanity Url":
            invites_data = helpers.get_invites_data()
            guild_id_str = str(member.guild.id)
            member_id_str = str(member.id)

            if guild_id_str not in invites_data:
                invites_data[guild_id_str] = {"invites": {}, "members": {}}

            if inviter_id_str not in invites_data[guild_id_str]["invites"]:
                invites_data[guild_id_str]["invites"][inviter_id_str] = {
                    "total": 0, "valid": 0, "fake": 0, "bonus": 0, "left": 0
                }

            inviter_data = invites_data[guild_id_str]["invites"][inviter_id_str]
            inviter_data["total"] += 1
            inviter_data["valid"] += 1

            invites_data[guild_id_str]["members"][member_id_str] = {
                "inviter": inviter_id_str,
                "code": used_invite.code if used_invite else "vanity_url"
            }
            helpers.save_invites_data(invites_data)

            await self._check_and_give_rewards(member.guild, inviter_id_str, inviter_data["valid"])
            await self._check_goal_role(member.guild, inviter_id_str, inviter_data["valid"])
            await self._update_staff_stats(member.guild, int(inviter_id_str))

        config = helpers.get_config()
        if not config.get("ativado", False) or not config.get("welcome_active", True):
            return

        channel_id = config.get("channel_id")
        if not channel_id:
            return

        channel = self.bot.get_channel(int(channel_id))
        if not channel:
            return


        now = datetime.datetime.now().timestamp()
        last_welcome = self._welcome_cache.get(member.id, 0)
        if now - last_welcome < 3600:
            return
        self._welcome_cache[member.id] = now

        if is_vanity_url:
            welcome_message = config.get("welcome_message_vanity", "") or config.get("welcome_message", "")
            inviter_mention = "Vanity Url"
            inviter_name = "Vanity Url"
            entry_mode = "Vanity Url"
            total_invites = inviter_data["total"] if inviter_data else 0
        else:
            welcome_message = config.get("welcome_message", "")
            if inviter is None:
                inviter_mention = "Usuário Desconhecido"
                inviter_name = "Usuário Desconhecido"
                total_invites = 0
            else:
                inviter_mention = inviter.mention
                inviter_name = inviter.display_name
                total_invites = inviter_data["valid"] if inviter_data else 0
            entry_mode = "Convite"

        if not welcome_message or not welcome_message.strip():
            return

        try:
            message_content = welcome_message.format(
                member=member.mention,
                membername=member.display_name,
                inviter=inviter_mention,
                invitername=inviter_name,
                invites=total_invites,
                entry_mode=entry_mode
            )
        except KeyError:
            message_content = welcome_message.format(
                member=member.mention,
                membername=member.display_name
            )

        await self._send_formatted_message(channel, message_content, config)

    @commands.Cog.listener("on_member_remove")
    async def on_member_remove(self, member: disnake.Member):
        if member.bot:
            return

        invites_data = helpers.get_invites_data()
        guild_id_str = str(member.guild.id)
        member_id_str = str(member.id)
        inviter_id_str = None
        inviter_data = None

        if guild_id_str in invites_data and member_id_str in invites_data[guild_id_str].get("members", {}):
            member_data = invites_data[guild_id_str]["members"].pop(member_id_str)
            if isinstance(member_data, dict):
                inviter_id_str = member_data.get("inviter")
            elif isinstance(member_data, str):
                inviter_id_str = member_data

            if inviter_id_str and inviter_id_str in invites_data[guild_id_str].get("invites", {}):
                inviter_data = invites_data[guild_id_str]["invites"][inviter_id_str]
                inviter_data["valid"] = max(0, inviter_data["valid"] - 1)
                inviter_data["left"] += 1

            helpers.save_invites_data(invites_data)
            if inviter_id_str and inviter_id_str != "Vanity Url":
                await self._update_staff_stats(member.guild, int(inviter_id_str))
                try:
                    from functions.giveaways import GiveawaysManager
                    from modules.giveaways.core import GiveawaysCog
                    inviter_member = member.guild.get_member(int(inviter_id_str))
                    if inviter_member:
                        giveaways = GiveawaysManager.obter_giveaways()
                        affected = set()
                        for gid, gv in giveaways.items():
                            for t in gv.get("tasks", []):
                                if t.get("status") != "running":
                                    continue
                                if int(inviter_id_str) not in t.get("participants", []):
                                    continue
                                ok, reason = GiveawaysManager.check_requirements(inviter_member, gv)
                                if ok:
                                    continue
                                t["participants"] = [p for p in t.get("participants", []) if p != int(inviter_id_str)]
                                GiveawaysManager.atualizar_task(gid, t["id"], t)
                                affected.add(gid)
                                try:
                                    await inviter_member.send(f"Você foi removido do sorteio **{gv.get('name')}** por não cumprir mais os requisitos:\n> {reason}")
                                except Exception:
                                    pass
                        for gid in affected:
                            self.bot.loop.create_task(GiveawaysCog.update_giveaway_messages(self.bot, gid))
                except Exception as e:
                    print(f"[INVITE TRACKER] Erro ao reavaliar sorteios apos saida de {member.id}: {e}")

        config = helpers.get_config()
        if not config.get("ativado", False) or not config.get("leave_active", True):
            return

        channel_id = config.get("channel_id")
        if not channel_id:
            return

        channel = self.bot.get_channel(int(channel_id))
        if not channel:
            return

        leave_message = config.get("leave_message", "")
        if not leave_message or not leave_message.strip():
            return

        inviter = None
        is_vanity_url = inviter_id_str == "Vanity Url"

        if inviter_id_str and not is_vanity_url:
            try:
                inviter = await self.bot.fetch_user(int(inviter_id_str))
            except (disnake.NotFound, ValueError):
                pass

        try:
            if is_vanity_url:
                inviter_mention = "Vanity Url"
                inviter_name = "Vanity Url"
                entry_mode = "Vanity Url"
                vanity_invites = inviter_data.get("total", 0) if inviter_data else 0
            else:
                inviter_mention = inviter.mention if inviter else "Usuário Desconhecido"
                inviter_name = inviter.display_name if inviter else "Usuário Desconhecido"
                entry_mode = "Convite"
                vanity_invites = inviter_data.get("valid", 0) if inviter_data else 0

            message_content = leave_message.format(
                member=member.mention,
                membername=member.display_name,
                inviter=inviter_mention,
                invitername=inviter_name,
                invites=vanity_invites,
                entry_mode=entry_mode
            )
        except KeyError:
            message_content = leave_message.format(
                member=member.mention,
                membername=member.display_name
            )

        await self._send_formatted_message(channel, message_content, config)

    async def _send_formatted_message(self, channel: disnake.TextChannel, content: str, config: dict):
        delete_after = config.get("delete_after", 0)
        if delete_after <= 0: delete_after = None

        await channel.send(
            components=[
                disnake.ui.Container(
                    disnake.ui.TextDisplay(content)
                ),
            ],
            flags=disnake.MessageFlags(is_components_v2=True),
            delete_after=delete_after
        )

    @commands.Cog.listener("on_member_update")
    async def on_member_update(self, before: disnake.Member, after: disnake.Member):
        if before.name != after.name:
            await self._update_staff_stats(after.guild, after.id)
