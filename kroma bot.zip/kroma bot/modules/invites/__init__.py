"""
Módulo de Invite Tracker.
Dividido em submódulos para melhor organização:
- core: Cog principal e handlers de interação
- modals: Classes de modais (MensagensModal, RewardConfigModal, etc)
- panels: Funções de geração de painéis UI
- helpers: Funções auxiliares e gestão de dados
- tracker: Sistema de rastreamento de convites
"""
from .core import InviteTrackerModule

__all__ = ["InviteTrackerModule"]
