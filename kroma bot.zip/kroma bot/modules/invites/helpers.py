from functions.database import Database

def get_config() -> dict:
    data = Database.get_document("invites_config") or {}
    data.setdefault("ativado", False)
    data.setdefault("channel_id", None)
    data.setdefault("welcome_message", "Seja bem-vindo(a) {member}! Você foi convidado(a) por {inviter} que agora possui {invites} convites válidos.")
    data.setdefault("welcome_message_vanity", "Seja bem-vindo(a) {member}! Você entrou através do Vanity URL do servidor.")
    data.setdefault("leave_message", "Que pena, {member} nos deixou. Ele(a) foi convidado(a) por {inviter} que agora possui {invites} convites válidos.")
    data.setdefault("message_style", "container")
    data.setdefault("rewards_enabled", False)
    data.setdefault("rewards", [])
    data.setdefault("delete_after", 0)
    data.setdefault("ranking_channel_id", None)
    data.setdefault("ranking_message_id", None)

    data.setdefault("goal_role_enabled", False)
    data.setdefault("goal_role_id", None)
    data.setdefault("goal_role_invites", 0)

    data.setdefault("staff_goals_enabled", False)
    data.setdefault("staff_role_id", None)
    data.setdefault("staff_goal_invites", 0)
    data.setdefault("staff_goal_period", "weekly")
    data.setdefault("staff_category_id", None)
    data.setdefault("staff_alert_channel_id", None)
    data.setdefault("staff_channels", {})
    data.setdefault("staff_bypass_roles", [])
    data.setdefault("staff_bypass_users", [])
    data.setdefault("invite_dm_enabled", True)
    data.setdefault("invite_auto_delete_enabled", True)
    data.setdefault("invite_dm_message", "Olá **{membername}**, você acaba de gerar um novo convite!\n\n* **Convite**: {url}\n* **Expiração**: Mesmo que tenha colocado como permanente, este convite será **excluído {expiration}** por segurança.")
    return data

def save_config(data: dict) -> None:
    Database.save_document("invites_config", data)

def get_invites_data() -> dict:
    return Database.get_document("invites_data") or {}

def save_invites_data(data: dict) -> None:
    Database.save_document("invites_data", data)

def get_rewards() -> list:
    config = get_config()
    rewards = config.get("rewards", [])

    migrated = False
    for r in rewards:
        if "role_id" in r:
            r["type"] = "role"
            r["id"] = r.pop("role_id")
            migrated = True
    if migrated:
        save_config(config)

    return sorted(rewards, key=lambda x: x.get("invites_required", 0))

def add_reward(reward_type: str, reward_id: str, invites_required: int, extra_data: dict = None) -> bool:
    config = get_config()
    rewards = config.get("rewards", [])

    for reward in rewards:
        rid = reward.get("id") or reward.get("role_id")
        if (reward.get("type", "role") == reward_type and
            str(rid) == str(reward_id) and
            int(reward.get("invites_required", 0)) == int(invites_required)):

            reward["data"] = extra_data or {}
            config["rewards"] = rewards
            save_config(config)
            return True

    rewards.append({
        "type": reward_type,
        "id": str(reward_id),
        "invites_required": invites_required,
        "data": extra_data or {}
    })
    config["rewards"] = rewards
    save_config(config)
    return True

def remove_reward(reward_type: str, reward_id: str, invites_required: int = None) -> bool:
    config = get_config()
    rewards = config.get("rewards", [])

    initial_len = len(rewards)
    new_rewards = []
    for r in rewards:
        rid = r.get("id") or r.pop("role_id", None)

        if r.get("type", "role") == reward_type and str(rid) == str(reward_id):
            if invites_required is not None and int(r.get("invites_required", 0)) != int(invites_required):
                r["id"] = rid
                new_rewards.append(r)
                continue

            continue

        r["id"] = rid
        new_rewards.append(r)

    if len(new_rewards) == initial_len:
        return False

    config["rewards"] = new_rewards
    save_config(config)
    return True

def get_earned_rewards(valid_invites: int) -> list:
    rewards = get_rewards()
    earned = []
    for reward in rewards:
        if valid_invites >= reward.get("invites_required", 0):
            earned.append(reward)
    return earned

def format_duration(seconds: int) -> str:
    if seconds == 0:
        return "Desativado"

    if seconds < 60:
        return f"{seconds} {'segundo' if seconds == 1 else 'segundos'}"

    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes} {'minuto' if minutes == 1 else 'minutos'}"

    hours = minutes // 60
    return f"{hours} {'hora' if hours == 1 else 'horas'}"

def parse_duration(text: str) -> int:
    text = text.lower().strip()
    if not text or text in ["0", "desativado", "off"]:
        return 0

    import re

    match = re.search(r'(\d+)\s*(h|m|s|hora|minuto|segundo)', text)
    if match:
        value = int(match.group(1))
        unit = match.group(2)
        if unit.startswith('h'):
            return value * 3600
        if unit.startswith('m'):
            return value * 60
        return value

    try:
        return int(text)
    except ValueError:
        return 0
