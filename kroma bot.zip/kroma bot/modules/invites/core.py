"""
Modulo de Invite Tracker (runtime)
Mantem apenas os componentes runtime: ranking publicado, painel de convites
do usuario, recompensas (consulta) e atualizacao dos canais de meta de staff.
A configuracao foi movida para a dashboard web.
"""
import disnake
from disnake.ext import commands

from functions.database import Database
from functions.servers import ServerManager

from . import helpers
from .tracker import InviteTrackerSystem


class InviteTrackerModule(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def generate_ranking_components(self, guild: disnake.Guild) -> list:
        invites_data = helpers.get_invites_data()
        gid = str(guild.id)
        guild_invites = invites_data.get(gid, {}).get("invites", {})

        header = "## Ranking de Convites\n-# O ranking e atualizado automaticamente a cada 1 minuto."
        lines = []
        count = 0
        for uid, data in sorted(guild_invites.items(), key=lambda x: x[1].get("total", 0), reverse=True):
            if count >= 10:
                break

            member = guild.get_member(int(uid))
            if not member:
                continue

            count += 1
            total = data.get("total", 0)
            prefix = ["🥇", "🥈", "🥉"][count - 1] if count <= 3 else f"` {count} `"
            lines.append(f"{prefix} {member.mention} - **{total}** convites")

        content = "\n".join(lines) if lines else "-# Nenhum convite registrado ainda."

        container = disnake.ui.Container(
            disnake.ui.TextDisplay(header),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(content),
        )

        buttons = disnake.ui.ActionRow(
            disnake.ui.Button(label="Ver recompensas", style=disnake.ButtonStyle.grey, custom_id="InviteTracker_ViewRewards"),
            disnake.ui.Button(label="Meus convites", style=disnake.ButtonStyle.blurple, custom_id="InviteTracker_ViewMyInvites"),
        )

        return [container, buttons]

    def _get_rewards_view_panel(self, guild: disnake.Guild) -> dict:
        rewards = helpers.get_rewards()

        header = "### Recompensas de Convites\n-# Veja o que voce pode ganhar convidando pessoas!"

        if not rewards:
            content = "-# Nenhuma recompensa configurada no momento."
        else:
            lines = []
            type_labels = {"role": "Cargo", "product": "Produto"}

            for r in rewards:
                r_type = r.get("type", "role")
                r_id = r.get("id")
                invites_req = r.get("invites_required", 0)
                label = type_labels.get(r_type, "Recompensa")

                name = "Desconhecido"
                if r_type == "role":
                    role = guild.get_role(int(r_id))
                    name = role.mention if role else f"Cargo ({r_id})"
                elif r_type == "product":
                    products = Database.get_document("loja_products") or {}
                    p = products.get(r_id, {})
                    name = f"Produto: **{p.get('name', r_id)}**"

                lines.append(f"- **{invites_req} convites** -> {name} ({label})")

            content = "\n".join(lines)

        return {
            "components": [
                disnake.ui.Container(
                    disnake.ui.TextDisplay(header),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(content),
                )
            ]
        }

    def _get_user_invites_panel(self, user: disnake.User, guild: disnake.Guild) -> dict:
        invites_data = helpers.get_invites_data()
        guild_id = str(guild.id)
        user_id = str(user.id)

        data = invites_data.get(guild_id, {}).get("invites", {}).get(
            user_id,
            {"valid": 0, "fake": 0, "left": 0, "bonus": 0, "total": 0},
        )

        content = (
            f"## Resumo de Convites\n"
            f"-# Informacoes gerais de {user.mention}\n\n"
            f"**Estatisticas principais**\n"
            f"-# Convites Validos: `{data.get('valid', 0)}`\n"
            f"-# Convites Bonus: `{data.get('bonus', 0)}`\n"
            f"-# Total Geral: `{data.get('total', 0)}`\n\n"
            f"**Logs detalhados**\n"
            f"-# Convites Falsos: `{data.get('fake', 0)}`\n"
            f"-# Pessoas que Sairam: `{data.get('left', 0)}`"
        )

        return {
            "components": [
                disnake.ui.Container(disnake.ui.TextDisplay(content))
            ]
        }

    async def update_staff_channel_panel(self, channel: disnake.TextChannel, member: disnake.Member, config: dict):
        invites_data = helpers.get_invites_data()

        main_guild_id = str(ServerManager.get_server_id("main"))
        guild_data = invites_data.get(main_guild_id, {}).get("invites", {})
        user_data = guild_data.get(str(member.id), {})

        valid = user_data.get("valid", 0)
        staff_goal = config.get("staff_goal_invites", 0)
        period = config.get("staff_goal_period", "weekly")
        period_text = "Semanal" if period == "weekly" else "Mensal"

        progress = min(100, int((valid / staff_goal) * 100)) if staff_goal > 0 else 0
        bar_filled = int(progress / 10)
        bar_empty = 10 - bar_filled
        progress_bar = "█" * bar_filled + "░" * bar_empty

        goal_achieved = valid >= staff_goal
        status = "Atingida!" if goal_achieved else "Em progresso"

        expected_name = f"⼁meta・{member.name[:20]}"
        normalized_expected = expected_name.lower().replace(" ", "-")
        if channel.name != normalized_expected:
            try:
                await channel.edit(name=expected_name)
            except Exception:
                pass

        container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"# Meta de Convites\n-# {member.name}"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                f"**Periodo:** `{period_text}`\n"
                f"**Meta:** `{staff_goal}` convites\n"
                f"**Seus convites:** `{valid}`\n\n"
                f"**Progresso:**\n`[{progress_bar}]` {progress}%\n\n"
                f"**Status:** {status}"
            ),
        )

        staff_messages = config.get("staff_messages", {})
        uid_str = str(member.id)
        existing_msg_id = staff_messages.get(uid_str)

        try:
            if existing_msg_id:
                try:
                    existing_msg = await channel.fetch_message(int(existing_msg_id))
                    await existing_msg.edit(components=[container])
                    return
                except disnake.NotFound:
                    pass
                except Exception:
                    pass

            try:
                await channel.purge(limit=10)
            except Exception:
                pass

            msg = await channel.send(components=[container], flags=disnake.MessageFlags(is_components_v2=True))
            staff_messages[uid_str] = str(msg.id)
            config["staff_messages"] = staff_messages
            helpers.save_config(config)
        except Exception as e:
            print(f"[INVITE TRACKER] Erro ao atualizar painel: {e}")

    @commands.Cog.listener("on_button_click")
    async def runtime_button_listener(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id
        if not cid:
            return

        if cid == "InviteTracker_ViewRewards":
            panel_data = self._get_rewards_view_panel(inter.guild)
            return await inter.response.send_message(
                **panel_data,
                ephemeral=True,
                flags=disnake.MessageFlags(is_components_v2=True),
            )

        if cid == "InviteTracker_ViewMyInvites":
            panel_data = self._get_user_invites_panel(inter.user, inter.guild)
            return await inter.response.send_message(
                **panel_data,
                ephemeral=True,
                flags=disnake.MessageFlags(is_components_v2=True),
            )


def setup(bot: commands.Bot):
    if not bot.get_cog("InviteTrackerModule"):
        try:
            bot.add_cog(InviteTrackerModule(bot))
        except Exception as e:
            print(f"Erro ao carregar InviteTrackerModule: {e}")

    if not bot.get_cog("InviteTrackerSystem"):
        try:
            bot.add_cog(InviteTrackerSystem(bot))
        except Exception as e:
            print(f"Erro ao carregar InviteTrackerSystem: {e}")
