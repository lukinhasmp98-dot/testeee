
def setup(bot):
    bot.load_extension("modules.protection.events")
