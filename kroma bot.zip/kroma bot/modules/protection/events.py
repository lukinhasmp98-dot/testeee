import disnake
from disnake.ext import commands
from functions.protection import ProtectionManager
import datetime

class ProtectionEvents(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._join_log_cache = {}

    async def _check_and_punish(self, guild: disnake.Guild, member: disnake.Member, protection_type: str, action_details: str = ""):
        config = ProtectionManager.get_config(protection_type)

        if not config.get("enabled", False):
            return

        immune_roles = config.get("immune_roles", [])
        if any(role.id in immune_roles for role in member.roles):
            return

        if member.id == guild.owner_id:
            return

        if ProtectionManager.check_violation(protection_type, member.id):
            punishment = config.get("punishment", "ban")
            punishment_text = "não aplicada"
            punishment_success = False
            error_message = None

            bot_member = guild.get_member(self.bot.user.id)
            if bot_member and member.top_role >= bot_member.top_role:
                error_message = "Cargo do infrator é superior ou igual ao do bot"
            else:

                try:
                    if punishment == "ban":
                        await member.ban(reason=f"Proteção: {protection_type} - {action_details}")
                        punishment_text = "banido"
                        punishment_success = True

                    elif punishment == "kick":
                        await member.kick(reason=f"Proteção: {protection_type} - {action_details}")
                        punishment_text = "expulso"
                        punishment_success = True

                    elif punishment == "timeout_30d":
                        timeout_until = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=30)
                        await member.timeout(until=timeout_until, reason=f"Proteção: {protection_type} - {action_details}")
                        punishment_text = "castigado por 30 dias"
                        punishment_success = True

                    elif punishment == "remove_roles":
                        roles_to_remove = [r for r in member.roles if r != guild.default_role and r.position < bot_member.top_role.position]
                        if roles_to_remove:
                            await member.remove_roles(*roles_to_remove, reason=f"Proteção: {protection_type} - {action_details}")
                            punishment_text = f"teve {len(roles_to_remove)} cargo(s) removido(s)"
                            punishment_success = True
                        else:
                            punishment_text = "sem cargos para remover ou cargos superiores ao bot"

                    else:
                        punishment_text = "apenas registrado nos logs"
                        punishment_success = True

                except disnake.Forbidden as e:
                    error_message = f"Sem permissões: {str(e)}"
                    print(f"Erro de permissão ao aplicar punição ({punishment}): {e}")

                except Exception as e:
                    error_message = f"Erro desconhecido: {str(e)}"
                    print(f"Erro ao aplicar punição: {e}")

            await self._send_log(
                guild,
                config,
                member,
                protection_type,
                action_details,
                punishment_text,
                punishment_success,
                error_message
            )

    async def _send_log(self, guild: disnake.Guild, config: dict, member: disnake.Member,
                        protection_type: str, action_details: str, punishment_text: str,
                        punishment_success: bool = True, error_message: str = None):
        log_channel_id = config.get("log_channel")
        if not log_channel_id:
            return

        channel = guild.get_channel(log_channel_id)
        if not channel:
            return

        protection_info = ProtectionManager.PROTECTION_TYPES.get(protection_type, {})
        limit = config.get("limit", 5)
        interval = config.get("interval", 60)


        status_text = "Punição aplicada com sucesso" if punishment_success else "Falha ao aplicar punição"
        if error_message:
            status_text += f"\n-# Motivo: {error_message}"

        container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"# Proteção Ativada\n-# {protection_info.get('name', 'Proteção')}"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                f"**Infrator:** {member.mention} (`{member.id}`)\n"
                f"-# {member.name}"
            ),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                f"**Detalhes da Violação:**\n"
                f"-# Tipo: {protection_info.get('name', protection_type)}\n"
                f"-# Limite: {limit} ações em {interval}s\n"
                f"-# Ação detectada: {action_details}"
            ),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                f"-# Punição: {punishment_text.capitalize()}"
            )
        )

        try:
            await channel.send(components=[container], flags=disnake.MessageFlags(is_components_v2=True))
        except Exception as e:
            print(f"Erro ao enviar log: {e}")

    @commands.Cog.listener()
    async def on_member_ban(self, guild: disnake.Guild, user: disnake.User | disnake.Member):

        try:
            async for entry in guild.audit_logs(limit=1, action=disnake.AuditLogAction.ban):
                if entry.target.id == user.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    await self._check_and_punish(
                        guild,
                        executor,
                        "mass_ban",
                        f"Banimento de {user}"
                    )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        try:
            async for entry in member.guild.audit_logs(limit=1, action=disnake.AuditLogAction.kick):
                if entry.target.id == member.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    await self._check_and_punish(
                        member.guild,
                        executor,
                        "mass_kick",
                        f"Expulsão de {member}"
                    )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: disnake.Role):
        try:
            async for entry in role.guild.audit_logs(limit=1, action=disnake.AuditLogAction.role_create):
                if entry.target.id == role.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    member = role.guild.get_member(executor.id)
                    if member:
                        await self._check_and_punish(
                            role.guild,
                            member,
                            "mass_role_create",
                            f"Criação de cargo: {role.name}"
                        )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: disnake.Role):
        try:
            async for entry in role.guild.audit_logs(limit=1, action=disnake.AuditLogAction.role_delete):
                if entry.target.id == role.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    member = role.guild.get_member(executor.id)
                    if member:
                        await self._check_and_punish(
                            role.guild,
                            member,
                            "mass_role_delete",
                            f"Exclusão de cargo: {role.name}"
                        )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: disnake.Role, after: disnake.Role):

        if before.name == after.name and before.permissions == after.permissions and before.color == after.color:
            return

        try:
            async for entry in after.guild.audit_logs(limit=1, action=disnake.AuditLogAction.role_update):
                if entry.target.id == after.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    member = after.guild.get_member(executor.id)
                    if member:
                        await self._check_and_punish(
                            after.guild,
                            member,
                            "mass_role_edit",
                            f"Edição de cargo: {after.name}"
                        )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: disnake.abc.GuildChannel):
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=disnake.AuditLogAction.channel_create):
                if entry.target.id == channel.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    member = channel.guild.get_member(executor.id)
                    if member:
                        await self._check_and_punish(
                            channel.guild,
                            member,
                            "mass_channel_create",
                            f"Criação de canal: {channel.name}"
                        )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: disnake.abc.GuildChannel):
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=disnake.AuditLogAction.channel_delete):
                if entry.target.id == channel.id:
                    executor = entry.user
                    if executor.bot:
                        return

                    member = channel.guild.get_member(executor.id)
                    if member:
                        await self._check_and_punish(
                            channel.guild,
                            member,
                            "mass_channel_delete",
                            f"Exclusão de canal: {channel.name}"
                        )
                    break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: disnake.TextChannel):
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=disnake.AuditLogAction.webhook_create):
                executor = entry.user
                if executor.bot:
                    return

                member = channel.guild.get_member(executor.id)
                if member:
                    await self._check_and_punish(
                        channel.guild,
                        member,
                        "mass_webhook_create",
                        f"Criação de webhook em {channel.name}"
                    )
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        guild = member.guild
        if not guild:
            return

        bot_config = ProtectionManager.get_config("bot_entry")
        if bot_config.get("enabled", False) and member.bot:
            await self._punish_join(guild, member, "bot_entry", "Entrada de bot bloqueada")
            return

        fake_config = ProtectionManager.get_config("anti_fake")
        if fake_config.get("enabled", False) and not member.bot:
            min_days = fake_config.get("min_days", 7)
            account_age = (disnake.utils.utcnow() - member.created_at).days

            if account_age < min_days:

                immune_roles = fake_config.get("immune_roles", [])
                if any(role.id in immune_roles for role in member.roles):
                    return

                await self._punish_join(guild, member, "anti_fake", f"Conta suspeita ({account_age} dias)")

    async def _punish_join(self, guild: disnake.Guild, member: disnake.Member, protection_type: str, action_details: str):
        config = ProtectionManager.get_config(protection_type)
        punishment = config.get("punishment", "kick")

        punishment_text = "não aplicada"
        punishment_success = False
        error_message = None

        try:
            if punishment == "ban":
                await member.ban(reason=f"Proteção: {protection_type} - {action_details}")
                punishment_text = "banido"
                punishment_success = True
            elif punishment == "kick":
                await member.kick(reason=f"Proteção: {protection_type} - {action_details}")
                punishment_text = "expulso"
                punishment_success = True
            elif punishment == "none":
                punishment_text = "apenas log"
                punishment_success = True
            else:
                await member.kick(reason=f"Proteção: {protection_type} - {action_details}")
                punishment_text = "expulso (fallback)"
                punishment_success = True
        except Exception as e:
            error_message = str(e)


        cache_key = f"{member.id}:{protection_type}"
        now = datetime.datetime.now().timestamp()
        last_log = self._join_log_cache.get(cache_key, 0)


        if now - last_log > 3600:
            self._join_log_cache[cache_key] = now
            await self._send_log(
                guild, config, member, protection_type, action_details, punishment_text, punishment_success, error_message
            )

def setup(bot: commands.Bot):
    bot.add_cog(ProtectionEvents(bot))
