"""
Módulo centralizado de sincronização do cache.
Atualiza periodicamente todos os documentos que podem ser modificados
pela dashboard/site, garantindo que o bot sempre tenha dados frescos.
"""

from disnake.ext import commands, tasks

from connections import mongo_db
from functions.database import Database


SYNCED_DOCUMENTS = [
    "loja_products",
    "loja_stock",
    "loja_preferences",
    "loja_maintenance",
    "tickets_config",
    "canais",
    "cargos",
    "bot_config",
    "ai_config",
    "payment_configs",
    "auto_messages",
    "auto_reactions",
    "auto_responses",
    "auto_nuke",
    "auto_clean",
    "auto_lock",
    "auto_suggestions",
    "auto_suggestions_data",
    "product_repost",
    "vip_plans",
    "vip_config",
    "vip_panel_config",
    "vip_logs",
    "giveaways_data",
    # Boas-vindas / Saídas / Autorole — editados pela dashboard
    "welcome_message",
    "leave_message",
    "auto_role",
    # Convites
    "invites_config",
    "invites_data",
]


class CacheSyncModule(commands.Cog):
    """Sincroniza o cache RAM do bot com o MongoDB periodicamente."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_vip_log_count: int = -1

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.sync_loop.is_running():
            self.sync_loop.start()

    def cog_unload(self):
        self.sync_loop.cancel()

    @tasks.loop(seconds=5)
    async def sync_loop(self):
        """Atualiza todos os documentos externos do cache a cada 5 segundos.
        Inclui refresh dinâmico de docs user_vip_* e emissão de embeds pros
        novos entries em vip_logs gravados pelo backend."""
        for doc_id in SYNCED_DOCUMENTS:
            try:
                await Database.refresh_document(doc_id)
            except Exception as e:
                print(f"[CACHE_SYNC] Erro ao atualizar '{doc_id}': {e}")

        try:
            await self._sync_user_vip_docs()
        except Exception as e:
            print(f"[CACHE_SYNC] Erro ao sincronizar user_vip_*: {e}")

        try:
            await self._emit_new_vip_logs()
        except Exception as e:
            print(f"[CACHE_SYNC] Erro ao emitir logs VIP novos: {e}")

    async def _sync_user_vip_docs(self):
        """Busca IDs de user_vip_* no Mongo e refresca cada doc.
        Garante que ativações/alterações via dashboard apareçam no cache RAM."""
        coll = mongo_db.bot_collection
        if coll is None:
            mongo_db.init_connection()
            coll = mongo_db.bot_collection
        if coll is None:
            return

        try:
            cursor = coll.find({"_id": {"$regex": "^user_vip_"}}, {"_id": 1})
            ids: list[str] = []
            async for doc in cursor:
                _id = doc.get("_id")
                if isinstance(_id, str):
                    ids.append(_id)
        except Exception as e:
            print(f"[CACHE_SYNC] Falha ao listar user_vip_*: {e}")
            return

        for doc_id in ids:
            try:
                await Database.refresh_document(doc_id)
            except Exception as e:
                print(f"[CACHE_SYNC] Erro refresh '{doc_id}': {e}")

    async def _emit_new_vip_logs(self):
        """Detecta novos entries em vip_logs (gravados pelo backend) e emite embeds
        no canal configurado via VipLogger. Usa length delta pra evitar duplicação."""
        from modules.vip.logger import VipLogger
        from modules.vip.manager import VipManager

        raw = Database.get_document("vip_logs") or {}
        if isinstance(raw, list):
            items = raw
        elif isinstance(raw, dict):
            items = raw.get("items") or []
        else:
            items = []

        if not isinstance(items, list):
            return

        current_count = len(items)

        if self._last_vip_log_count < 0:
            self._last_vip_log_count = current_count
            return

        if current_count <= self._last_vip_log_count:
            if current_count < self._last_vip_log_count:
                self._last_vip_log_count = current_count
            return

        new_entries = items[self._last_vip_log_count:]
        self._last_vip_log_count = current_count

        for entry in new_entries:
            if not isinstance(entry, dict):
                continue
            try:
                await self._emit_log_entry(entry, VipLogger, VipManager)
            except Exception as e:
                print(f"[CACHE_SYNC] Falha emitir log VIP '{entry.get('action')}': {e}")

    async def _emit_log_entry(self, entry: dict, VipLogger, VipManager):
        action = entry.get("action") or ""
        user_id_raw = entry.get("discordUserId")
        plan_key = entry.get("planKey")
        plan = VipManager.get_plan(plan_key) if plan_key else None
        plan_name = (plan or {}).get("displayName") or plan_key or "desconhecido"

        user = None
        if user_id_raw:
            try:
                uid = int(user_id_raw)
                user = self.bot.get_user(uid)
                if user is None:
                    try:
                        user = await self.bot.fetch_user(uid)
                    except Exception:
                        user = None
            except (TypeError, ValueError):
                user = None

        if user is None:
            return

        staff = None
        staff_id_raw = entry.get("staffId")
        if staff_id_raw and staff_id_raw != user_id_raw:
            try:
                sid = int(staff_id_raw)
                staff = self.bot.get_user(sid)
            except (TypeError, ValueError):
                staff = None

        if action in ("activated", "changed", "renewed"):
            days = entry.get("days")
            permanent = entry.get("permanent")
            if permanent:
                duration_text = "Permanente"
            elif days:
                duration_text = f"{days} dia(s)"
            else:
                duration_text = "—"
            await VipLogger.activated(self.bot, user, plan_name, duration_text, staff)
            if action == "activated":
                try:
                    await self._send_welcome_dm(user, plan_name, VipManager, entry)
                except Exception as e:
                    print(f"[CACHE_SYNC] Falha welcome DM: {e}")
        elif action == "revoked":
            await VipLogger.revoked(self.bot, user, plan_name, staff)
        elif action == "expired":
            await VipLogger.expired(self.bot, user, plan_name)

    async def _send_welcome_dm(self, user, plan_name: str, VipManager, entry: dict):
        """Envia DM de boas-vindas usando o template configurado em vip_config.welcome_dm."""
        config = VipManager.get_config() or {}
        template = config.get("welcome_dm")
        if not template or not isinstance(template, str) or not template.strip():
            return

        data = VipManager.get_user_vip(user.id) or {}
        from datetime import datetime
        expires_at = data.get("expires_at")
        expires_text = "permanente" if data.get("is_permanent") else (expires_at or "—")
        days_left = "∞"
        if expires_at and not data.get("is_permanent"):
            try:
                dt = datetime.fromisoformat(expires_at)
                delta = dt - datetime.now()
                if delta.total_seconds() > 0:
                    days_left = str(max(1, int(delta.total_seconds() // 86400)))
                else:
                    days_left = "0"
            except Exception:
                pass

        rendered = (
            template
            .replace("{user}", user.mention)
            .replace("{plan}", plan_name)
            .replace("{expires}", expires_text)
            .replace("{days_left}", days_left)
        )

        try:
            await user.send(content=rendered[:2000])
        except Exception as e:
            print(f"[CACHE_SYNC] DM falhou pra {user.id}: {e}")

    @sync_loop.before_loop
    async def before_sync_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(CacheSyncModule(bot))
