"""Entrega de artes e publicação automática no portfólio do servidor."""
from __future__ import annotations

import disnake
from disnake.ext import commands

from functions.art_queue import get_entry_for_ticket, set_status
from functions.database import Database
from functions.permissions import Permissions
from modules.tickets.handlers.team_panel import get_panel_data_for_ticket


FLAGS = disnake.MessageFlags(is_components_v2=True)
ACCENT = disnake.Colour(0x43DBD0)


def _card(title: str, text: str, color=ACCENT):
    return [disnake.ui.Container(
        disnake.ui.TextDisplay(f"# {title}"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(text),
        accent_colour=color,
    )]


def _portfolio_config() -> dict:
    return Database.get_document("kroma_portfolio") or {}


class PortfolioCog(commands.Cog):
    """Comandos que finalizam um pedido de orçamento já pago."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(
        name="entregar_arte",
        description="Entrega a arte do ticket e publica no portfólio configurado.",
        default_member_permissions=disnake.Permissions(manage_guild=True),
    )
    async def entregar_arte(
        self,
        inter: disnake.ApplicationCommandInteraction,
        arquivo: disnake.Attachment,
        descricao: str = "Arte finalizada",
    ):
        if not await Permissions.check_user(inter.user.id):
            return await inter.response.send_message(
                components=_card("ACESSO RESTRITO", "Somente a equipe pode entregar pedidos.", disnake.Colour.red()),
                flags=FLAGS,
                ephemeral=True,
            )

        panel_data, option_data, ticket_info = get_panel_data_for_ticket(inter.channel.id)
        if not ticket_info or str(ticket_info["ticket"].get("option_id")) != "orcamento":
            return await inter.response.send_message(
                components=_card("TICKET INVÁLIDO", "Use este comando dentro de um ticket de **Orçamento** confirmado."),
                flags=FLAGS,
                ephemeral=True,
            )

        entry = get_entry_for_ticket(inter.channel.id)
        if not entry:
            return await inter.response.send_message(
                components=_card("PAGAMENTO PENDENTE", "Não existe um PIX confirmado para este orçamento. Confirme o pagamento antes da entrega."),
                flags=FLAGS,
                ephemeral=True,
            )
        if entry.get("status") == "entregue":
            return await inter.response.send_message(
                components=_card("JÁ ENTREGUE", "Este pedido já foi marcado como entregue."), flags=FLAGS, ephemeral=True
            )

        await inter.response.defer(ephemeral=True)
        description = descricao.strip()[:500] or "Arte finalizada"
        customer_id = int(ticket_info["user_id"])

        # A cópia enviada no ticket é a entrega do cliente. Um arquivo novo é
        # criado para o portfólio porque anexos do Discord não podem ser
        # reutilizados depois de enviados.
        try:
            ticket_file = await arquivo.to_file(use_cached=True)
            await inter.channel.send(
                components=_card("ARTE FINALIZADA", f"{description}\n\nCliente: <@{customer_id}>"),
                file=ticket_file,
                flags=FLAGS,
            )
        except Exception as exc:
            return await inter.followup.send(f"Não consegui enviar o arquivo no ticket: {exc}", ephemeral=True)

        portfolio = _portfolio_config()
        portfolio_channel = self.bot.get_channel(int(portfolio.get("channel_id") or 0))
        published = False
        if isinstance(portfolio_channel, disnake.TextChannel):
            try:
                portfolio_file = await arquivo.to_file(use_cached=True)
                title = portfolio.get("title") or "PORTFÓLIO / KROMA STUDIO"
                await portfolio_channel.send(
                    components=_card(title, f"**{entry.get('service') or 'Arte personalizada'}**\n{description}"),
                    file=portfolio_file,
                    flags=FLAGS,
                    allowed_mentions=disnake.AllowedMentions.none(),
                )
                published = True
            except Exception as exc:
                await inter.followup.send(f"A arte foi entregue, mas não foi possível publicar no portfólio: {exc}", ephemeral=True)

        await set_status(self.bot, inter.channel.id, "entregue", staff_id=inter.user.id, delivery_url=arquivo.url)
        message = "Entrega registrada e removida da fila pública."
        message += " A arte também foi publicada no portfólio." if published else " Configure um canal de portfólio na Central para publicar automaticamente."
        await inter.followup.send(components=_card("ENTREGA CONCLUÍDA", message), flags=FLAGS, ephemeral=True)


def setup(bot: commands.Bot):
    bot.add_cog(PortfolioCog(bot))
