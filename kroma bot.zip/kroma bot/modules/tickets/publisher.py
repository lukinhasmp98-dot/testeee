import disnake
import aiohttp
import io
from disnake.ext import commands
from functions.database import Database


def _schema_has_ticket_action(schema) -> bool:
    """Detecta se o schema do builder já inclui um botão/dropdown de ação de ticket
    (custom_id começando com Ticket_Create ou Ticket_PanelSelect)."""
    if not isinstance(schema, list):
        return False
    def _walk(items):
        for it in items:
            if not isinstance(it, dict):
                continue
            cid = it.get("custom_id")
            if isinstance(cid, str) and (cid.startswith("Ticket_Create") or cid.startswith("Ticket_PanelSelect")):
                return True
            for key in ("components",):
                sub = it.get(key)
                if isinstance(sub, list) and _walk(sub):
                    return True
        return False
    return _walk(schema)


def _inject_ticket_options_into_schema(schema, options, panel_id):
    """Percorre o schema do builder e substitui as options de StringSelects que são
    de ticket pelas opções atuais do painel (mantém UI dinâmica mesmo com snapshot frozen)."""
    if not isinstance(schema, list) or not options:
        return schema
    import copy as _copy
    schema = _copy.deepcopy(schema)
    target_select_cid = f"Ticket_PanelSelect:{panel_id}"
    target_button_prefix = f"Ticket_Create:{panel_id}:"

    def _walk(items):
        for it in items:
            if not isinstance(it, dict):
                continue
            t = it.get("type")
            cid = it.get("custom_id")
            # Substituir options do StringSelect de ticket
            if t == 3 and isinstance(cid, str) and cid.startswith("Ticket_PanelSelect"):
                new_opts = []
                for opt in options[:25]:
                    o_dict = {"label": str(opt.get("name") or "Opção")[:100], "value": str(opt.get("id") or "")}
                    if opt.get("description"):
                        o_dict["description"] = str(opt.get("description"))[:100]
                    if opt.get("emoji"):
                        o_dict["emoji"] = opt.get("emoji")
                    new_opts.append(o_dict)
                if new_opts:
                    it["options"] = new_opts
            for key in ("components",):
                sub = it.get(key)
                if isinstance(sub, list):
                    _walk(sub)
    _walk(schema)
    return schema


class TicketPublisher:

    @staticmethod
    async def sync_panel_message(bot: commands.Bot, panel_id: str):
        # Force refresh para pegar últimas opções/edits do backend (evita usar cache stale)
        config = await Database.refresh_document("tickets_config", force=True) or {}
        panel_data = config.get("panels", {}).get(panel_id)

        if not panel_data:
            return

        message_id = panel_data.get("message_id")
        channel_id = panel_data.get("channel_id")

        if not channel_id:
            return

        try:
            channel = bot.get_channel(int(channel_id))
            if not channel:
                return

            # Primeiro publish: a Central já salvou o painel, mas ainda não
            # existe mensagem para editar. Publica em vez de retornar vazio.
            if not message_id:
                await TicketPublisher.send_panel(bot, panel_id, channel)
                return

            msg = None
            if message_id:
                try:
                    msg = await channel.fetch_message(int(message_id))
                except disnake.NotFound:
                    msg = None

            substituted = TicketPublisher._apply_panel_placeholders(panel_data, channel)
            payload = await TicketPublisher.build_panel_payload(substituted, panel_id, extra_placeholders={"server": channel.guild.name if channel else ""})
            is_v2_style = True

            if msg:
                is_v2_msg = getattr(msg.flags, "is_components_v2", False)

                if is_v2_msg != is_v2_style:
                    try:
                        await msg.delete()
                    except Exception:
                        pass
                    msg = None
                    panel_data["message_id"] = None

            if not msg:
                msg = await channel.send(**payload, flags=disnake.MessageFlags(is_components_v2=True))
                panel_data["message_id"] = str(msg.id)
                Database.save_document("tickets_config", config)
            else:
                payload["content"] = None
                await msg.edit(**payload, flags=disnake.MessageFlags(is_components_v2=True))

        except disnake.NotFound:
            panel_data["message_id"] = None
            Database.save_document("tickets_config", config)
        except disnake.HTTPException:
            pass

    @staticmethod
    def _get_panel_button(panel_data: dict, panel_id: str, disabled: bool = False) -> disnake.ui.Button:
        from functions.utils import Utils
        button_data = panel_data.get("button", {}) or {}
        label = button_data.get("label", "Abrir Ticket")
        style_map = {
            "blurple": disnake.ButtonStyle.blurple,
            "green": disnake.ButtonStyle.green,
            "red": disnake.ButtonStyle.red,
            "grey": disnake.ButtonStyle.grey,
            "gray": disnake.ButtonStyle.grey,
        }
        style = style_map.get(button_data.get("style", "blurple"), disnake.ButtonStyle.blurple)
        emoji_raw = button_data.get("emoji")
        emoji = Utils.safe_get_emoji(emoji_raw) if emoji_raw else None

        kwargs = {
            "label": label,
            "style": style,
            "custom_id": f"Ticket_Create:{panel_id}",
            "disabled": disabled,
        }
        if emoji:
            kwargs["emoji"] = emoji
        return disnake.ui.Button(**kwargs)

    @staticmethod
    async def build_panel_payload(panel_data: dict, panel_id: str, is_preview: bool = False, extra_placeholders: dict | None = None) -> dict:
        from functions.utils import Utils
        from functions.components_v2_renderer import render_components_v2
        get_panel_button = TicketPublisher._get_panel_button

        options = panel_data.get("options", [])

        # Layout: explicit > inferred (legacy panels sem campo)
        layout = panel_data.get("layout")
        if layout not in ("single", "multi"):
            layout = "multi" if len(options) > 0 else "single"
        is_multi = layout == "multi" and len(options) >= 1
        display_mode = (panel_data.get("container") or {}).get("display_mode") or "dropdown"
        use_dropdown = is_multi and display_mode == "dropdown"
        use_buttons = is_multi and display_mode == "buttons"

        style_map = {
            "blurple": disnake.ButtonStyle.blurple,
            "blue": disnake.ButtonStyle.blurple,
            "green": disnake.ButtonStyle.green,
            "red": disnake.ButtonStyle.red,
            "grey": disnake.ButtonStyle.grey,
            "gray": disnake.ButtonStyle.grey,
        }
        panel_btn_style = style_map.get((panel_data.get("button") or {}).get("style", "blurple"), disnake.ButtonStyle.blurple)

        def _build_action_components():
            if use_buttons:
                row_btns = []
                for opt in options:
                    emoji_raw = opt.get("emoji")
                    emoji = Utils.safe_get_emoji(emoji_raw) if emoji_raw else None
                    kw = {"label": opt.get("button") or opt.get("name", "Opção"), "style": panel_btn_style,
                          "custom_id": f"Ticket_Create:{panel_id}:{opt.get('id')}", "disabled": is_preview}
                    if emoji: kw["emoji"] = emoji
                    row_btns.append(disnake.ui.Button(**kw))
                rows = []
                for i in range(0, len(row_btns), 5):
                    rows.append(disnake.ui.ActionRow(*row_btns[i:i+5]))
                return rows
            elif use_dropdown:
                select_options = []
                for opt in options:
                    emoji = Utils.safe_get_emoji(opt.get("emoji")) if opt.get("emoji") else None
                    select_options.append(disnake.SelectOption(label=opt.get("name", "Opção"), value=str(opt.get("id")), description=opt.get("description")))
                return [disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=f"Ticket_PanelSelect:{panel_id}",
                    placeholder="Selecione uma opção para abrir o ticket...",
                    options=select_options, disabled=is_preview))]
            else:
                return [disnake.ui.ActionRow(get_panel_button(panel_data, panel_id, disabled=is_preview))]

        # Modo Builder: se container.components_v2 for array válido, usa direto
        builder_schema = (panel_data.get("container") or {}).get("components_v2")
        if isinstance(builder_schema, list) and len(builder_schema) > 0:
            from datetime import datetime
            now = datetime.now()
            placeholders = {
                "panel": panel_data.get("name", ""),
                "date": now.strftime("%d/%m/%Y"),
                "time": now.strftime("%H:%M"),
                "server": "",
            }
            if extra_placeholders:
                placeholders.update(extra_placeholders)
            # Injeta opções atuais no schema (StringSelect frozen vira dinâmico)
            live_schema = _inject_ticket_options_into_schema(builder_schema, options, panel_id)
            has_ticket_action = _schema_has_ticket_action(live_schema)
            rendered = render_components_v2(live_schema, placeholders)
            # Se o schema do builder NÃO já tem botão/dropdown de ticket,
            # bot anexa um padrão com base em display_mode/layout
            if not has_ticket_action:
                for row in _build_action_components():
                    rendered.append(row)
            return {"components": rendered}

        data = panel_data.get("container", {})
        button_data = panel_data.get("button", {})
        btn_position = button_data.get("position", "below")

        action_components = _build_action_components()

        container_kwargs = {}
        color_hex = data.get("color")
        if color_hex:
            try:
                container_kwargs["accent_colour"] = disnake.Colour(int(color_hex.lstrip("#"), 16))
            except Exception:
                pass

        container_components = []
        files = []

        if data.get("image_url"):
            bw = data.get("banner_width")
            bh = data.get("banner_height")
            if bw or bh:
                from functions.media import ImageHandler
                buf = await ImageHandler.resize_banner(data["image_url"], width=int(bw) if bw else None, height=int(bh) if bh else None)
                if buf:
                    files.append(disnake.File(buf, filename="banner.png"))
                    container_components.append(
                        disnake.ui.MediaGallery(disnake.MediaGalleryItem(media="attachment://banner.png"))
                    )
                else:
                    container_components.append(
                        disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=data["image_url"]))
                    )
            else:
                container_components.append(
                    disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=data["image_url"]))
                )

        # Mantém a mesma escolha de posição usada no modal de aparência.
        banner_component = None
        if data.get("image_url") and data.get("banner_position", "top") == "bottom":
            banner_component = container_components.pop()

        thumb_url = data.get("thumbnail_url")
        content_text = data.get("content")

        if content_text and thumb_url:
            container_components.append(
                disnake.ui.Section(
                    disnake.ui.TextDisplay(content_text),
                    accessory=disnake.ui.Thumbnail(media=thumb_url)
                )
            )
        elif content_text:
            container_components.append(disnake.ui.TextDisplay(content_text))

        if banner_component:
            container_components.append(banner_component)

        # Discord trata StringSelect sempre como top-level: força dropdown pra fora do container
        force_top_level = use_dropdown

        if btn_position == "accessory" and not force_top_level:
            if is_multi:
                container_components.append(disnake.ui.Separator())
                for row in action_components:
                    container_components.append(row)
            else:
                btn = get_panel_button(panel_data, panel_id, disabled=is_preview)
                container_components.append(disnake.ui.Separator())
                container_components.append(
                    disnake.ui.Section(
                        disnake.ui.TextDisplay("-# Clique no botão ao lado"),
                        accessory=btn
                    )
                )
            result = {"components": [disnake.ui.Container(*container_components, **container_kwargs)]}
            if files:
                result["files"] = files
            return result

        elif btn_position == "floating" or force_top_level:
            result_components = [disnake.ui.Container(*container_components, **container_kwargs)]
            if is_multi:
                for row in action_components:
                    result_components.append(row)
            else:
                btn = get_panel_button(panel_data, panel_id, disabled=is_preview)
                result_components.append(
                    disnake.ui.Section(
                        disnake.ui.TextDisplay("-# Clique no botão ao lado"),
                        accessory=btn
                    )
                )
                result_components.append(disnake.ui.Separator())
            result = {"components": result_components}
            if files:
                result["files"] = files
            return result

        else:
            container_components.append(disnake.ui.Separator())
            for row in action_components:
                container_components.append(row)
            result = {"components": [disnake.ui.Container(*container_components, **container_kwargs)]}
            if files:
                result["files"] = files
            return result

    @staticmethod
    def _apply_panel_placeholders(panel_data: dict, channel: disnake.TextChannel | None) -> dict:
        from datetime import datetime
        now = datetime.now()
        replacements = {
            "{server}": channel.guild.name if channel else "",
            "{panel}": panel_data.get("name", ""),
            "{date}": now.strftime("%d/%m/%Y"),
            "{time}": now.strftime("%H:%M"),
        }
        container = panel_data.get("container", {}) or {}
        content = container.get("content")
        if content:
            for k, v in replacements.items():
                content = content.replace(k, str(v))
            new_panel = {**panel_data, "container": {**container, "content": content}}
            return new_panel
        return panel_data

    @staticmethod
    async def send_panel(bot: commands.Bot, panel_id: str, channel: disnake.TextChannel) -> disnake.Message:
        # Force refresh pra pegar últimas opções/edits (evita publicar versão stale do cache)
        config = await Database.refresh_document("tickets_config", force=True) or {}
        panel_data = config.get("panels", {}).get(panel_id)

        if not panel_data:
            raise ValueError("Painel não encontrado")

        substituted = TicketPublisher._apply_panel_placeholders(panel_data, channel)
        payload = await TicketPublisher.build_panel_payload(substituted, panel_id, extra_placeholders={"server": channel.guild.name if channel else ""})
        msg = await channel.send(**payload, flags=disnake.MessageFlags(is_components_v2=True))

        # O runtime da Kroma usa banco JSON local. O caminho legado abaixo
        # (MongoDB) é opcional, portanto o ID precisa ser persistido aqui.
        panel_data["message_id"] = str(msg.id)
        panel_data["channel_id"] = str(channel.id)
        Database.save_document("tickets_config", config)

        # Update cirúrgico de message_id/channel_id (não sobrescreve doc inteiro)
        try:
            from functions.database import get_bot_collection
            coll = get_bot_collection()
            if coll is not None:
                await coll.update_one(
                    {"_id": "tickets_config"},
                    {"$set": {f"panels.{panel_id}.message_id": str(msg.id), f"panels.{panel_id}.channel_id": str(channel.id)}}
                )
        except Exception as e:
            print(f"[send_panel] update message_id falhou: {e}")
        # Refresh cache
        await Database.refresh_document("tickets_config", force=True)

        return msg
