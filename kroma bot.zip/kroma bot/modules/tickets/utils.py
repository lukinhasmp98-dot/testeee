class SafeFormatter(dict):
    def __missing__(self, key):
        return f"{ {key}} "

def format_placeholders(template: str, **kwargs) -> str:
    formatter = SafeFormatter(**kwargs)
    return template.format_map(formatter)

def sanitize_channel_name(name: str, max_length: int = 25) -> str:
    import re
    sanitized = re.sub(r'[^a-z0-9-]', '', name.lower().replace(' ', '-'))
    return sanitized[:max_length] if sanitized else "ticket"


async def safe_defer(inter, ephemeral: bool = True) -> bool:
    try:
        if inter.response.is_done():
            return False
        await inter.response.defer(ephemeral=ephemeral)
        return True
    except Exception:
        return False


async def safe_send(inter, *args, ephemeral: bool = True, **kwargs):
    """Envia mensagem de resposta de forma segura.
    Se a interaction ainda não foi acknowledged, usa response.send_message.
    Se já foi, usa followup.send."""
    try:
        if not inter.response.is_done():
            return await inter.response.send_message(*args, ephemeral=ephemeral, **kwargs)
        return await inter.followup.send(*args, ephemeral=ephemeral, **kwargs)
    except Exception:

        try:
            return await inter.followup.send(*args, ephemeral=ephemeral, **kwargs)
        except Exception:
            return None
