import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import format_placeholders, safe_defer

async def create_call(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)
    ticket = ticket_info.get("ticket", {})

    call_channel_id = ticket.get("call_channel_id")
    if call_channel_id:
        call_channel = inter.guild.get_channel(call_channel_id)
        if call_channel:
            return await inter.followup.send(f"Já existe uma call ativa: {call_channel.mention}", ephemeral=True)

    try:

        category = channel.category if isinstance(channel, disnake.TextChannel) else None

        overwrites = {
            inter.guild.default_role: disnake.PermissionOverwrite(connect=False, view_channel=False),
            inter.guild.me: disnake.PermissionOverwrite(connect=True, view_channel=True, manage_channels=True)
        }

        user_id = ticket_info.get("user_id")
        user = inter.guild.get_member(int(user_id))
        if user:
            overwrites[user] = disnake.PermissionOverwrite(connect=True, view_channel=True)

        roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
        for role_id in roles_data.get("attendant", []):
            role = inter.guild.get_role(int(role_id))
            if role:
                overwrites[role] = disnake.PermissionOverwrite(connect=True, view_channel=True)

        voice_channel = await inter.guild.create_voice_channel(
            name=f"Call - {channel.name}",
            category=category,
            overwrites=overwrites
        )

        tickets_data = Database.get_document("tickets_data") or {}
        panel_id = ticket_info.get("panel_id")

        for t in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
            if t.get("ticket_id") == channel.id:
                t["call_channel_id"] = voice_channel.id
                break

        Database.save_document("tickets_data", tickets_data)

        messages = panel_data.get("messages", {})
        template = messages.get("create_call_message", "Canal de voz criado: {voice_channel}")

        msg = format_placeholders(
            template,
            voice_channel=voice_channel.mention,
            author=inter.author.mention
        )

        await channel.send(msg)
        await inter.followup.send(f"Call criada: {voice_channel.mention}", ephemeral=True)

        try:
            if user:
                dm_msg = messages.get("create_call_dm_message", "Uma call foi criada no seu ticket.")
                button = disnake.ui.Button(label="Ir para o canal", style=disnake.ButtonStyle.link, url=voice_channel.jump_url)
                await user.send(dm_msg, components=[button])
        except Exception:
            pass

    except Exception as e:
        await inter.followup.send(f"Erro ao criar call: {e}", ephemeral=True)

async def delete_call(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)
    ticket = ticket_info.get("ticket", {})

    call_channel_id = ticket.get("call_channel_id")
    if not call_channel_id:
        return await inter.followup.send("Não há call ativa neste ticket.", ephemeral=True)

    call_channel = inter.guild.get_channel(call_channel_id)
    if call_channel:
        try:
            await call_channel.delete()
        except Exception:
            pass

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")
    user_id = ticket_info.get("user_id")

    for t in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if t.get("ticket_id") == channel.id:
            t["call_channel_id"] = None
            break

    Database.save_document("tickets_data", tickets_data)

    await channel.send(f"Status: Call encerrada por {inter.author.mention}")
    await inter.followup.send("Call encerrada!", ephemeral=True)

async def request_call(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])

    mentions = []
    for role_id in attendant_roles:
        role = inter.guild.get_role(int(role_id))
        if role:
            mentions.append(role.mention)

    messages = panel_data.get("messages", {})
    template = messages.get("request_call_message", "{user} está solicitando uma call. {attendants}")

    msg = format_placeholders(
        template,
        user=inter.author.mention,
        attendants=" ".join(mentions) if mentions else ""
    )

    await channel.send(msg)
    await inter.followup.send("Solicitação de call enviada!", ephemeral=True)

def get_call_panel(channel_id: int) -> dict:
    info = get_ticket_info(channel_id)
    ticket = info.get("ticket", {}) if info else {}
    has_call = bool(ticket.get("call_channel_id"))

    color_data = Database.get_document("custom_colors")
    primary_color_hex = color_data.get("primary")

    container_kwargs = {}
    if primary_color_hex:
        pass

    return {
        "components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay("# Gerenciar Call"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(f"**Status:** {'Ativa' if has_call else 'Inativa'}"),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Criar Call" if not has_call else "Encerrar Call",
                        style=disnake.ButtonStyle.green if not has_call else disnake.ButtonStyle.red,
                        custom_id="Ticket_CreateCall" if not has_call else "Ticket_DeleteCall"
                    )
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, custom_id="Ticket_AttendantPanel")
                ),
                **container_kwargs
            )
        ]
    }
