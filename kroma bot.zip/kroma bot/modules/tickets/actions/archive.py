import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import safe_defer
import time

async def archive_ticket(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])
    user_role_ids = [role.id for role in inter.author.roles]
    is_attendant = any(int(rid) in user_role_ids for rid in attendant_roles)

    if not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para arquivar este ticket.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")
    user_id = ticket_info.get("user_id")

    for ticket in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if ticket.get("ticket_id") == channel.id:
            ticket["status"] = "archived"
            ticket["archived_at"] = int(time.time())
            ticket["archived_by"] = inter.author.id
            break

    Database.save_document("tickets_data", tickets_data)

    prefs = panel_data.get("preferences", {})
    archive_category_id = prefs.get("archive_category_id")

    if archive_category_id and isinstance(channel, disnake.TextChannel):
        try:
            archive_category = inter.guild.get_channel(archive_category_id)
            if archive_category and isinstance(archive_category, disnake.CategoryChannel):
                await channel.edit(category=archive_category)
        except Exception:
            pass

    if isinstance(channel, disnake.TextChannel):
        try:

            overwrites = channel.overwrites.copy()
            for target, perms in overwrites.items():
                if target != inter.guild.me:
                    overwrites[target] = disnake.PermissionOverwrite(
                        read_messages=perms.read_messages,
                        send_messages=False
                    )
            await channel.edit(overwrites=overwrites)
        except Exception:
            pass
    elif isinstance(channel, disnake.Thread):
        try:
            await channel.edit(archived=True, locked=True)
        except Exception:
            pass

    await channel.send(f"Status: Ticket arquivado por {inter.author.mention}")
    await inter.followup.send("Ticket arquivado!", ephemeral=True)

async def mark_resolved(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])
    user_role_ids = [role.id for role in inter.author.roles]
    is_attendant = any(int(rid) in user_role_ids for rid in attendant_roles)

    if not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para marcar como resolvido.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")
    user_id = ticket_info.get("user_id")

    for ticket in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if ticket.get("ticket_id") == channel.id:
            ticket["resolved"] = True
            ticket["resolved_at"] = int(time.time())
            ticket["resolved_by"] = inter.author.id
            break

    Database.save_document("tickets_data", tickets_data)

    await channel.send(f"Status: Ticket marcado como **resolvido** por {inter.author.mention}")
    await inter.followup.send("Ticket marcado como resolvido!", ephemeral=True)
