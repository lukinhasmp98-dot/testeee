import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import format_placeholders

async def add_user_to_ticket(inter: disnake.MessageInteraction, user: disnake.Member, is_user_action: bool = False):
    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    if isinstance(channel, disnake.Thread):

        try:
            await channel.add_user(user)

            tickets_data = Database.get_document("tickets_data") or {}
            owner_id = str(info["user_id"])
            panel_id = info["panel_id"]
            for t in tickets_data.get("panels", {}).get(panel_id, {}).get(owner_id, []):
                if t.get("ticket_id") == channel.id:
                    if "permitted_users" not in t: t["permitted_users"] = []
                    if user.id not in t["permitted_users"]:
                        t["permitted_users"].append(user.id)
                    break
            Database.save_document("tickets_data", tickets_data)

        except Exception:
            return await inter.followup.send("Erro ao adicionar usuário à thread.", ephemeral=True)
    else:

        perms = channel.permissions_for(user)
        if perms.read_messages:
            return await inter.followup.send("Este usuário já tem acesso ao ticket.", ephemeral=True)

        try:
            await channel.set_permissions(user, read_messages=True, send_messages=True)
        except Exception:
            return await inter.followup.send("Erro ao adicionar permissões.", ephemeral=True)

    messages = panel_data.get("messages", {})
    template = messages.get("add_user_message", "{added_user} foi adicionado ao ticket por {author}.")

    msg = format_placeholders(
        template,
        added_user=user.mention,
        added_user_name=user.name,
        author=inter.author.mention,
        author_name=inter.author.name,
        channel_name=channel.name
    )

    await channel.send(msg)
    await inter.followup.send(f"{user.mention} adicionado ao ticket!", ephemeral=True)

    try:
        dm_template = messages.get("add_user_dm_message", "Você foi adicionado ao ticket {channel_name}.")
        dm_msg = format_placeholders(
            dm_template,
            channel_name=channel.name,
            guild_name=inter.guild.name,
            added_by=inter.author.name
        )
        button = disnake.ui.Button(label="Ir para o Ticket", style=disnake.ButtonStyle.link, url=channel.jump_url)
        await user.send(dm_msg, components=[button])
    except Exception:
        pass

async def remove_user_from_ticket(inter: disnake.MessageInteraction, user: disnake.Member, is_user_action: bool = False):
    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    if str(user.id) == str(ticket_info.get("user_id")):
        return await inter.followup.send("Não é possível remover o dono do ticket.", ephemeral=True)

    if isinstance(channel, disnake.Thread):
        try:
            await channel.remove_user(user)

            tickets_data = Database.get_document("tickets_data") or {}
            owner_id = str(info["user_id"])
            panel_id = info["panel_id"]
            for t in tickets_data.get("panels", {}).get(panel_id, {}).get(owner_id, []):
                if t.get("ticket_id") == channel.id:
                    if "permitted_users" in t and user.id in t["permitted_users"]:
                        t["permitted_users"].remove(user.id)
                    break
            Database.save_document("tickets_data", tickets_data)

        except Exception:
            return await inter.followup.send("Erro ao remover usuário da thread.", ephemeral=True)
    else:
        try:
            await channel.set_permissions(user, overwrite=None)
        except Exception:
            return await inter.followup.send("Erro ao remover permissões.", ephemeral=True)

    messages = panel_data.get("messages", {})
    template = messages.get("remove_user_message", "{removed_user} foi removido do ticket por {author}.")

    msg = format_placeholders(
        template,
        removed_user=user.mention,
        removed_user_name=user.name,
        author=inter.author.mention,
        author_name=inter.author.name,
        channel_name=channel.name
    )

    await channel.send(msg)
    await inter.followup.send(f"{user.mention} removido do ticket!", ephemeral=True)

    try:
        dm_template = messages.get("remove_user_dm_message", "Você foi removido do ticket {channel_name}.")
        dm_msg = format_placeholders(
            dm_template,
            channel_name=channel.name,
            guild_name=inter.guild.name,
            removed_by=inter.author.name
        )
        await user.send(dm_msg)
    except Exception:
        pass

def get_user_select_panel(action: str) -> dict:
    color_data = Database.get_document("custom_colors")
    primary_color_hex = color_data.get("primary")

    container_kwargs = {}
    if primary_color_hex:
        pass

    title = "Adicionar Usuário" if action == "add" else "Remover Usuário"
    custom_id = f"Ticket_SelectUser:{action}"

    return {
        "components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"# {title}"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("Selecione o usuário:"),
                disnake.ui.ActionRow(
                    disnake.ui.UserSelect(
                        placeholder="Selecione um usuário...",
                        custom_id=custom_id
                    )
                ),
                **container_kwargs
            )
        ]
    }
