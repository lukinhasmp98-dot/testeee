import disnake
import asyncio
import time
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import format_placeholders

async def close_ticket(inter: disnake.MessageInteraction, reason: str = None, is_user: bool = False):

    if not inter.response.is_done():
        try:
            await inter.response.defer(ephemeral=True)
        except Exception:
            pass

    channel = inter.channel
    ticket_info = get_ticket_info(channel.id)

    if not ticket_info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, info = get_panel_data_for_ticket(channel.id)


    is_owner = str(inter.author.id) == str(info.get("user_id"))
    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])
    user_role_ids = [role.id for role in inter.author.roles]
    is_attendant = any(int(rid) in user_role_ids for rid in attendant_roles)

    if not is_owner and not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para fechar este ticket.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = info.get("panel_id")
    user_id = info.get("user_id")

    for ticket in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if ticket.get("ticket_id") == channel.id:
            ticket["status"] = "closed"
            ticket["closed_at"] = int(time.time())
            ticket["closed_by"] = inter.author.id
            ticket["close_reason"] = reason
            break

    Database.save_document("tickets_data", tickets_data)

    # A fila é exclusiva de pedidos com PIX confirmado. Se o atendimento
    # termina, o pedido deixa de ocupar uma posição pública.
    try:
        from functions.art_queue import remove_ticket
        await remove_ticket(inter.bot, channel.id)
    except Exception as exc:
        print(f"[FILA] Erro ao remover ticket fechado: {exc}")

    try:
        user = await inter.guild.fetch_member(int(user_id))
        if user:
            messages = panel_data.get("messages", {})
            if reason:
                template = messages.get("close_message_reason", "Seu ticket foi fechado. Motivo: {reason}")
            else:
                template = messages.get("close_message", "Seu ticket foi fechado.")

            dm_msg = format_placeholders(
                template,
                reason=reason or "",
                channel_name=channel.name,
                guild_name=inter.guild.name,
                attendant=inter.author.name
            )
            await user.send(dm_msg)
    except Exception:
        pass

    prefs = panel_data.get("preferences", {})
    if prefs.get("transcripts", {}).get("send_on_close", False):
        from .transcript import generate_and_send_transcript
        await generate_and_send_transcript(inter, channel, panel_data)

    from functions.tickets import TicketStatsManager
    from ..publisher import TicketPublisher
    TicketStatsManager.add_ticket_closed()

    inter.client.loop.create_task(TicketPublisher.sync_panel_message(inter.bot, panel_id))

    try:
        await channel.delete(reason=f"Ticket fechado por {inter.author}")
    except Exception:
        pass

async def auto_close_ticket(bot: disnake.ext.commands.Bot, channel_id: int, reason: str = "Atendimento concluído pela IA"):

    ticket_info = get_ticket_info(channel_id)
    if not ticket_info:
        return

    panel_data, option_data, info = get_panel_data_for_ticket(channel_id)
    panel_id = info.get("panel_id")
    user_id = info.get("user_id")


    tickets_data = Database.get_document("tickets_data") or {}
    for ticket in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if ticket.get("ticket_id") == channel_id:
            ticket["status"] = "closed"
            ticket["closed_at"] = int(time.time())
            ticket["closed_by"] = bot.user.id
            ticket["close_reason"] = reason
            break
    Database.save_document("tickets_data", tickets_data)

    try:
        from functions.art_queue import remove_ticket
        await remove_ticket(bot, channel_id)
    except Exception as exc:
        print(f"[FILA] Erro ao remover ticket automático: {exc}")

    channel = bot.get_channel(channel_id)
    if not channel:
        return


    try:
        guild = channel.guild
        user = await guild.fetch_member(int(user_id))
        if user:
            messages = panel_data.get("messages", {})
            template = messages.get("close_message_reason", "Seu ticket foi fechado. Motivo: {reason}")
            dm_msg = format_placeholders(
                template,
                reason=reason,
                channel_name=channel.name,
                guild_name=guild.name,
                attendant="IA"
            )
            await user.send(dm_msg)
    except Exception:
        pass


    prefs = panel_data.get("preferences", {})
    transcript_prefs = prefs.get("transcripts", {})
    if transcript_prefs.get("send_on_close", False):
        try:
            from .transcript import generate_transcript
            from datetime import datetime
            transcript_io = await generate_transcript(channel)
            if transcript_io:
                filename = f"transcript-{channel.name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.html"


                log_channel_id = transcript_prefs.get("channel_id")
                if log_channel_id:
                    guild = channel.guild
                    log_channel = guild.get_channel(int(log_channel_id))
                    if log_channel:
                        transcript_io.seek(0)
                        log_file = disnake.File(transcript_io, filename=filename)
                        log_container = disnake.ui.Container(
                            disnake.ui.TextDisplay("# 📑 Histórico de Ticket"),
                            disnake.ui.TextDisplay(f"-# Ticket > Logs > **{channel.name}**"),
                            disnake.ui.Separator(),
                            disnake.ui.TextDisplay("**Resumo do Atendimento**\nTicket finalizado automaticamente pela IA."),
                            disnake.ui.Separator(),
                            disnake.ui.TextDisplay(
                                f"**Usuário:** <@{user_id}>\n"
                                f"**Finalizado por:** IA\n"
                                f"**ID do Canal:** `{channel.id}`"
                            ),
                            disnake.ui.Separator(),
                            disnake.ui.File(f"attachment://{filename}")
                        )
                        await log_channel.send(
                            components=[log_container],
                            files=[log_file],
                            flags=disnake.MessageFlags(is_components_v2=True),
                            allowed_mentions=disnake.AllowedMentions.none()
                        )


                if transcript_prefs.get("send_to_user", False) and user_id:
                    try:
                        guild = channel.guild
                        user_member = await guild.fetch_member(int(user_id))
                        if user_member:
                            dm_transcript = await generate_transcript(channel)
                            if dm_transcript:
                                dm_transcript.seek(0)
                                dm_file = disnake.File(dm_transcript, filename=filename)
                                messages = panel_data.get("messages", {})
                                msg = messages.get("transcript_message", "Aqui está o transcript do seu ticket.")
                                await user_member.send(msg, file=dm_file)
                    except Exception as e:
                        print(f"[AI_AUTO_CLOSE] Erro ao enviar transcript DM: {e}")
        except Exception as e:
            print(f"[AI_AUTO_CLOSE] Erro ao gerar/enviar transcript: {e}")


    from functions.tickets import TicketStatsManager
    from ..publisher import TicketPublisher
    TicketStatsManager.add_ticket_closed()
    bot.loop.create_task(TicketPublisher.sync_panel_message(bot, panel_id))


    close_container = disnake.ui.Container(
        disnake.ui.TextDisplay("### 🔒 Ticket Finalizado\n-# Atendimento encerrado automaticamente pela **IA**"),
    )
    await channel.send(
        components=[close_container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )
    await asyncio.sleep(5)

    try:
        await channel.delete(reason="Ticket fechado automaticamente pela IA")
    except Exception:
        pass
