import disnake
from functions.database import Database
from datetime import datetime
from ..utils import safe_defer

async def show_user_history(inter: disnake.MessageInteraction, user: disnake.Member = None):
    await safe_defer(inter, ephemeral=True)

    target_user = user or inter.author

    tickets_data = Database.get_document("tickets_data") or {}

    user_tickets = []

    for panel_id, users in tickets_data.get("panels", {}).items():
        for user_id, tickets in users.items():
            if str(user_id) == str(target_user.id):
                for ticket in tickets:
                    user_tickets.append({
                        "panel_id": panel_id,
                        **ticket
                    })

    if not user_tickets:
        return await inter.followup.send(f"**{target_user.name}** não tem histórico de tickets.", ephemeral=True)

    user_tickets.sort(key=lambda x: x.get("created_at", 0), reverse=True)

    user_tickets = user_tickets[:10]

    color_data = Database.get_document("custom_colors")
    primary_color_hex = color_data.get("primary")

    container_kwargs = {}
    if primary_color_hex:
        pass

    config = Database.get_document("tickets_config") or {}
    panels = config.get("panels", {})

    history_lines = []
    for ticket in user_tickets:
        panel_name = panels.get(ticket.get("panel_id"), {}).get("name", "Desconhecido")
        status = ticket.get("status", "unknown")
        status_text = {"open": "[Aberto]", "closed": "[Fechado]", "archived": "[Arquivado]"}.get(status, "[?]")

        created_at = ticket.get("created_at")
        date_str = datetime.fromtimestamp(created_at).strftime("%d/%m/%Y") if created_at else "N/A"
        history_lines.append(f"-# {status_text} **{panel_name}** - {date_str}")

    history_text = "\n".join(history_lines)

    panel = {
        "components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"# Histórico de Tickets\n-# {target_user.name}"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(f"**Total:** `{len(user_tickets)}` ticket(s)\n\n{history_text}"),
                **container_kwargs
            )
        ]
    }

    await inter.followup.send(**panel, flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

def get_history_user_select() -> dict:
    color_data = Database.get_document("custom_colors")
    primary_color_hex = color_data.get("primary")

    container_kwargs = {}
    if primary_color_hex:
        pass

    return {
        "components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay("# Histórico de Tickets"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("Selecione um usuário para ver o histórico:"),
                disnake.ui.ActionRow(
                    disnake.ui.UserSelect(
                        placeholder="Selecione um usuário...",
                        custom_id="Ticket_HistoryUserSelect"
                    )
                ),
                **container_kwargs
            )
        ]
    }
