import disnake
import io
from datetime import datetime
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
import chat_exporter

async def generate_transcript(channel: disnake.TextChannel | disnake.Thread, limit: int = None) -> io.BytesIO:
    try:
        transcript = await chat_exporter.export(
            channel,
            limit=limit,
            tz_info="America/Sao_Paulo",
            military_time=False,
            bot=channel.guild.me
        )

        if transcript is None:
            return None

        return io.BytesIO(transcript.encode())
    except Exception as e:
        print(f"[TRANSCRIPT ERROR] Erro ao gerar transcript HTML: {e}")
        return None

async def generate_and_send_transcript(inter: disnake.Interaction, channel: disnake.TextChannel | disnake.Thread, panel_data: dict = None):
    transcript_io = await generate_transcript(channel)

    if not transcript_io:
        return None

    info = get_ticket_info(channel.id)
    user_id = info.get("user_id") if info else None

    filename = f"transcript-{channel.name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.html"

    if panel_data:
        prefs = panel_data.get("preferences", {})
        transcript_prefs = prefs.get("transcripts", {})

        log_channel_id = transcript_prefs.get("channel_id")
        if log_channel_id:
            try:
                log_channel = inter.guild.get_channel(int(log_channel_id)) or await inter.guild.fetch_channel(int(log_channel_id))
                if log_channel:
                    transcript_io.seek(0)

                    log_file = disnake.File(
                        transcript_io,
                        filename=filename
                    )

                    log_container = disnake.ui.Container(
                        disnake.ui.TextDisplay("# 📑 Histórico de Ticket"),
                        disnake.ui.TextDisplay(f"-# Ticket > Logs > **{channel.name}**"),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay("**Resumo do Atendimento**\nTicket finalizado com sucesso."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(
                            f"**Usuário:** <@{user_id}>\n"
                            f"**Finalizado por:** {inter.author.mention}\n"
                            f"**ID do Canal:** `{channel.id}`"
                        ),
                        disnake.ui.Separator(),
                        disnake.ui.File(f"attachment://{filename}")
                    )

                    await log_channel.send(
                        components=[log_container],
                        files=[log_file],
                        flags=disnake.MessageFlags(is_components_v2=True),
                        allowed_mentions=disnake.AllowedMentions.none()
                    )
            except Exception as e:
                print(f"[TICKET LOG ERROR] Erro ao enviar transcript: {e}")

        if transcript_prefs.get("send_to_user", False) and user_id:
            try:
                user = await inter.guild.fetch_member(int(user_id))
                if user:
                    dm_transcript = await generate_transcript(channel)
                    if dm_transcript:
                        dm_transcript.seek(0)
                        dm_file = disnake.File(
                            dm_transcript,
                            filename=filename
                        )

                        messages = panel_data.get("messages", {})
                        msg = messages.get("transcript_message", "Aqui está o transcript do seu ticket.")

                        await user.send(msg, file=dm_file)
            except Exception as e:
                print(f"[TRANSCRIPT DM ERROR] Erro ao enviar transcript para usuário: {e}")

    transcript_io.seek(0)
    return disnake.File(transcript_io, filename=filename)

async def send_transcript_to_user(inter: disnake.MessageInteraction):
    from ..utils import safe_defer
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, _, _ = get_panel_data_for_ticket(channel.id)

    transcript_io = await generate_transcript(channel)

    if not transcript_io:
        return await inter.followup.send("Não há mensagens para gerar o transcript.", ephemeral=True)

    try:
        transcript_io.seek(0)
        filename = f"transcript-{channel.name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.html"

        file = disnake.File(
            transcript_io,
            filename=filename
        )

        messages = panel_data.get("messages", {})
        msg = messages.get("transcript_dm_message", "Aqui está o transcript solicitado.")

        await inter.author.send(msg, file=file)
        await inter.followup.send("Transcript enviado na sua DM!", ephemeral=True)
    except disnake.Forbidden:
        await inter.followup.send("Não foi possível enviar DM. Verifique suas configurações de privacidade.", ephemeral=True)
    except Exception as e:
        await inter.followup.send(f"Erro ao gerar transcript: {e}", ephemeral=True)
