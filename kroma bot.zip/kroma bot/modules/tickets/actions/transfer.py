import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import format_placeholders, safe_defer

async def transfer_ticket(inter: disnake.MessageInteraction, new_owner: disnake.Member, is_user_action: bool = False):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)
    old_owner_id = ticket_info.get("user_id")

    if str(new_owner.id) == str(old_owner_id):
        return await inter.followup.send("O usuário já é o dono deste ticket.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")

    old_tickets = tickets_data.get("panels", {}).get(panel_id, {}).get(str(old_owner_id), [])
    ticket_data = None

    for i, ticket in enumerate(old_tickets):
        if ticket.get("ticket_id") == channel.id:
            ticket_data = old_tickets.pop(i)
            break

    if not ticket_data:
        return await inter.followup.send("Erro ao encontrar dados do ticket.", ephemeral=True)

    ticket_data["user_id"] = new_owner.id
    ticket_data["transferred_from"] = old_owner_id
    ticket_data["transferred_by"] = inter.author.id

    if str(new_owner.id) not in tickets_data["panels"][panel_id]:
        tickets_data["panels"][panel_id][str(new_owner.id)] = []

    tickets_data["panels"][panel_id][str(new_owner.id)].append(ticket_data)
    Database.save_document("tickets_data", tickets_data)

    old_owner = inter.guild.get_member(int(old_owner_id))

    if not isinstance(channel, disnake.Thread):
        try:
            if old_owner:
                await channel.set_permissions(old_owner, overwrite=None)
            await channel.set_permissions(new_owner, read_messages=True, send_messages=True)
        except Exception:
            pass
    else:
        try:
            await channel.add_user(new_owner)
        except Exception:
            pass

    messages = panel_data.get("messages", {})
    template = messages.get("transfer_message", "O ticket foi transferido para {new_owner} por {author}.")

    msg = format_placeholders(
        template,
        new_owner=new_owner.mention,
        new_owner_name=new_owner.name,
        old_owner=old_owner.mention if old_owner else "Usuário anterior",
        author=inter.author.mention,
        author_name=inter.author.name
    )

    await channel.send(msg)
    await inter.followup.send(f"Ticket transferido para {new_owner.mention}!", ephemeral=True)

def get_transfer_panel(is_user: bool = False) -> dict:
    color_data = Database.get_document("custom_colors")
    primary_color_hex = color_data.get("primary")

    container_kwargs = {}
    if primary_color_hex:
        pass

    back_custom_id = "Ticket_UserPanel" if is_user else "Ticket_AttendantPanel"

    return {
        "components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay("# Transferir Ticket"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("Selecione o novo dono do ticket:"),
                disnake.ui.ActionRow(
                    disnake.ui.UserSelect(
                        placeholder="Selecione um usuário...",
                        custom_id="Ticket_TransferSelect"
                    )
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, custom_id=back_custom_id)
                ),
                **container_kwargs
            )
        ]
    }
