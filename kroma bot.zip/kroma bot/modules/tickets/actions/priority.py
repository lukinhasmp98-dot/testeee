import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket

PRIORITIES = {
    "low": {"label": "Baixa", "color": "[L]"},
    "medium": {"label": "Média", "color": "[M]"},
    "high": {"label": "Alta", "color": "[H]"},
    "urgent": {"label": "Urgente", "color": "[U]"},
}

def get_priority_panel(channel_id: int) -> dict:
    info = get_ticket_info(channel_id)
    current_priority = info.get("ticket", {}).get("priority", "medium") if info else "medium"

    color_data = Database.get_document("custom_colors")
    primary_color_hex = color_data.get("primary")

    container_kwargs = {}
    if primary_color_hex:
        pass

    options = []
    for key, data in PRIORITIES.items():
        options.append(
            disnake.SelectOption(label=f"{data['color']} {data['label']}",
                value=key,
                default=key == current_priority)
        )

    return {
        "components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay("# Definir Prioridade"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(f"**Prioridade atual:** {PRIORITIES.get(current_priority, {}).get('label', 'Média')}"),
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        placeholder="Selecione a nova prioridade...",
                        custom_id="Ticket_SetPriority",
                        options=options
                    )
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, custom_id="Ticket_AttendantPanel")
                ),
                **container_kwargs
            )
        ]
    }

async def set_priority(inter: disnake.MessageInteraction, priority: str):
    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])
    user_role_ids = [role.id for role in inter.author.roles]
    is_attendant = any(int(rid) in user_role_ids for rid in attendant_roles)

    if not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para definir prioridade.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")
    user_id = ticket_info.get("user_id")

    for ticket in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if ticket.get("ticket_id") == channel.id:
            ticket["priority"] = priority
            break

    Database.save_document("tickets_data", tickets_data)

    priority_data = PRIORITIES.get(priority, PRIORITIES["medium"])
    await channel.send(f"Prioridade definida como **{priority_data['label']}** por {inter.author.mention}")
    await inter.followup.send("Prioridade atualizada!", ephemeral=True)
