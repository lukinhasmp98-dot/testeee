import disnake
import time
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import format_placeholders, safe_defer

async def notify_user(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)
    ticket = ticket_info.get("ticket", {})
    user_id = ticket_info.get("user_id")

    global_roles = panel_data.get("roles", {}).get("attendant", [])
    category_roles = option_data.get("roles", {}).get("attendant", []) if option_data else []

    all_allowed_role_ids = list(set([int(r) for r in global_roles] + [int(r) for r in category_roles]))
    user_role_ids = [role.id for role in inter.author.roles]

    is_attendant = any(rid in user_role_ids for rid in all_allowed_role_ids)
    if not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para notificar o usuário.", ephemeral=True)

    last_notify = ticket.get("last_notify_user", 0)
    now = int(time.time())
    cooldown = 7200

    if now - last_notify < cooldown:
        remaining = cooldown - (now - last_notify)
        hours = remaining // 3600
        minutes = (remaining % 3600) // 60
        return await inter.followup.send(f"Aguarde mais {hours}h {minutes}m para notificar novamente.", ephemeral=True)

    ticket_owner = inter.guild.get_member(int(user_id))
    if not ticket_owner:
        return await inter.followup.send("Usuário não encontrado no servidor.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")

    found = False
    for t in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if t.get("ticket_id") == channel.id:
            t["last_notify_user"] = now
            found = True
            break

    if found:
        Database.save_document("tickets_data", tickets_data)

    messages = panel_data.get("messages", {})
    template = messages.get("notify_message_staff_to_user", "{user}, você foi notificado por {attendant}.")

    msg = format_placeholders(
        template,
        user=ticket_owner.mention,
        user_name=ticket_owner.name,
        attendant=inter.author.mention,
        attendant_name=inter.author.name,
        channel_name=channel.name
    )

    await channel.send(msg)
    await inter.followup.send("Usuário notificado!", ephemeral=True)

async def notify_attendant(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])

    mentions = []
    for role_id in attendant_roles:
        role = inter.guild.get_role(int(role_id))
        if role:
            mentions.append(role.mention)

    if not mentions:
        return await inter.followup.send("Nenhum cargo de atendente configurado.", ephemeral=True)

    messages = panel_data.get("messages", {})
    template = messages.get("notify_message_user_to_staff", "{attendants}, {user} está solicitando atenção neste ticket.")

    msg = format_placeholders(
        template,
        user=inter.author.mention,
        user_name=inter.author.name,
        attendants=" ".join(mentions),
        channel_name=channel.name
    )

    await channel.send(msg)
    await inter.followup.send("Atendentes notificados!", ephemeral=True)
