import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import sanitize_channel_name, safe_defer

async def rename_ticket(inter: disnake.MessageInteraction, new_name: str):
    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])
    user_role_ids = [role.id for role in inter.author.roles]
    is_attendant = any(int(rid) in user_role_ids for rid in attendant_roles)

    if not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para renomear este ticket.", ephemeral=True)

    sanitized_name = sanitize_channel_name(new_name, max_length=50)

    if not sanitized_name:
        return await inter.followup.send("Nome inválido.", ephemeral=True)

    try:
        await channel.edit(name=sanitized_name)
        await inter.followup.send(f"Ticket renomeado para `{sanitized_name}`.", ephemeral=True)
    except Exception as e:
        await inter.followup.send(f"Erro ao renomear: {e}", ephemeral=True)

class RenameTicketModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Novo nome do ticket",
                custom_id="name",
                placeholder="Digite o novo nome...",
                max_length=50,
                required=True
            )
        ]
        super().__init__(title="Renomear Ticket", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        await safe_defer(inter, ephemeral=True)
        new_name = inter.text_values.get("name", "").strip()
        await rename_ticket(inter, new_name)
