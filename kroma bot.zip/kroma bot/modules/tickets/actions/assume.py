import disnake
from functions.database import Database
from ..handlers.team_panel import get_ticket_info, get_panel_data_for_ticket
from ..utils import format_placeholders, safe_defer

async def assume_ticket(inter: disnake.MessageInteraction):
    await safe_defer(inter, ephemeral=True)

    channel = inter.channel
    info = get_ticket_info(channel.id)

    if not info:
        return await inter.followup.send("Este canal não é um ticket.", ephemeral=True)

    panel_data, option_data, ticket_info = get_panel_data_for_ticket(channel.id)
    ticket = ticket_info.get("ticket", {})

    roles_data = option_data.get("roles", {}) if option_data else panel_data.get("roles", {})
    attendant_roles = roles_data.get("attendant", [])
    user_role_ids = [role.id for role in inter.author.roles]
    is_attendant = any(int(rid) in user_role_ids for rid in attendant_roles)

    if not is_attendant and not inter.author.guild_permissions.administrator:
        return await inter.followup.send("Você não tem permissão para assumir este ticket.", ephemeral=True)

    assumed_by = ticket.get("assumed_by")
    if assumed_by:
        if assumed_by == inter.author.id:
            return await inter.followup.send("Você já assumiu este ticket.", ephemeral=True)
        else:
            member = inter.guild.get_member(assumed_by)
            name = member.display_name if member else "outro atendente"
            return await inter.followup.send(f"Este ticket já foi assumido por **{name}**.", ephemeral=True)

    tickets_data = Database.get_document("tickets_data") or {}
    panel_id = ticket_info.get("panel_id")
    user_id = ticket_info.get("user_id")

    for t in tickets_data.get("panels", {}).get(panel_id, {}).get(str(user_id), []):
        if t.get("ticket_id") == channel.id:
            t["assumed_by"] = inter.author.id
            break

    Database.save_document("tickets_data", tickets_data)

    messages = panel_data.get("messages", {})
    template = messages.get("assume_message", "{attendant} assumiu o atendimento deste ticket.")

    ticket_owner = inter.guild.get_member(int(user_id))

    msg = format_placeholders(
        template,
        attendant=inter.author.mention,
        attendant_name=inter.author.name,
        user=ticket_owner.mention if ticket_owner else "Usuário",
        user_name=ticket_owner.name if ticket_owner else "Usuário",
        channel_name=channel.name
    )

    await channel.send(msg)
    await inter.followup.send("Você assumiu este ticket!", ephemeral=True)

    try:
        if ticket_owner:
            dm_template = messages.get("assume_dm_message", "O atendente {attendant_name} assumiu seu ticket.")
            dm_msg = format_placeholders(
                dm_template,
                attendant=inter.author.mention,
                attendant_name=inter.author.name,
                channel_name=channel.name,
                guild_name=inter.guild.name
            )

            button = disnake.ui.Button(label="Ir para o Ticket", style=disnake.ButtonStyle.link, url=channel.jump_url)
            await ticket_owner.send(dm_msg, components=[button])
    except Exception:
        pass
