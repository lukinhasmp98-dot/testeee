import disnake
from functions.database import Database

TEAM_BUTTONS = {
    "close": {"label": "Fechar Ticket", "custom_id": "Ticket_Close"},
    "assume": {"label": "Assumir Ticket", "custom_id": "Ticket_Assume"},
    "notify": {"label": "Notificar Usuário", "custom_id": "Ticket_Notify"},
    "manage_call": {"label": "Gerenciar Call", "custom_id": "Ticket_ManageCall"},
    "charge_pix": {"label": "Gerar PIX", "custom_id": "Ticket_ChargePix"},
    "start_production": {"label": "Iniciar produção", "custom_id": "Ticket_StartProduction"},
}

STYLE_MAP = {
    "green": disnake.ButtonStyle.green,
    "blue": disnake.ButtonStyle.blurple,
    "grey": disnake.ButtonStyle.grey,
    "red": disnake.ButtonStyle.red,
}

class AttendantSetupView(disnake.ui.View):
    def __init__(self, panel_data: dict, option_data: dict = None):
        super().__init__(timeout=None)

        panel_prefs = panel_data.get("preferences", {}) or {}
        option_prefs = option_data.get("preferences", {}) if option_data else {}

        prefs = {**panel_prefs, **option_prefs}
        team_setup = prefs.get("team_setup", {}) or {}
        disabled_buttons = team_setup.get("disabled_buttons", []) or []

        for key, data in TEAM_BUTTONS.items():
            if key not in disabled_buttons:
                self.add_item(disnake.ui.Button(
                    label=data["label"],
                    style=disnake.ButtonStyle.grey,
                    custom_id=data["custom_id"]
                ))

def _parse_emoji(raw: str):
    if not raw:
        return None
    try:
        return disnake.PartialEmoji.from_str(raw)
    except Exception:
        return raw

async def get_attendant_panel(panel_data: dict = None, option_data: dict = None, ticket_info: dict = None) -> dict:
    prefs = {}
    if panel_data:
        panel_prefs = panel_data.get("preferences", {}) or {}
        option_prefs = option_data.get("preferences", {}) if option_data else {}
        prefs = {**panel_prefs, **option_prefs}

    tc = prefs.get("team_container", {}) or {}

    container_kwargs = {}
    color_hex = tc.get("color")
    if color_hex:
        try:
            container_kwargs["accent_colour"] = disnake.Colour(int(color_hex.lstrip("#"), 16))
        except Exception:
            pass

    team_setup = prefs.get("team_setup", {}) or {}
    disabled_buttons = list(team_setup.get("disabled_buttons", []) or [])

    if ticket_info and ticket_info.get("ticket", {}).get("assumed_by"):
        if "assume" not in disabled_buttons:
            disabled_buttons.append("assume")

    header = tc.get("content") or "-# Painel do Atendente"

    notify_disabled = False
    notify_suffix = ""
    if ticket_info:
        import time
        last_notify = ticket_info.get("ticket", {}).get("last_notify_user", 0)
        now = int(time.time())
        if now - last_notify < 7200:
            notify_disabled = True
            remaining = 7200 - (now - last_notify)
            hours = remaining // 3600
            minutes = (remaining % 3600) // 60
            notify_suffix = f" ({hours}h {minutes}m)"

    all_options = [
        ("close", "Fechar Ticket", "Ticket_Close"),
        ("assume", "Assumir Ticket", "Ticket_Assume"),
        ("notify", f"Notificar Usuário{notify_suffix}", "Ticket_Notify"),
        ("manage_call", "Gerenciar Call", "Ticket_ManageCall"),
        ("charge_pix", "Gerar PIX para este pedido", "Ticket_ChargePix"),
        ("start_production", "Iniciar produção", "Ticket_StartProduction"),
    ]

    button_overrides = tc.get("button_overrides", {}) or {}
    display_mode = tc.get("display_mode", "dropdown") or "dropdown"

    enabled_options = []
    for key, label, custom_id in all_options:
        if key in disabled_buttons:
            continue
        if key == "notify" and notify_disabled:
            continue
        ov = button_overrides.get(key, {}) or {}
        final_label = ov.get("label") or label
        final_emoji = _parse_emoji(ov.get("emoji", ""))
        final_style = STYLE_MAP.get(ov.get("style", ""), disnake.ButtonStyle.grey)
        enabled_options.append((key, final_label, custom_id, final_emoji, final_style))

    container_components = []

    files = []
    if tc.get("image_url"):
        bw = tc.get("banner_width")
        bh = tc.get("banner_height")
        if bw or bh:
            from functions.media import ImageHandler
            buf = await ImageHandler.resize_banner(tc["image_url"], width=int(bw) if bw else None, height=int(bh) if bh else None)
            if buf:
                files.append(disnake.File(buf, filename="team_banner.png"))
                container_components.append(
                    disnake.ui.MediaGallery(disnake.MediaGalleryItem(media="attachment://team_banner.png"))
                )
            else:
                container_components.append(
                    disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=tc["image_url"]))
                )
        else:
            container_components.append(
                disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=tc["image_url"]))
            )

    thumb_url = tc.get("thumbnail_url")
    if header and thumb_url:
        container_components.append(
            disnake.ui.Section(
                disnake.ui.TextDisplay(header),
                accessory=disnake.ui.Thumbnail(media=thumb_url)
            )
        )
    elif header:
        container_components.append(disnake.ui.TextDisplay(header))

    container_components.append(disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small))

    if not enabled_options:
        container_components.append(
            disnake.ui.TextDisplay("Nenhuma ação habilitada para este painel.")
        )
    elif display_mode == "buttons":
        # O Discord aceita no máximo cinco botões por ActionRow.
        for offset in range(0, len(enabled_options), 5):
            row = disnake.ui.ActionRow()
            for key, label, custom_id, emoji, style in enabled_options[offset:offset + 5]:
                btn_kwargs = {"label": label, "custom_id": custom_id, "style": style}
                if emoji:
                    btn_kwargs["emoji"] = emoji
                row.append_item(disnake.ui.Button(**btn_kwargs))
            container_components.append(row)
    else:
        select_options = []
        for key, label, custom_id, emoji, style in enabled_options:
            opt = disnake.SelectOption(label=label, value=custom_id)
            if emoji:
                opt.emoji = emoji
            select_options.append(opt)
        container_components.append(
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    custom_id="Ticket_TeamAction",
                    placeholder="Selecione uma ação...",
                    options=select_options
                )
            )
        )

    result = {
        "components": [
            disnake.ui.Container(*container_components, **container_kwargs)
        ]
    }
    if files:
        result["files"] = files
    return result

def get_ticket_info(channel_id: int) -> dict | None:
    tickets_data = Database.get_document("tickets_data") or {}

    for panel_id, users in tickets_data.get("panels", {}).items():
        for user_id, tickets in users.items():
            for ticket in tickets:
                if ticket.get("ticket_id") == channel_id:
                    return {
                        "panel_id": panel_id,
                        "user_id": user_id,
                        "ticket": ticket
                    }

    return None

def get_panel_data_for_ticket(channel_id: int) -> tuple[dict, dict, dict]:
    ticket_info = get_ticket_info(channel_id)

    if not ticket_info:
        return {}, {}, {}

    config = Database.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(ticket_info["panel_id"], {})

    option_data = {}
    option_id = ticket_info["ticket"].get("option_id")
    if option_id:
        option_data = next(
            (o for o in panel_data.get("options", []) if str(o.get("id")) == str(option_id)),
            {}
        )

    return panel_data, option_data, ticket_info
