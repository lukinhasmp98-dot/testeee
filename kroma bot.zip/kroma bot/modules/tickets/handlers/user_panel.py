import disnake
from functions.database import Database

MEMBER_BUTTONS = {
    "close": {"label": "Fechar Ticket", "custom_id": "Ticket_CloseUser", "row": 0},
    "notify": {"label": "Notificar Atendente", "custom_id": "Ticket_NotifyUser", "row": 0},
    "request_call": {"label": "Solicitar Call", "custom_id": "Ticket_RequestCall", "row": 0},
}

STYLE_MAP = {
    "green": disnake.ButtonStyle.green,
    "blue": disnake.ButtonStyle.blurple,
    "grey": disnake.ButtonStyle.grey,
    "red": disnake.ButtonStyle.red,
}

class UserSetupView(disnake.ui.View):
    def __init__(self, panel_data: dict, option_data: dict = None):
        super().__init__(timeout=None)

        panel_prefs = panel_data.get("preferences", {}) or {}
        option_prefs = option_data.get("preferences", {}) if option_data else {}

        prefs = {**panel_prefs, **option_prefs}
        member_setup = prefs.get("member_setup", {}) or {}
        disabled_buttons = member_setup.get("disabled_buttons", []) or []

        for key, data in MEMBER_BUTTONS.items():
            if key not in disabled_buttons:
                self.add_item(disnake.ui.Button(
                    label=data["label"],
                    style=disnake.ButtonStyle.grey,
                    custom_id=data["custom_id"],
                    row=data.get("row", 0)
                ))

def _parse_emoji(raw: str):
    if not raw:
        return None
    try:
        return disnake.PartialEmoji.from_str(raw)
    except Exception:
        return raw

async def get_user_panel(panel_data: dict = None, option_data: dict = None) -> dict:
    prefs = {}
    if panel_data:
        panel_prefs = panel_data.get("preferences", {}) or {}
        option_prefs = option_data.get("preferences", {}) if option_data else {}
        prefs = {**panel_prefs, **option_prefs}

    mc = prefs.get("member_container", {}) or {}

    container_kwargs = {}
    color_hex = mc.get("color")
    if color_hex:
        try:
            container_kwargs["accent_colour"] = disnake.Colour(int(color_hex.lstrip("#"), 16))
        except Exception:
            pass

    member_setup = prefs.get("member_setup", {}) or {}
    disabled_buttons = member_setup.get("disabled_buttons", []) or []

    header = mc.get("content") or "-# Painel do Usuário"

    all_options = [
        ("close", "Fechar Ticket", "Ticket_CloseUser"),
        ("notify", "Notificar Atendente", "Ticket_NotifyUser"),
        ("request_call", "Solicitar Call", "Ticket_RequestCall"),
    ]

    button_overrides = mc.get("button_overrides", {}) or {}
    display_mode = mc.get("display_mode", "dropdown") or "dropdown"

    enabled_options = []
    for key, label, custom_id in all_options:
        if key in disabled_buttons:
            continue
        ov = button_overrides.get(key, {}) or {}
        final_label = ov.get("label") or label
        final_emoji = _parse_emoji(ov.get("emoji", ""))
        final_style = STYLE_MAP.get(ov.get("style", ""), disnake.ButtonStyle.grey)
        enabled_options.append((key, final_label, custom_id, final_emoji, final_style))

    container_components = []
    files = []

    if mc.get("image_url"):
        bw = mc.get("banner_width")
        bh = mc.get("banner_height")
        if bw or bh:
            from functions.media import ImageHandler
            buf = await ImageHandler.resize_banner(mc["image_url"], width=int(bw) if bw else None, height=int(bh) if bh else None)
            if buf:
                files.append(disnake.File(buf, filename="user_banner.png"))
                container_components.append(
                    disnake.ui.MediaGallery(disnake.MediaGalleryItem(media="attachment://user_banner.png"))
                )
            else:
                container_components.append(
                    disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=mc["image_url"]))
                )
        else:
            container_components.append(
                disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=mc["image_url"]))
            )

    thumb_url = mc.get("thumbnail_url")
    if header and thumb_url:
        container_components.append(
            disnake.ui.Section(
                disnake.ui.TextDisplay(header),
                accessory=disnake.ui.Thumbnail(media=thumb_url)
            )
        )
    elif header:
        container_components.append(disnake.ui.TextDisplay(header))

    container_components.append(disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small))

    if not enabled_options:
        container_components.append(
            disnake.ui.TextDisplay("Nenhuma ação habilitada para este painel.")
        )
    elif display_mode == "buttons":
        row = disnake.ui.ActionRow()
        for key, label, custom_id, emoji, style in enabled_options:
            btn_kwargs = {"label": label, "custom_id": custom_id, "style": style}
            if emoji:
                btn_kwargs["emoji"] = emoji
            row.append_item(disnake.ui.Button(**btn_kwargs))
        container_components.append(row)
    else:
        select_options = []
        for key, label, custom_id, emoji, style in enabled_options:
            opt = disnake.SelectOption(label=label, value=custom_id)
            if emoji:
                opt.emoji = emoji
            select_options.append(opt)
        container_components.append(
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    custom_id="Ticket_UserAction",
                    placeholder="Selecione uma ação...",
                    options=select_options
                )
            )
        )

    result = {
        "components": [
            disnake.ui.Container(*container_components, **container_kwargs)
        ]
    }
    if files:
        result["files"] = files
    return result
