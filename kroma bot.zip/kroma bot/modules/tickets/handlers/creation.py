import disnake
from disnake.ext import commands
from functions.database import Database
from ..utils import format_placeholders, sanitize_channel_name, safe_defer
import time

def get_attendant_role_ids(panel_data: dict, option_data: dict = None) -> list:
    roles_data = (option_data.get("roles") if option_data else None) or panel_data.get("roles", {})
    attendant_ids = roles_data.get("attendant", [])
    if attendant_ids:
        return attendant_ids

    cargos = Database.get_document("cargos") or {}
    suporte_id = cargos.get("cargo_suporte")
    if suporte_id:
        return [str(suporte_id)]
    return []

async def check_existing_ticket(bot: commands.Bot, user_id: int, panel_id: str) -> tuple[bool, str]:
    tickets_data = Database.get_document("tickets_data") or {}
    panels = tickets_data.get("panels", {})

    user_tickets = panels.get(panel_id, {}).get(str(user_id), [])

    for ticket in user_tickets:
        if ticket.get("status") == "open":
            channel_id = ticket.get("ticket_id")
            try:
                channel = bot.get_channel(channel_id)
                if not channel:
                    channel = await bot.fetch_channel(int(channel_id))
                if channel:
                    return False, f"Você já tem um ticket aberto: {channel.mention}"
            except Exception:
                pass

    return True, ""

async def check_permissions(user: disnake.Member, panel_data: dict, option_data: dict = None) -> tuple[bool, str]:
    roles_data = (option_data.get("roles") if option_data else None) or panel_data.get("roles", {})
    forbidden_roles = roles_data.get("forbidden", [])

    user_role_ids = [role.id for role in user.roles]

    for role_id in forbidden_roles:
        if int(role_id) in user_role_ids:
            return False, "Você não tem permissão para abrir tickets neste painel."

    return True, ""

async def check_office_hours(panel_data: dict) -> tuple[bool, str]:
    hours = panel_data.get("office_hours", {})

    if not hours.get("enabled", False):
        return True, ""

    start_time = hours.get("start_time", "09:00")
    end_time = hours.get("end_time", "18:00")
    timezone_str = "America/Sao_Paulo"
    closed_message = hours.get("closed_message", "Estamos fora do horário de atendimento. Por favor, aguarde nosso retorno.")

    try:
        from datetime import datetime
        try:
            import zoneinfo
            tz = zoneinfo.ZoneInfo(timezone_str)
        except Exception:
            # Windows frequentemente não possui a base IANA do zoneinfo.
            # pytz já faz parte das dependências do bot e mantém o fuso
            # America/Sao_Paulo correto, incluindo regras históricas.
            import pytz
            tz = pytz.timezone(timezone_str)
        now = datetime.now(tz)
        current_time = now.strftime("%H:%M")

        # Segunda=0 até domingo=6. Painéis antigos sem "days" seguem
        # compatíveis e continuam usando somente a faixa de horário.
        days = hours.get("days")
        if days is not None and now.weekday() not in {int(day) for day in days}:
            return False, f"{closed_message} Hoje não há atendimento."

        start_h, start_m = map(int, start_time.split(":"))
        end_h, end_m = map(int, end_time.split(":"))
        curr_h, curr_m = map(int, current_time.split(":"))

        start_minutes = start_h * 60 + start_m
        end_minutes = end_h * 60 + end_m
        curr_minutes = curr_h * 60 + curr_m

        if start_minutes <= end_minutes:
            is_open = start_minutes <= curr_minutes <= end_minutes
        else:
            is_open = curr_minutes >= start_minutes or curr_minutes <= end_minutes

        if not is_open:
            return False, f"{closed_message} Atendimento: `{start_time} - {end_time}` (<t:{int(now.timestamp())}:t>)"

    except Exception as e:
        print(f"Erro ao verificar horário de atendimento: {e}")
        return False, "Não foi possível verificar o horário de atendimento. Tente novamente em alguns minutos."

    return True, ""

async def create_ticket(
    inter: disnake.Interaction,
    bot: commands.Bot,
    panel_id: str,
    option_data: dict = None,
    form_answers: dict = None
) -> disnake.TextChannel | disnake.Thread:


    config = await Database.refresh_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id)

    if not panel_data:
        raise ValueError("Painel não encontrado.")

    user = inter.author
    mode = panel_data.get("mode", "channel")

    name_template = option_data.get("name", panel_data.get("name", "Suporte")) if option_data else panel_data.get("name", "Suporte")

    ticket_name = format_placeholders(
        name_template,
        user=user.name,
        user_id=str(user.id),
        option=option_data.get("name", "") if option_data else ""
    )
    ticket_name = sanitize_channel_name(f"{ticket_name}-{user.name}")
    if not ticket_name or ticket_name == "ticket":
        ticket_name = sanitize_channel_name(f"suporte-{user.name}")

    new_channel = None

    if mode == "topic":

        channel_id = panel_data.get("channel_id")
        if not channel_id:
            raise ValueError("Canal para criação de tópicos não configurado.")
        channel = bot.get_channel(int(channel_id))

        if not channel or not isinstance(channel, disnake.TextChannel):
            raise ValueError("Canal para criação de tópicos não encontrado.")

        category_name = option_data.get("name", panel_data.get("name", "Suporte")) if option_data else panel_data.get("name", "Suporte")
        thread_name = f"{category_name} — {user.name}"

        new_channel = await channel.create_thread(
            name=thread_name,
            type=disnake.ChannelType.private_thread,
            invitable=False
        )

    else:

        category_id = panel_data.get("category_id")
        if not category_id:
            raise ValueError("Categoria para criação de tickets não configurada.")
        category = bot.get_channel(int(category_id))

        if not category or not isinstance(category, disnake.CategoryChannel):
            raise ValueError("Categoria para criação de tickets não encontrada.")

        overwrites = {
            inter.guild.default_role: disnake.PermissionOverwrite(read_messages=False),
            user: disnake.PermissionOverwrite(read_messages=True, send_messages=True),
            inter.guild.me: disnake.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
        }

        attendant_ids = get_attendant_role_ids(panel_data, option_data)
        for role_id in attendant_ids:
            try:
                role = inter.guild.get_role(int(role_id))
                if role:
                    overwrites[role] = disnake.PermissionOverwrite(read_messages=True, send_messages=True)
            except Exception:
                pass

        new_channel = await category.create_text_channel(
            name=ticket_name,
            overwrites=overwrites
        )

    tickets_data = Database.get_document("tickets_data") or {}
    if "panels" not in tickets_data:
        tickets_data["panels"] = {}
    if panel_id not in tickets_data["panels"]:
        tickets_data["panels"][panel_id] = {}
    if str(user.id) not in tickets_data["panels"][panel_id]:
        tickets_data["panels"][panel_id][str(user.id)] = []

    ticket_info = {
        "ticket_id": new_channel.id,
        "user_id": user.id,
        "panel_id": panel_id,
        "option_id": option_data.get("id") if option_data else None,
        "status": "open",
        "created_at": int(time.time()),
        "form_answers": form_answers,
        "permitted_users": []
    }

    tickets_data["panels"][panel_id][str(user.id)].append(ticket_info)
    Database.save_document("tickets_data", tickets_data)

    from functions.tickets import TicketStatsManager
    from ..publisher import TicketPublisher
    TicketStatsManager.add_ticket_created()

    inter.client.loop.create_task(TicketPublisher.sync_panel_message(bot, panel_id))

    roles_data = (option_data.get("roles") if option_data else None) or panel_data.get("roles", {})


    protected_ids = set(str(rid) for rid in get_attendant_role_ids(panel_data, option_data))

    for role_id in roles_data.get("add", []):
        try:
            role = inter.guild.get_role(int(role_id))
            if role and role not in user.roles:
                await user.add_roles(role, reason="Ticket aberto")
        except Exception:
            pass

    for role_id in roles_data.get("remove", []):
        if str(role_id) in protected_ids:
            continue
        try:
            role = inter.guild.get_role(int(role_id))
            if role and role in user.roles:
                await user.remove_roles(role, reason="Ticket aberto")
        except Exception:
            pass

    await send_opening_message(new_channel, user, panel_data, option_data, form_answers)

    return new_channel

async def send_opening_message(
    channel: disnake.TextChannel | disnake.Thread,
    user: disnake.Member,
    panel_data: dict,
    option_data: dict = None,
    form_answers: dict = None
):
    open_message = option_data.get("open_message", {}) if option_data else panel_data.get("open_message", {})
    style = open_message.get("style", "container")

    attendant_role_ids = get_attendant_role_ids(panel_data, option_data)

    mention_str = user.mention
    for r_id in attendant_role_ids:
        try:
            role = channel.guild.get_role(int(r_id))
            if role:
                mention_str += f" {role.mention}"
        except Exception:
            pass


    if isinstance(channel, disnake.Thread):
        await channel.send(mention_str)
    else:
        await channel.send(mention_str, delete_after=1)

    form_container = None
    if form_answers:
        questions = option_data.get("form", {}).get("questions", []) if option_data else panel_data.get("form", {}).get("questions", [])
        question_map = {q.get("id"): q.get("label") for q in questions}

        valid_answers = []
        for qid, answer in form_answers.items():
            if answer and answer.strip():
                label = question_map.get(qid, "Informação")
                valid_answers.append(f"### {label}\n-# *{answer.strip()}*")

        if valid_answers:
            form_content = "\n\n".join(valid_answers)
            form_container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"## Dados do Formulário\n{form_content}"),

            )

    def get_style(s):
        return {
            "green": disnake.ButtonStyle.success,
            "blue": disnake.ButtonStyle.primary,
            "blurple": disnake.ButtonStyle.primary,
            "red": disnake.ButtonStyle.danger,
            "grey": disnake.ButtonStyle.secondary,
            "gray": disnake.ButtonStyle.secondary,
            "link": disnake.ButtonStyle.link,
        }.get(s, disnake.ButtonStyle.secondary)

    ACTION_TO_CUSTOM_ID = {
        "close": "Ticket_Close",
        "notify": "Ticket_Notify",
        "transfer": "Ticket_Transfer",
        "priority": "Ticket_Priority",
        "archive": "Ticket_Archive",
        "rename": "Ticket_Rename",
        "history": "Ticket_History",
        "transcript": "Ticket_Transcript",
        "assume": "Ticket_Assume",
        "request_call": "Ticket_RequestCall",
    }

    custom_buttons = open_message.get("buttons") or []

    container_files = []

    from datetime import datetime as _dt
    _now = _dt.now()
    _ph = {
        "user": user.mention,
        "user.name": user.display_name,
        "user.id": str(user.id),
        "ticket": channel.mention,
        "panel": panel_data.get("name", ""),
        "option": (option_data or {}).get("name", "") if option_data else "",
        "server": channel.guild.name,
        "date": _now.strftime("%d/%m/%Y"),
        "time": _now.strftime("%H:%M"),
    }

    # Modo Builder: se open_message.container.components_v2 for array válido, renderiza direto
    builder_schema = ((open_message.get("container") or {}).get("components_v2"))
    if isinstance(builder_schema, list) and len(builder_schema) > 0 and style != "none":
        from functions.components_v2_renderer import render_components_v2
        rendered = render_components_v2(builder_schema, _ph)
        components_to_send = rendered
        if form_container:
            components_to_send.append(form_container)
        await channel.send(components=components_to_send, flags=disnake.MessageFlags(is_components_v2=True))

        # Botões customizados (se houver)
        if custom_buttons:
            from functions.utils import Utils
            ACTION_TO_CUSTOM_ID_BLD = {
                "close": "Ticket_Close", "notify": "Ticket_Notify", "transfer": "Ticket_Transfer",
                "priority": "Ticket_Priority", "archive": "Ticket_Archive", "rename": "Ticket_Rename",
                "history": "Ticket_History", "transcript": "Ticket_Transcript", "assume": "Ticket_Assume",
                "request_call": "Ticket_RequestCall",
            }
            def _bld_style(s):
                return {"green": disnake.ButtonStyle.success, "blue": disnake.ButtonStyle.primary,
                        "red": disnake.ButtonStyle.danger, "grey": disnake.ButtonStyle.secondary,
                        "link": disnake.ButtonStyle.link}.get(s, disnake.ButtonStyle.secondary)
            row_btns = []
            for b in custom_buttons:
                emoji_raw = b.get("emoji")
                emoji = Utils.safe_get_emoji(emoji_raw) if emoji_raw else None
                kw = {"label": (b.get("label") or "").format_map({}) or None, "style": _bld_style(b.get("style", "grey"))}
                if emoji: kw["emoji"] = emoji
                if b.get("style") == "link":
                    if not b.get("url"): continue
                    kw["url"] = b.get("url")
                else:
                    if b.get("action") not in ACTION_TO_CUSTOM_ID_BLD: continue
                    kw["custom_id"] = ACTION_TO_CUSTOM_ID_BLD[b.get("action")]
                row_btns.append(disnake.ui.Button(**kw))
            for i in range(0, len(row_btns), 5):
                await channel.send(components=[disnake.ui.ActionRow(*row_btns[i:i+5])])
        return
    def _sub(text: str) -> str:
        if not text:
            return text
        out = text
        for k, v in _ph.items():
            out = out.replace("{" + k + "}", str(v))
        return out

    if style == "none":
        if form_container:
            await channel.send(components=[form_container], flags=disnake.MessageFlags(is_components_v2=True))
    else:
        from functions.utils import Utils

        data = open_message.get("container", {}) or {}
        container_kwargs = {}

        color_hex = data.get("color")
        if color_hex:
            try:
                container_kwargs["accent_colour"] = disnake.Colour(int(color_hex.lstrip("#"), 16))
            except Exception:
                pass

        container_children = []

        image_url = data.get("image_url") or panel_data.get("open_message_image", "")
        banner_component = disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=image_url)) if image_url else None
        if banner_component and data.get("banner_position", "top") == "top":
            container_children.append(banner_component)

        raw_content = data.get("content") or open_message.get("content") or open_message.get("title") or "Seu ticket foi aberto!"
        content = _sub(raw_content)
        thumb_url = data.get("thumbnail_url")

        if content and thumb_url:
            container_children.append(
                disnake.ui.Section(
                    disnake.ui.TextDisplay(content),
                    accessory=disnake.ui.Thumbnail(media=thumb_url)
                )
            )
        elif content:
            container_children.append(disnake.ui.TextDisplay(content))

        if banner_component and data.get("banner_position", "top") == "bottom":
            container_children.append(banner_component)

        display_mode = open_message.get("display_mode") or "buttons"

        if custom_buttons and display_mode == "buttons":
            non_link = [b for b in custom_buttons if b.get("style") != "link" and b.get("action") in ACTION_TO_CUSTOM_ID]
            link_btns = [b for b in custom_buttons if b.get("style") == "link" and b.get("url")]

            row_btns = []
            for b in (non_link + link_btns):
                emoji_raw = b.get("emoji")
                emoji = Utils.safe_get_emoji(emoji_raw) if emoji_raw else None
                kwargs = {
                    "label": _sub(b.get("label")) or None,
                    "style": get_style(b.get("style", "grey")),
                }
                if emoji:
                    kwargs["emoji"] = emoji
                if b.get("style") == "link":
                    kwargs["url"] = b.get("url")
                else:
                    kwargs["custom_id"] = ACTION_TO_CUSTOM_ID[b.get("action")]
                row_btns.append(disnake.ui.Button(**kwargs))

            for i in range(0, len(row_btns), 5):
                container_children.append(disnake.ui.Separator())
                container_children.append(disnake.ui.ActionRow(*row_btns[i:i+5]))
        elif custom_buttons and display_mode == "dropdown":
            select_options = []
            for b in custom_buttons:
                if b.get("style") == "link" or b.get("action") not in ACTION_TO_CUSTOM_ID:
                    continue
                emoji_raw = b.get("emoji")
                emoji = Utils.safe_get_emoji(emoji_raw) if emoji_raw else None
                opt_kwargs = {
                    "label": (_sub(b.get("label")) or "Ação")[:100],
                    "value": ACTION_TO_CUSTOM_ID[b.get("action")],
                }
                if emoji:
                    opt_kwargs["emoji"] = emoji
                select_options.append(disnake.SelectOption(**opt_kwargs))
            if select_options:
                container_children.append(disnake.ui.Separator())
                container_children.append(disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id="Ticket_TeamAction",
                        placeholder="Selecione uma ação...",
                        options=select_options,
                    )
                ))

        container = disnake.ui.Container(*container_children, **container_kwargs)
        components = [container]
        if form_container:
            components.append(form_container)

        send_kwargs = {"components": components, "flags": disnake.MessageFlags(is_components_v2=True)}
        if container_files:
            send_kwargs["files"] = container_files
        await channel.send(**send_kwargs)

    if not custom_buttons:
        controls = (option_data or panel_data).get("control_buttons", {})
        legacy_buttons = []
        legacy_configs = [
            ("attendant", "Ticket_AttendantPanel", {"label": "Painel do Atendente", "emoji": "", "style": "grey"}),
            ("user", "Ticket_UserPanel", {"label": "Painel do Usuário", "emoji": "", "style": "grey"}),
            ("info", "Ticket_Info", {"label": "", "emoji": "", "style": "grey"})
        ]
        for key, custom_id, default in legacy_configs:
            btn_data = controls.get(key, default)
            label = btn_data.get("label")
            emoji = btn_data.get("emoji")
            if label or emoji:
                legacy_buttons.append(
                    disnake.ui.Button(
                        label=label if label else None,
                        emoji=emoji if emoji else None,
                        style=get_style(btn_data.get("style")),
                        custom_id=custom_id
                    )
                )
        if legacy_buttons:
            await channel.send(components=[disnake.ui.ActionRow(*legacy_buttons)])

class TicketFormModal(disnake.ui.Modal):
    def __init__(self, bot: commands.Bot, panel_id: str, option_data: dict, questions: list):
        self.bot = bot
        self.panel_id = panel_id
        self.option_data = option_data
        self.questions = questions

        components = []
        for q in questions:
            style = disnake.TextInputStyle.paragraph if q.get("style") == "paragraph" else disnake.TextInputStyle.short
            components.append(
                disnake.ui.TextInput(
                    label=q.get("label", "Pergunta")[:45],
                    custom_id=q.get("id"),
                    style=style,
                    placeholder=q.get("placeholder", ""),
                    required=q.get("required", True),
                    max_length=500
                )
            )

        super().__init__(title="Abrir Ticket", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        await safe_defer(inter, ephemeral=True)

        form_answers = {q.get("id"): inter.text_values.get(q.get("id"), "") for q in self.questions}

        config = Database.get_document("tickets_config") or {}
        panel_data = config.get("panels", {}).get(self.panel_id)

        try:
            ok, error = await check_office_hours(panel_data)
            if not ok:
                return await inter.followup.send(error, ephemeral=True)
            
            ok, error = await check_existing_ticket(self.bot, inter.author.id, self.panel_id)
            if not ok:
                return await inter.followup.send(error, ephemeral=True)

            ok, error = await check_permissions(inter.author, panel_data, self.option_data)
            if not ok:
                return await inter.followup.send(error, ephemeral=True)

            channel = await create_ticket(inter, self.bot, self.panel_id, self.option_data, form_answers)

            await inter.followup.send(f"Seu ticket foi criado: {channel.mention}", ephemeral=True)

        except Exception as e:
            await inter.followup.send(f"Erro ao criar ticket: {str(e)}", ephemeral=True)
