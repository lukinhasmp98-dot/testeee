"""
Sistema de Tickets (runtime)
Cuida da criacao, acoes e sync com a dashboard web.
Configuracao dos paineis foi movida para a dashboard (removida do bot).
"""
import disnake
import asyncio
import time
import io
import uuid
from disnake.ext import commands, tasks

from functions.database import Database

from .publisher import TicketPublisher
from .handlers.creation import (
    create_ticket,
    check_existing_ticket,
    check_permissions,
    check_office_hours,
    TicketFormModal,
)
from .handlers.team_panel import get_attendant_panel, get_panel_data_for_ticket
from .handlers.user_panel import get_user_panel
from .actions.close import close_ticket
from .actions.assume import assume_ticket
from .actions.notify import notify_user, notify_attendant
from .actions.rename import rename_ticket, RenameTicketModal
from .actions.priority import get_priority_panel, set_priority
from .actions.users import add_user_to_ticket, remove_user_from_ticket, get_user_select_panel
from .actions.transfer import transfer_ticket, get_transfer_panel
from .actions.transcript import send_transcript_to_user
from .actions.archive import archive_ticket, mark_resolved
from .actions.call import create_call, delete_call, request_call, get_call_panel
from .actions.history import show_user_history, get_history_user_select
from .utils import safe_defer, safe_send


class TicketPixChargeModal(disnake.ui.Modal):
    """Cobrança manual criada pela equipe dentro de um ticket de orçamento."""
    def __init__(self, channel_id: int):
        self.channel_id = channel_id
        super().__init__(title="Gerar PIX para orçamento", components=[
            disnake.ui.TextInput(label="Valor", custom_id="amount", placeholder="Ex.: 120,00", max_length=20),
            disnake.ui.TextInput(label="Descrição do pedido", custom_id="description", placeholder="Ex.: Logo para minha loja", max_length=120),
        ])

    async def callback(self, inter):
        panel_data, option_data, ticket_info = get_panel_data_for_ticket(self.channel_id)
        if not ticket_info or str(ticket_info.get("ticket", {}).get("option_id")) != "orcamento":
            return await inter.response.send_message("A cobrança PIX automática da fila é exclusiva de tickets de orçamento.", ephemeral=True)
        roles = (option_data.get("roles") if option_data else panel_data.get("roles", {})).get("attendant", [])
        is_staff = any(str(role.id) in {str(item) for item in roles} for role in inter.author.roles) or inter.author.guild_permissions.administrator
        if not is_staff:
            return await inter.response.send_message("Somente a equipe pode gerar a cobrança.", ephemeral=True)
        raw = inter.text_values["amount"].replace("R$", "").replace(".", "").replace(",", ".").strip()
        try: amount = float(raw); assert amount > 0
        except (ValueError, AssertionError): return await inter.response.send_message("Informe um valor válido, por exemplo `120,00`.", ephemeral=True)
        pix = (Database.get_config().get("manual_pix") or {})
        key = str(pix.get("key") or "").strip()
        if not pix.get("enabled") or not key:
            return await inter.response.send_message("O PIX manual não está configurado na Central.", ephemeral=True)
        payment_id = f"KROMA-{uuid.uuid4().hex[:8].upper()}"; expires = int(time.time() + 3600)
        payments = Database.get_document("manual_pix_payments") or {}
        payments[payment_id] = {"id":payment_id,"amount":amount,"user_id":int(ticket_info["user_id"]),"staff_id":inter.author.id,"description":inter.text_values["description"].strip(),"key":key,"status":"awaiting_proof","created_at":time.time(),"expires_at":expires,"channel_id":self.channel_id,"ticket_id":self.channel_id,"option_id":"orcamento"}
        Database.save_document("manual_pix_payments", payments)
        image = None
        try:
            from functions.qr_code import QRGenerator
            raw_qr = await QRGenerator.generate(key)
            if raw_qr: image = disnake.File(io.BytesIO(raw_qr), filename="pix-kroma.png")
        except Exception: pass
        details = f"## PIX MANUAL / ORÇAMENTO\n**Valor:** `R$ {amount:,.2f}`\n**Pedido:** {inter.text_values['description'].strip()}\n**Recebedor:** {pix.get('recipient') or 'Kroma Studio'}\n**Válido até:** <t:{expires}:R>\n\n**Chave PIX**\n```\n{key}\n```\n-# {pix.get('message') or 'Envie o comprovante neste ticket após o pagamento.'}"
        children=[disnake.ui.TextDisplay(details)]
        if image: children.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media="attachment://pix-kroma.png")))
        children += [disnake.ui.Separator(),disnake.ui.ActionRow(disnake.ui.Button(label="Copiar chave PIX",custom_id=f"KromaPix:copy:{payment_id}",style=disnake.ButtonStyle.secondary),disnake.ui.Button(label="Confirmar recebimento",custom_id=f"KromaPix:confirm:{payment_id}",style=disnake.ButtonStyle.success))]
        await inter.response.send_message(components=[disnake.ui.Container(*children,accent_colour=disnake.Colour(0x43DBD0))],file=image,flags=disnake.MessageFlags(is_components_v2=True))


async def start_ticket_production(inter: disnake.MessageInteraction):
    """Move para produção apenas o orçamento cujo PIX já foi confirmado."""
    panel_data, option_data, ticket_info = get_panel_data_for_ticket(inter.channel.id)
    if not ticket_info or str(ticket_info.get("ticket", {}).get("option_id")) != "orcamento":
        return await safe_send(inter, "A fila de produção é exclusiva de tickets de orçamento.", ephemeral=True)
    roles = (option_data.get("roles") if option_data else panel_data.get("roles", {})).get("attendant", [])
    is_staff = any(str(role.id) in {str(item) for item in roles} for role in inter.author.roles) or inter.author.guild_permissions.administrator
    if not is_staff:
        return await safe_send(inter, "Somente a equipe pode iniciar a produção.", ephemeral=True)
    from functions.art_queue import set_status
    entry = await set_status(inter.bot, inter.channel.id, "em_producao", staff_id=inter.author.id)
    if not entry:
        return await safe_send(inter, "Confirme o PIX deste orçamento antes de iniciar a produção.", ephemeral=True)
    await safe_send(inter, "Produção iniciada. A fila pública foi atualizada.", ephemeral=True)


class TicketSystem(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.dashboard_sync_loop.is_running():
            self.dashboard_sync_loop.start()

    def cog_unload(self):
        self.dashboard_sync_loop.cancel()

    @tasks.loop(seconds=3)
    async def dashboard_sync_loop(self):
        try:
            config = await Database.refresh_document("tickets_config") or {}
            panels = config.get("panels", {})

            pending_publish = []
            pending_sync = []
            pending_unpublish = []
            unset_paths = []  # campos a limpar via $unset (evita race com edições do backend)

            for panel_id, panel_data in list(panels.items()):
                if not isinstance(panel_data, dict):
                    continue

                publish = panel_data.pop("_publish_pending", None)
                if publish and publish.get("channel_id"):
                    pending_publish.append((panel_id, publish["channel_id"]))
                    unset_paths.append(f"panels.{panel_id}._publish_pending")

                if panel_data.pop("_sync_pending", None):
                    pending_sync.append(panel_id)
                    unset_paths.append(f"panels.{panel_id}._sync_pending")

                unpublish = panel_data.pop("_unpublish_pending", None)
                if unpublish and unpublish.get("channel_id") and unpublish.get("message_id"):
                    pending_unpublish.append((panel_id, unpublish["channel_id"], unpublish["message_id"]))
                    unset_paths.append(f"panels.{panel_id}._unpublish_pending")

            if unset_paths:
                # $unset cirúrgico em vez de replace_one — preserva edições concorrentes do backend (novas opções, etc)
                await Database.unset_nested_fields("tickets_config", unset_paths)

            for panel_id, channel_id in pending_publish:
                try:
                    channel = self.bot.get_channel(int(channel_id))
                    if channel:
                        await TicketPublisher.send_panel(self.bot, panel_id, channel)
                except Exception as e:
                    print(f"[TicketSync] Erro ao publicar painel {panel_id}: {e}")

            for panel_id in pending_sync:
                try:
                    await TicketPublisher.sync_panel_message(self.bot, panel_id)
                except Exception as e:
                    print(f"[TicketSync] Erro ao sincronizar painel {panel_id}: {e}")

            for panel_id, channel_id, message_id in pending_unpublish:
                try:
                    channel = self.bot.get_channel(int(channel_id))
                    if channel:
                        msg = await channel.fetch_message(int(message_id))
                        if msg:
                            await msg.delete()
                        print(f"[TicketSync] Mensagem do painel {panel_id} deletada com sucesso")
                except Exception as e:
                    print(f"[TicketSync] Erro ao despublicar painel {panel_id}: {e}")

        except Exception as e:
            print(f"[TicketSync] Erro geral: {e}")

    @dashboard_sync_loop.before_loop
    async def before_dashboard_sync_loop(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener("on_button_click")
    async def runtime_button_listener(self, inter: disnake.MessageInteraction):
        if not isinstance(inter.author, disnake.Member):
            return
        custom_id = inter.component.custom_id

        if not custom_id.startswith("Ticket_"):
            return

        parts = custom_id.split(":")
        action = parts[0].replace("Ticket_", "")
        args = parts[1:] if len(parts) > 1 else []


        public_actions = {
            "Create", "AttendantPanel", "UserPanel", "Close", "CloseUser",
            "Assume", "Notify", "NotifyUser",
            "Info", "Rename", "Priority", "Resolved", "Archive",
            "AddUser", "AddUserUser", "RemoveUser", "RemoveUserUser",
            "Transcript", "TranscriptUser", "History",
            "ManageCall", "CreateCall", "DeleteCall", "RequestCall",
            "Transfer", "TransferUser", "ChargePix", "StartProduction",
        }
        if action not in public_actions:
            return

        if action == "AttendantPanel":
            try:
                panel_data, option_data, ticket_info = get_panel_data_for_ticket(inter.channel.id)
                payload = await get_attendant_panel(panel_data, option_data, ticket_info)
                await safe_send(inter, **payload, flags=disnake.MessageFlags(is_components_v2=True, ephemeral=True))
            except Exception as e:
                await safe_send(inter, f"Erro ao carregar painel do atendente: {e}", ephemeral=True)

        elif action == "UserPanel":
            try:
                panel_data, option_data, ticket_info = get_panel_data_for_ticket(inter.channel.id)
                payload = await get_user_panel(panel_data, option_data)
                await safe_send(inter, **payload, flags=disnake.MessageFlags(is_components_v2=True, ephemeral=True))
            except Exception as e:
                await safe_send(inter, f"Erro ao carregar painel do usuario: {e}", ephemeral=True)

        elif action == "ChargePix":
            if inter.response.is_done():
                await safe_send(inter, "A interação expirou. Abra o painel da equipe novamente.", ephemeral=True)
            else:
                await inter.response.send_modal(TicketPixChargeModal(inter.channel.id))

        elif action == "StartProduction":
            await start_ticket_production(inter)

        elif action == "Close":
            await close_ticket(inter, is_user=False)

        elif action == "CloseUser":
            await close_ticket(inter, is_user=True)

        elif action == "Assume":
            await assume_ticket(inter)

        elif action == "Notify":
            await notify_user(inter)

        elif action == "NotifyUser":
            await notify_attendant(inter)

        elif action == "Info":
            panel_data, option_data, ticket_info = get_panel_data_for_ticket(inter.channel.id)
            if not ticket_info:
                return await safe_send(inter, "Informacoes do ticket nao encontradas.", ephemeral=True)

            user_id = ticket_info.get("user_id")
            user = inter.guild.get_member(int(user_id))
            created_at = ticket_info.get("ticket", {}).get("created_at")

            header = "# Info\n-# Informacoes do Ticket"
            info_text = (
                f"**Dono:** {user.mention if user else '`Desconhecido`'}\n"
                f"**Aberto em:** <t:{created_at}:f>\n"
                f"**Painel:** `{panel_data.get('name', 'N/A')}`"
            )
            if option_data:
                info_text += f"\n**Opcao:** `{option_data.get('name', 'N/A')}`"

            payload = {
                "components": [
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(header),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(info_text),
                    )
                ]
            }
            await safe_send(inter, **payload, flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

        elif action == "Rename":
            if inter.response.is_done():
                await safe_send(inter, "A interação expirou. Tente novamente.", ephemeral=True)
            else:
                await inter.response.send_modal(RenameTicketModal())

        elif action == "Priority":
            if inter.response.is_done():
                await inter.edit_original_message(**get_priority_panel(inter.channel.id), flags=disnake.MessageFlags(is_components_v2=True))
            else:
                await inter.response.edit_message(**get_priority_panel(inter.channel.id), flags=disnake.MessageFlags(is_components_v2=True))

        elif action == "Resolved":
            await mark_resolved(inter)

        elif action == "Archive":
            await archive_ticket(inter)

        elif action in ("AddUser", "AddUserUser"):
            await safe_send(inter, **get_user_select_panel("add"), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

        elif action in ("RemoveUser", "RemoveUserUser"):
            await safe_send(inter, **get_user_select_panel("remove"), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

        elif action in ("Transcript", "TranscriptUser"):
            await send_transcript_to_user(inter)

        elif action == "History":
            await safe_send(inter, **get_history_user_select(), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

        elif action == "ManageCall":
            if inter.response.is_done():
                await inter.edit_original_message(**get_call_panel(inter.channel.id), flags=disnake.MessageFlags(is_components_v2=True))
            else:
                await inter.response.edit_message(**get_call_panel(inter.channel.id), flags=disnake.MessageFlags(is_components_v2=True))

        elif action == "CreateCall":
            await create_call(inter)

        elif action == "DeleteCall":
            await delete_call(inter)

        elif action == "RequestCall":
            await request_call(inter)

        elif action == "Transfer":
            await safe_send(inter, **get_transfer_panel(is_user=False), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

        elif action == "TransferUser":
            await safe_send(inter, **get_transfer_panel(is_user=True), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True)

        elif action == "Create":
            panel_id = args[0]
            option_id = args[1] if len(args) > 1 else None
            await self._handle_ticket_creation(inter, panel_id, option_id)

    @commands.Cog.listener("on_dropdown")
    async def runtime_select_listener(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        if not custom_id.startswith("Ticket_"):
            return

        parts = custom_id.split(":")
        action = parts[0].replace("Ticket_", "")
        args = parts[1:] if len(parts) > 1 else []
        selected = inter.values[0] if inter.values else None

        if action == "SetPriority":
            await safe_defer(inter, ephemeral=True)
            await set_priority(inter, selected)

            panel_data, option_data, ticket_info = get_panel_data_for_ticket(inter.channel.id)
            await inter.edit_original_message(
                **(await get_attendant_panel(panel_data, option_data, ticket_info)),
                flags=disnake.MessageFlags(is_components_v2=True),
            )

        elif action == "SelectUser":
            action_type = args[0] if args else "add"
            user_id = int(inter.values[0])
            user = inter.guild.get_member(user_id)
            if not user:
                return await safe_send(inter, "Usuario nao encontrado.", ephemeral=True)
            await safe_defer(inter, ephemeral=True)
            if action_type == "add":
                await add_user_to_ticket(inter, user)
            else:
                await remove_user_from_ticket(inter, user)

        elif action == "TransferSelect":
            user_id = int(inter.values[0])
            user = inter.guild.get_member(user_id)
            if not user:
                return await safe_send(inter, "Usuario nao encontrado.", ephemeral=True)
            await transfer_ticket(inter, user)

        elif action == "HistoryUserSelect":
            user_id = int(inter.values[0])
            user = inter.guild.get_member(user_id)
            if not user:
                return await safe_send(inter, "Usuario nao encontrado.", ephemeral=True)
            await show_user_history(inter, user)

        elif action == "TeamAction":

            if selected and selected.startswith("Ticket_"):
                team_action = selected.replace("Ticket_", "")

                async def _safe_send_modal(modal):
                    if not inter.response.is_done():
                        return await inter.response.send_modal(modal)
                    return await safe_send(inter, "A interação expirou. Tente novamente.", ephemeral=True)

                async def _safe_edit_message(**kwargs):
                    try:
                        if not inter.response.is_done():
                            return await inter.response.edit_message(**kwargs)
                        return await inter.edit_original_message(**kwargs)
                    except Exception:
                        return None

                action_map = {
                    "Close": lambda: close_ticket(inter, is_user=False),
                    "Assume": lambda: assume_ticket(inter),
                    "Notify": lambda: notify_user(inter),
                    "Rename": lambda: _safe_send_modal(RenameTicketModal()),
                    "Priority": lambda: _safe_edit_message(**get_priority_panel(inter.channel.id), flags=disnake.MessageFlags(is_components_v2=True)),
                    "Resolved": lambda: mark_resolved(inter),
                    "Archive": lambda: archive_ticket(inter),
                    "AddUser": lambda: safe_send(inter, **get_user_select_panel("add"), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "RemoveUser": lambda: safe_send(inter, **get_user_select_panel("remove"), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "Transcript": lambda: send_transcript_to_user(inter),
                    "History": lambda: safe_send(inter, **get_history_user_select(), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "ManageCall": lambda: _safe_edit_message(**get_call_panel(inter.channel.id), flags=disnake.MessageFlags(is_components_v2=True)),
                    "Transfer": lambda: safe_send(inter, **get_transfer_panel(is_user=False), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "ChargePix": lambda: _safe_send_modal(TicketPixChargeModal(inter.channel.id)),
                    "StartProduction": lambda: start_ticket_production(inter),
                }
                handler = action_map.get(team_action)
                if handler:
                    await handler()
                else:
                    await safe_send(inter, "Acao nao reconhecida.", ephemeral=True)

        elif action == "UserAction":

            if selected and selected.startswith("Ticket_"):
                user_action = selected.replace("Ticket_", "")
                action_map = {
                    "CloseUser": lambda: close_ticket(inter, is_user=True),
                    "NotifyUser": lambda: notify_attendant(inter),
                    "AddUserUser": lambda: safe_send(inter, **get_user_select_panel("add"), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "RemoveUserUser": lambda: safe_send(inter, **get_user_select_panel("remove"), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "TransferUser": lambda: safe_send(inter, **get_transfer_panel(is_user=True), flags=disnake.MessageFlags(is_components_v2=True), ephemeral=True),
                    "RequestCall": lambda: request_call(inter),
                    "TranscriptUser": lambda: send_transcript_to_user(inter),
                }
                handler = action_map.get(user_action)
                if handler:
                    await handler()
                else:
                    await safe_send(inter, "Acao nao reconhecida.", ephemeral=True)

        elif action == "PanelSelect":
            panel_id = args[0] if args else None
            option_id = selected
            if panel_id:
                await self._handle_ticket_creation(inter, panel_id, option_id)

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        tickets_data = Database.get_document("tickets_data") or {}
        panels = tickets_data.get("panels", {})

        for panel_id, users in panels.items():
            user_tickets = users.get(str(member.id), [])
            for ticket in user_tickets:
                if ticket.get("status") == "open":
                    channel_id = ticket.get("ticket_id")
                    channel = self.bot.get_channel(channel_id)

                    ticket["status"] = "closed"
                    ticket["closed_at"] = int(time.time())
                    ticket["close_reason"] = "Usuario saiu do servidor"

                    if channel:
                        try:
                            await channel.send("O dono do ticket saiu do servidor. O canal sera excluido em instantes.")
                            await asyncio.sleep(5)
                            await channel.delete(reason=f"Usuario {member} saiu do servidor.")
                        except Exception:
                            pass

        Database.save_document("tickets_data", tickets_data)

    @commands.Cog.listener()
    async def on_thread_member_join(self, member: disnake.ThreadMember):
        thread = member.thread

        if thread.type != disnake.ChannelType.private_thread or member.id == self.bot.user.id:
            return

        panel_data, option_data, ticket_info = get_panel_data_for_ticket(thread.id)
        if not ticket_info:
            return

        user_id = member.id
        owner_id = int(ticket_info.get("user_id", 0))

        if user_id == owner_id:
            return

        roles_data = (option_data.get("roles") if option_data else None) or panel_data.get("roles", {})
        attendant_roles = [int(r) for r in roles_data.get("attendant", [])]

        permitted_users = ticket_info.get("ticket", {}).get("permitted_users", [])
        if user_id in permitted_users:
            return

        guild_member = thread.guild.get_member(user_id)
        if not guild_member:
            try:
                guild_member = await thread.guild.fetch_member(user_id)
            except Exception:
                pass

        if guild_member:
            if any(role.id in attendant_roles for role in guild_member.roles) or guild_member.guild_permissions.administrator:
                return

        try:
            await thread.remove_user(member)
        except Exception:
            pass

    async def _handle_ticket_creation(self, inter: disnake.MessageInteraction, panel_id: str, option_id: str = None):
        config = Database.get_document("tickets_config") or {}
        panel_data = config.get("panels", {}).get(panel_id)

        if not panel_data:
            return await safe_send(inter, "Painel nao encontrado.", ephemeral=True)

        if not panel_data.get("enabled", False):
            return await safe_send(inter, "Este painel esta desativado.", ephemeral=True)

        ok, error = await check_office_hours(panel_data)
        if not ok:
            return await safe_send(inter, error, ephemeral=True)

        option_data = None
        if option_id:
            option_data = next((o for o in panel_data.get("options", []) if str(o.get("id")) == option_id), None)
        else:
            options = panel_data.get("options", [])
            if options:
                option_data = options[0]

        questions = []
        if option_data:
            questions = option_data.get("form", {}).get("questions", [])
        if not questions:
            questions = panel_data.get("form", {}).get("questions", [])

        if questions:

            if inter.response.is_done():
                return await safe_send(inter, "A interação expirou. Tente novamente.", ephemeral=True)
            await inter.response.send_modal(TicketFormModal(self.bot, panel_id, option_data, questions))
        else:
            await safe_defer(inter, ephemeral=True)

            try:
                ok, error = await check_existing_ticket(self.bot, inter.author.id, panel_id)
                if not ok:
                    return await inter.followup.send(error, ephemeral=True)

                ok, error = await check_permissions(inter.author, panel_data, option_data)
                if not ok:
                    return await inter.followup.send(error, ephemeral=True)

                channel = await create_ticket(inter, self.bot, panel_id, option_data)
                await inter.followup.send(f"Ticket criado: {channel.mention}", ephemeral=True)
            except Exception as e:
                await inter.followup.send(f"Erro ao criar ticket: {e}", ephemeral=True)


def setup(bot: commands.Bot):
    bot.add_cog(TicketSystem(bot))
