"""
Módulo de IA para tickets.
Escuta mensagens em canais de ticket e responde com áudio via ElevenLabs.
Mantém histórico da conversa por ticket para contexto entre sessões.
Detecta sinal de fechamento no transcript para fechar ticket automaticamente.
Pausa a IA automaticamente quando um atendente humano envia mensagem no ticket.
Persiste o estado de pausa no banco para sobreviver a restarts.
Debounce de mensagens: espera 60s sem nova mensagem antes de responder.
"""

import asyncio
import re
import disnake
from disnake.ext import commands
from collections import defaultdict
from functions.database import Database
from functions.elevenlabs_ai import chat_with_agent, _get_config as get_ai_config, AgentResponse
from functions.voice_message import send_voice_message
from functions.ai_context import build_ai_context

MAX_HISTORY = 30

CLOSE_TOOL_NAME = "fechar_ticket"

DEBOUNCE_SECONDS = 60


def _get_ticket_info(channel_id: int) -> dict | None:
    tickets_data = Database.get_document("tickets_data") or {}
    panels = tickets_data.get("panels", {})

    for panel_id, users in panels.items():
        if not isinstance(users, dict):
            continue
        for user_id, tickets in users.items():
            if not isinstance(tickets, list):
                continue
            for ticket in tickets:
                if ticket.get("ticket_id") == channel_id and ticket.get("status") == "open":
                    return {
                        "panel_id": panel_id,
                        "user_id": user_id,
                        "ticket": ticket,
                    }
    return None


def _get_attendant_role_ids(panel_id: str, option_id: str = None) -> list[int]:
    config = Database.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})

    option_data = None
    if option_id:
        option_data = next(
            (o for o in panel_data.get("options", []) if str(o.get("id")) == str(option_id)),
            None
        )

    roles_data = (option_data.get("roles") if option_data else None) or panel_data.get("roles", {})
    return [int(r) for r in roles_data.get("attendant", [])]


def _get_form_answers_as_vars(ticket: dict, panel_id: str, option_id: str = None) -> dict:
    form_answers = ticket.get("form_answers")
    if not form_answers:
        return {}

    config = Database.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})

    option_data = None
    if option_id:
        option_data = next(
            (o for o in panel_data.get("options", []) if str(o.get("id")) == str(option_id)),
            None
        )

    questions = (option_data.get("form", {}).get("questions", []) if option_data
                 else panel_data.get("form", {}).get("questions", []))
    question_map = {q.get("id"): q.get("label", "") for q in questions}

    result = {}
    for qid, answer in form_answers.items():
        if answer and answer.strip():
            label = question_map.get(qid, qid)

            key = "form_" + label.lower().replace(" ", "_").replace("-", "_")[:30]
            result[key] = answer.strip()
    return result


class AITicketListener(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._processing = set()
        self._history: dict[int, list[dict]] = defaultdict(list)
        self._debounce_tasks: dict[int, asyncio.Task] = {}
        self._pending_messages: dict[int, list[str]] = defaultdict(list)
        self._pending_context: dict[int, dict] = {}

    def _is_paused(self, channel_id: int) -> bool:
        data = Database.get_document_ref("tickets_ai_state") or {}
        return channel_id in data.get("paused_channels", [])

    def _set_paused(self, channel_id: int, paused: bool):
        data = Database.get_document("tickets_ai_state") or {}
        paused_channels = data.get("paused_channels", [])
        if paused and channel_id not in paused_channels:
            paused_channels.append(channel_id)
        elif not paused and channel_id in paused_channels:
            paused_channels.remove(channel_id)
        data["paused_channels"] = paused_channels
        Database.save_document("tickets_ai_state", data)

    def _add_to_history(self, channel_id: int, role: str, content: str):
        self._history[channel_id].append({"role": role, "content": content})
        if len(self._history[channel_id]) > MAX_HISTORY:
            self._history[channel_id] = self._history[channel_id][-MAX_HISTORY:]

    def clear_history(self, channel_id: int):
        self._history.pop(channel_id, None)
        self._set_paused(channel_id, False)
        self._pending_messages.pop(channel_id, None)
        self._pending_context.pop(channel_id, None)
        task = self._debounce_tasks.pop(channel_id, None)
        if task and not task.done():
            task.cancel()

    def _is_attendant(self, member: disnake.Member, panel_id: str, option_id: str = None) -> bool:
        if member.guild_permissions.administrator:
            return True
        attendant_ids = _get_attendant_role_ids(panel_id, option_id)
        return any(role.id in attendant_ids for role in member.roles)

    @commands.Cog.listener("on_message")
    async def on_ticket_message(self, message: disnake.Message):
        if message.author.bot:
            return

        ai_config = get_ai_config()
        if not ai_config["enabled"]:
            return
        if not ai_config["api_key"] or not ai_config["agent_id"]:
            return

        ticket_info = _get_ticket_info(message.channel.id)
        if not ticket_info:
            return

        panel_id = ticket_info.get("panel_id", "")
        option_id = ticket_info.get("ticket", {}).get("option_id")

        if self._is_attendant(message.author, panel_id, option_id):
            self._set_paused(message.channel.id, True)
            return

        if self._is_paused(message.channel.id):
            return

        ticket_owner_id = ticket_info.get("user_id")
        if str(message.author.id) != str(ticket_owner_id):
            return

        content = message.content.strip()
        if not content:
            return

        self._add_to_history(message.channel.id, "user", content)
        self._pending_messages[message.channel.id].append(content)

        self._pending_context[message.channel.id] = {
            "ai_config": ai_config,
            "ticket_info": ticket_info,
            "panel_id": panel_id,
            "option_id": option_id,
            "author": message.author,
            "channel": message.channel,
            "guild": message.guild,
            "message_id": message.id,
        }

        old_task = self._debounce_tasks.get(message.channel.id)
        if old_task and not old_task.done():
            old_task.cancel()

        self._debounce_tasks[message.channel.id] = self.bot.loop.create_task(
            self._debounce_respond(message.channel.id)
        )

    async def _debounce_respond(self, channel_id: int):
        try:
            await asyncio.sleep(DEBOUNCE_SECONDS)
        except asyncio.CancelledError:
            return

        if channel_id in self._processing:
            return

        ctx = self._pending_context.pop(channel_id, None)
        msgs = self._pending_messages.pop(channel_id, [])
        self._debounce_tasks.pop(channel_id, None)

        if not ctx or not msgs:
            return

        combined_content = "\n".join(msgs)
        ai_config = ctx["ai_config"]
        ticket_info = ctx["ticket_info"]
        panel_id = ctx["panel_id"]
        option_id = ctx["option_id"]
        channel = ctx["channel"]
        author = ctx["author"]
        guild = ctx["guild"]
        last_message_id = ctx["message_id"]

        self._processing.add(channel_id)

        try:
            async with channel.typing():
                custom_prompt = ai_config.get("prompt", "")

                user_name = author.display_name
                user_id_str = str(author.id)
                channel_name = getattr(channel, "name", "ticket")
                guild_name = guild.name if guild else ""

                identity_block = (
                    f"\n\n--- ATENDIMENTO ATUAL ---\n"
                    f"Cliente: {user_name} (ID: {user_id_str})\n"
                    f"Canal: {channel_name}\n"
                    f"Servidor: {guild_name}\n"
                )

                form_vars = _get_form_answers_as_vars(
                    ticket_info.get("ticket", {}), panel_id, option_id
                )
                if form_vars:
                    identity_block += "Respostas do formulário:\n"
                    for key, val in form_vars.items():
                        label = key.replace("form_", "").replace("_", " ").title()
                        identity_block += f"  - {label}: {val}\n"

                identity_block += "--- FIM ---\n"
                identity_block += "IMPORTANTE: Você está atendendo APENAS este cliente. Não confunda com outros atendimentos."

                custom_prompt = f"{custom_prompt}\n{identity_block}" if custom_prompt else identity_block

                system_context = await build_ai_context(customer_discord_id=user_id_str)
                if system_context:
                    custom_prompt = f"{custom_prompt}\n\n{system_context}"

                history = self._history.get(channel_id, [])

                dyn_vars = {
                    "user_name": user_name,
                    "user_id": user_id_str,
                    "channel_name": channel_name,
                    "ticket_panel": panel_id,
                    "guild_name": guild_name,
                }
                dyn_vars.update(form_vars)

                result = await chat_with_agent(
                    user_message=combined_content,
                    prompt_override=custom_prompt,
                    conversation_history=history[:-len(msgs)] if len(history) > len(msgs) else None,
                    dynamic_variables=dyn_vars,
                )
                if result:
                    clean_transcript = re.sub(r'\s*\[[A-Za-zÀ-ú]+\]\s*', ' ', result.transcript).strip()
                    if not clean_transcript:
                        clean_transcript = result.transcript

                    force_text = _should_force_text(clean_transcript)
                    send_as_text = result.text_only or force_text

                    if send_as_text:
                        transcript_text = clean_transcript
                        if transcript_text and transcript_text != "[Resposta em áudio]":
                            while transcript_text:
                                chunk = transcript_text[:2000]
                                transcript_text = transcript_text[2000:]
                                await channel.send(chunk)
                    else:
                        await send_voice_message(
                            bot=self.bot,
                            channel_id=channel_id,
                            audio_data=result.audio,
                            duration_secs=result.duration,
                            reply_to=last_message_id
                        )
                    self._add_to_history(channel_id, "assistant", clean_transcript)

                    if result.should_close:
                        self.clear_history(channel_id)
                        async def _delayed_close(ch_id=channel_id):
                            await asyncio.sleep(10)
                            try:
                                from .actions.close import auto_close_ticket
                                await auto_close_ticket(self.bot, ch_id)
                            except Exception as e:
                                print(f"[AI_TICKET] Erro ao fechar ticket automaticamente: {e}")
                        self.bot.loop.create_task(_delayed_close())
        except Exception as e:
            print(f"[AI_TICKET] Erro ao processar mensagem: {e}")
        finally:
            self._processing.discard(channel_id)


_FORCE_TEXT_PATTERNS = [
    re.compile(r'\b\d{17,20}\b'),
    re.compile(r'https?://\S+'),
    re.compile(r'\bID\s*[:\-]\s*\S+', re.IGNORECASE),
    re.compile(r'\bbotID\b', re.IGNORECASE),
    re.compile(r'\b[0-9a-f]{24}\b'),
    re.compile(r'(?=[A-Za-z0-9]{15,}\b)(?=.*\d)(?=.*[A-Za-z])[A-Za-z0-9]{15,}\b'),
]

def _should_force_text(transcript: str) -> bool:
    if not transcript:
        return False
    for pattern in _FORCE_TEXT_PATTERNS:
        if pattern.search(transcript):
            return True
    return False


def setup(bot: commands.Bot):
    bot.add_cog(AITicketListener(bot))
