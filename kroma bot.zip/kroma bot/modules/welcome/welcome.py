"""
Welcome / Leave / Autorole — handler de on_member_join e on_member_remove.

Lê 3 documentos do banco local do bot:
  - welcome_message: { enabled, channel_id, message_type, content, embed, components_v2, mention_user }
  - leave_message:   { enabled, channel_id, message_type, content, embed, components_v2 }
  - auto_role:       { role_id }

Modos de mensagem (igual auto_messages):
  - 'plain'     → texto simples
  - 'container' → Container V2 com embed-like data
  - 'builder'   → schema components_v2 do dashboard

Placeholders suportados:
  {user.mention}, {user.name}, {user.id}, {user.avatar}
  {server.name}, {server.id}, {server.member_count}
  {date}, {time}
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any

import disnake
from disnake.ext import commands

from functions.database import Database

logger = logging.getLogger(__name__)


async def _fetch_welcome_config_resilient() -> dict:
    """Obtém a configuração local de boas-vindas."""
    cached = Database.get_document("welcome_message") or {}
    if cached and cached.get("enabled") is not None:
        return cached
    return cached


def _resolve_color(value: Any) -> disnake.Colour | None:
    if value is None:
        return None
    try:
        if isinstance(value, int):
            return disnake.Colour(value)
        return disnake.Colour(int(str(value).lstrip("#"), 16))
    except Exception:
        return None


def _build_placeholders(member: disnake.Member, guild: disnake.Guild) -> dict[str, str]:
    now = datetime.now()
    avatar_url = ""
    try:
        avatar_url = str(member.display_avatar.url) if member.display_avatar else ""
    except Exception:
        pass
    return {
        "user.mention": member.mention,
        "user.name": member.display_name,
        "user.username": member.name,
        "user.id": str(member.id),
        "user.avatar": avatar_url,
        "server.name": guild.name,
        "server.id": str(guild.id),
        "server.member_count": str(guild.member_count or 0),
        "date": now.strftime("%d/%m/%Y"),
        "time": now.strftime("%H:%M"),
    }


def _substitute(text: str | None, placeholders: dict[str, str]) -> str:
    if not text:
        return ""
    out = text
    for key, val in placeholders.items():
        out = out.replace("{" + key + "}", val)
    return out


def _build_simple_container(content: str, embed_data: dict, placeholders: dict[str, str]) -> list:
    """Modo 'container': monta Container V2 com TextDisplays + image."""
    parts: list = []
    title = _substitute(embed_data.get("title"), placeholders)
    description = _substitute(embed_data.get("description"), placeholders)
    body = _substitute(content, placeholders)

    if title:
        parts.append(disnake.ui.TextDisplay(f"# {title[:200]}"))
    if description:
        parts.append(disnake.ui.TextDisplay(description[:3500]))
    if body and not (title or description):
        parts.append(disnake.ui.TextDisplay(body[:3500]))
    image_url = embed_data.get("image_url")
    if image_url:
        try:
            parts.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=image_url)))
        except Exception:
            pass
    if not parts:
        parts.append(disnake.ui.TextDisplay(body or "Bem-vindo!"))

    color = _resolve_color(embed_data.get("color"))
    try:
        if color:
            return [disnake.ui.Container(*parts, accent_colour=color)]
        return [disnake.ui.Container(*parts)]
    except Exception as e:
        logger.warning(f"[welcome] Container falhou: {e!r}")
        return [disnake.ui.TextDisplay(body or "Bem-vindo!")]


async def _schedule_delete(message: disnake.Message, seconds: int) -> None:
    """Apaga a mensagem N segundos depois. Spawn como task pra nao bloquear."""
    if not message or seconds <= 0:
        return
    try:
        await asyncio.sleep(seconds)
        await message.delete()
    except (disnake.NotFound, disnake.Forbidden):
        pass
    except Exception as e:
        logger.warning(f"[welcome] auto_delete falhou: {e!r}")


async def _send_message(channel: disnake.TextChannel, member: disnake.Member, config: dict, mention: bool = False) -> None:
    if not config or not config.get("enabled"):
        return
    placeholders = _build_placeholders(member, channel.guild)

    message_type = config.get("message_type") or "container"
    content = config.get("content", "") or ""
    embed_data = config.get("embed") or {}
    components_v2 = config.get("components_v2")
    auto_delete = int(config.get("auto_delete_seconds") or 0)

    sent: disnake.Message | None = None

    # Builder mode (Loritta-style) — usa renderer existente
    if message_type == "builder" and isinstance(components_v2, list) and components_v2:
        try:
            from functions.components_v2_renderer import render_components_v2
            rendered = render_components_v2(components_v2, placeholders)
            if rendered:
                kwargs: dict[str, Any] = {
                    "components": rendered,
                    "flags": disnake.MessageFlags(is_components_v2=True),
                }
                # Mention auto removida — buggava a mensagem (user pediu)
                sent = await channel.send(**kwargs)
        except Exception as e:
            logger.error(f"[welcome] builder falhou, fallback container: {e!r}")

    # Plain mode
    if sent is None and message_type == "plain":
        body = _substitute(content, placeholders)
        if mention and "{user.mention}" not in content:
            body = f"{member.mention} {body}".strip()
        if body.strip():
            sent = await channel.send(body[:2000])

    # Container mode (default / fallback)
    if sent is None:
        components = _build_simple_container(content, embed_data, placeholders)
        kwargs: dict[str, Any] = {
            "components": components,
            "flags": disnake.MessageFlags(is_components_v2=True),
        }
        sent = await channel.send(**kwargs)

    if sent and auto_delete > 0:
        asyncio.create_task(_schedule_delete(sent, auto_delete))


class WelcomeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_member_join")
    async def on_member_join(self, member: disnake.Member):
        logger.info(f"[welcome] on_member_join {member.id} guild={member.guild.id} bot={member.bot}")
        if member.bot:
            return
        # 1) AUTOROLE — atribui cargo configurado
        try:
            auto_role_doc = Database.get_document("auto_role") or {}
            role_id = auto_role_doc.get("role_id")
            if role_id:
                role = member.guild.get_role(int(role_id))
                if role and role < member.guild.me.top_role:
                    await member.add_roles(role, reason="Autorole: novo membro")
        except disnake.Forbidden:
            logger.warning(f"[autorole] sem permissão pra atribuir cargo no {member.guild.id}")
        except Exception as e:
            logger.error(f"[autorole] erro: {e!r}")

        # 2) WELCOME MESSAGE
        try:
            config = await _fetch_welcome_config_resilient()
            enabled = config.get("enabled")
            channel_id = config.get("channel_id")
            logger.info(f"[welcome] config enabled={enabled} channel={channel_id} type={config.get('message_type')}")
            if not enabled:
                logger.info("[welcome] desativado — abortando")
                return
            if not channel_id:
                logger.warning("[welcome] sem channel_id configurado")
                return
            channel = self.bot.get_channel(int(channel_id))
            if channel is None:
                logger.warning(f"[welcome] canal {channel_id} não encontrado no cache do bot")
                return
            if not isinstance(channel, disnake.TextChannel):
                logger.warning(f"[welcome] canal {channel_id} não é TextChannel ({type(channel).__name__})")
                return
            await _send_message(channel, member, config, mention=bool(config.get("mention_user")))
            logger.info(f"[welcome] mensagem enviada pra {member.id} em #{channel.name}")
        except Exception as e:
            logger.error(f"[welcome] on_member_join erro: {e!r}", exc_info=True)

    @commands.Cog.listener("on_member_remove")
    async def on_member_remove(self, member: disnake.Member):
        if member.bot:
            return
        try:
            config = Database.get_document("leave_message") or {}
            channel_id = config.get("channel_id")
            if not channel_id:
                return
            channel = self.bot.get_channel(int(channel_id))
            if channel is None or not isinstance(channel, disnake.TextChannel):
                return
            await _send_message(channel, member, config, mention=False)
        except Exception as e:
            logger.error(f"[welcome] on_member_remove erro: {e!r}")


def setup(bot: commands.Bot):
    bot.add_cog(WelcomeCog(bot))
