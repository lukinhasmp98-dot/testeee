import disnake
from disnake.ext import commands, tasks
from functions.database import Database
from datetime import datetime


class AutoMessagesManager:

    @staticmethod
    def get_messages() -> dict:
        return Database.get_document("auto_messages") or {}

    @staticmethod
    def save_message(message_id: str, data: dict):
        messages = AutoMessagesManager.get_messages()
        messages[message_id] = data
        Database.save_document("auto_messages", messages)


def _resolve_color(value):
    if not value:
        return None
    try:
        return disnake.Colour(int(str(value).lstrip("#"), 16))
    except Exception:
        return None


def _build_components_simple(content, embed_data):
    """Modo simples: monta Container V2 a partir de content + embed-like data."""
    parts = []
    if embed_data.get("title"):
        parts.append(disnake.ui.TextDisplay(f"# {embed_data['title']}"))
    if embed_data.get("description"):
        parts.append(disnake.ui.TextDisplay(embed_data["description"]))
    if content and not (embed_data.get("title") or embed_data.get("description")):
        parts.append(disnake.ui.TextDisplay(content))
    if embed_data.get("image_url"):
        parts.append(disnake.ui.MediaGallery(
            disnake.MediaGalleryItem(media=embed_data["image_url"])
        ))
    if not parts:
        parts.append(disnake.ui.TextDisplay(content or "Mensagem automática"))

    color = _resolve_color(embed_data.get("color"))
    if color:
        return [disnake.ui.Container(*parts, accent_colour=color)]
    return [disnake.ui.Container(*parts)]


async def _send_auto_message(channel, data: dict):
    """Envia uma mensagem automática respeitando message_type:
    - 'plain': texto puro com content (sem container)
    - 'container': Container V2 a partir de embed/content (default legacy)
    - 'builder': renderiza components_v2 do schema
    Retorna o message_id ou None.
    """
    message_type = data.get("message_type") or "container"
    content = data.get("content", "") or ""
    embed_data = data.get("embed") or {}
    container_data = data.get("container") or {}

    # Modo BUILDER: components_v2 do dashboard
    builder_schema = container_data.get("components_v2") if isinstance(container_data, dict) else None
    if not builder_schema:
        builder_schema = data.get("components_v2") if isinstance(data.get("components_v2"), list) else None

    if isinstance(builder_schema, list) and len(builder_schema) > 0:
        from functions.components_v2_renderer import render_components_v2
        now = datetime.now()
        rendered = render_components_v2(builder_schema, {
            "date": now.strftime("%d/%m/%Y"),
            "time": now.strftime("%H:%M"),
            "server": channel.guild.name if channel.guild else "",
            "channel": channel.name,
        })
        if not rendered:
            return None
        msg = await channel.send(components=rendered, flags=disnake.MessageFlags(is_components_v2=True))
        return msg.id

    # Modo PLAIN: texto sem container
    if message_type == "plain":
        if not content:
            return None
        msg = await channel.send(content[:2000])
        return msg.id

    # Modo CONTAINER (default): Container V2 com embed-like data
    components = _build_components_simple(content, embed_data)
    msg = await channel.send(components=components, flags=disnake.MessageFlags(is_components_v2=True))
    return msg.id


async def _clear_previous(bot, data: dict):
    """Deleta a última mensagem enviada (se clear_previous estiver ativo)."""
    if not data.get("clear_previous"):
        return
    last_id = data.get("last_message_id")
    channel_id = data.get("channel_id")
    if not last_id or not channel_id:
        return
    try:
        ch_id = int(channel_id)
        channel = bot.get_channel(ch_id)
        if not channel:
            return
        msg = await channel.fetch_message(int(last_id))
        if msg:
            await msg.delete()
    except disnake.NotFound:
        pass
    except Exception as e:
        print(f"[AutoMessages] erro ao apagar mensagem anterior: {e}")


class AutoMessagesCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.auto_message_loop.is_running():
            self.auto_message_loop.start()

    def cog_unload(self):
        self.auto_message_loop.cancel()

    @tasks.loop(minutes=1)
    async def auto_message_loop(self):
        messages = AutoMessagesManager.get_messages()

        for msg_id, data in messages.items():
            if not data.get("enabled", False):
                continue

            interval_minutes = data.get("interval", 60)
            last_sent = data.get("last_sent", 0)
            now = datetime.now().timestamp()
            if now - last_sent < interval_minutes * 60:
                continue

            channel_id = data.get("channel_id")
            if not channel_id:
                continue

            try:
                ch_id = int(channel_id)
                channel = self.bot.get_channel(ch_id)
                if not channel:
                    continue

                # Apaga anterior se flag ativa
                await _clear_previous(self.bot, data)

                # Envia nova mensagem
                new_msg_id = await _send_auto_message(channel, data)

                data["last_sent"] = now
                if new_msg_id:
                    data["last_message_id"] = str(new_msg_id)
                AutoMessagesManager.save_message(msg_id, data)
            except Exception as e:
                print(f"Erro ao enviar mensagem automatica ({msg_id}): {e}")

    @auto_message_loop.before_loop
    async def before_auto_message_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(AutoMessagesCog(bot))
