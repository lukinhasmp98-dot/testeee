import disnake
from disnake.ext import commands, tasks
from functions.database import Database
from functions import log_reporter
from datetime import datetime, timedelta


class AutoNukeManager:
    @staticmethod
    def get_configs() -> dict:
        return Database.get_document("auto_nuke") or {}

    @staticmethod
    def save_config(nuke_id: str, data: dict):
        configs = AutoNukeManager.get_configs()
        configs[nuke_id] = data
        Database.save_document("auto_nuke", configs)


class AutoNukeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.nuke_loop.is_running():
            self.nuke_loop.start()

    def cog_unload(self):
        self.nuke_loop.cancel()

    @tasks.loop(minutes=1)
    async def nuke_loop(self):
        configs = AutoNukeManager.get_configs()
        now_dt = datetime.now()
        now = now_dt.timestamp()

        for nuke_id, data in configs.items():
            if not data.get("enabled", False):
                continue

            mode = data.get("mode", "interval")
            last_nuke = data.get("last_nuke", 0)

            if mode == "schedule":
                schedule_time = data.get("schedule_time", "00:00")
                try:
                    h_str, m_str = schedule_time.split(":")
                    sched_h, sched_m = int(h_str), int(m_str)
                except (ValueError, AttributeError):
                    log_reporter.error(f"Auto Nuke '{nuke_id}' schedule_time inválido: {schedule_time}", "AUTO_NUKE")
                    continue
                target_today = now_dt.replace(hour=sched_h, minute=sched_m, second=0, microsecond=0)
                # Janela de 5min após o horário agendado — evita disparar imediato
                # quando o bot é iniciado depois do horário (last_nuke=0 +
                # target_today < now passa a checagem antiga e disparava na hora).
                window_end = target_today + timedelta(minutes=5)
                if not (target_today <= now_dt <= window_end):
                    continue
                # Já executou hoje?
                if last_nuke and last_nuke >= target_today.timestamp():
                    continue
            else:
                interval_value = data.get("interval", 24)
                interval_unit = data.get("interval_unit", "hours")
                unit_seconds = {"minutes": 60, "hours": 3600, "days": 86400}.get(interval_unit, 3600)
                interval_seconds = interval_value * unit_seconds
                if now - last_nuke < interval_seconds:
                    continue

            channel_id = data.get("channel_id")
            if not channel_id:
                log_reporter.warn(f"Auto Nuke '{nuke_id}' sem canal configurado", "AUTO_NUKE")
                continue

            try:
                ch_id = int(channel_id)
            except (TypeError, ValueError):
                log_reporter.error(f"Auto Nuke '{nuke_id}' channel_id inválido: {channel_id}", "AUTO_NUKE")
                continue

            channel = self.bot.get_channel(ch_id)
            if channel is None:
                log_reporter.warn(f"Auto Nuke '{nuke_id}' canal {ch_id} não encontrado (deletado manualmente?)", "AUTO_NUKE")
                continue

            try:
                position = channel.position
                new_channel = await channel.clone(reason="Auto Nuke")
                await channel.delete(reason="Auto Nuke")
                await new_channel.edit(position=position)

                data["channel_id"] = str(new_channel.id)
                data["last_nuke"] = now
                AutoNukeManager.save_config(nuke_id, data)

                try:
                    import time as _time
                    ts = int(_time.time())
                    if mode == "schedule":
                        schedule_label = f"Diariamente às {data.get('schedule_time', '00:00')}"
                    else:
                        units_pt = {
                            "minutes": ("minuto", "minutos"),
                            "hours": ("hora", "horas"),
                            "days": ("dia", "dias"),
                        }
                        sing, plur = units_pt.get(data.get("interval_unit", "hours"), ("hora", "horas"))
                        iv = data.get("interval", 24)
                        schedule_label = f"A cada {iv} {sing if iv == 1 else plur}"
                    await new_channel.send(
                        components=[
                            disnake.ui.Container(
                                disnake.ui.TextDisplay("# Canal Resetado\n-# Auto Nuke"),
                                disnake.ui.Separator(),
                                disnake.ui.TextDisplay(
                                    "**Informações**\n"
                                    f"-# Frequência: {schedule_label}\n"
                                    f"-# Executado em: <t:{ts}:F>"
                                ),
                            )
                        ],
                        flags=disnake.MessageFlags(is_components_v2=True),
                        allowed_mentions=disnake.AllowedMentions.none(),
                    )
                except Exception as send_err:
                    log_reporter.warn(f"Auto Nuke '{nuke_id}' não conseguiu enviar aviso no canal {new_channel.id}: {send_err}", "AUTO_NUKE")
            except disnake.Forbidden as e:
                log_reporter.error(f"Auto Nuke '{nuke_id}' sem permissão no canal {ch_id}: {e}", "AUTO_NUKE")
            except Exception as e:
                log_reporter.error(f"Auto Nuke '{nuke_id}' falhou no canal {ch_id}: {e}", "AUTO_NUKE")

    @nuke_loop.before_loop
    async def before_nuke_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(AutoNukeCog(bot))
