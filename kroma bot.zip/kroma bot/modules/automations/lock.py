"""Auto-lock/unlock de canais por horário.

Em vez de só agir no minuto exato (que falha se o loop atrasar 1s),
calcula a cada tick se o canal *deveria* estar travado agora e converge
pro estado certo. Só anuncia no canal quando há transição real.
"""

import disnake
from disnake.ext import commands, tasks
from datetime import datetime, time

from functions.database import Database


def _parse_hhmm(s) -> time | None:
    try:
        if not s or not isinstance(s, str):
            return None
        h, m = s.split(":")
        return time(int(h) % 24, int(m) % 60)
    except Exception:
        return None


def _is_locked_now(now: time, lock_t: time, unlock_t: time) -> bool:
    """Considera lock_time e unlock_time como bordas circulares (24h)."""
    if lock_t == unlock_t:
        return False
    if lock_t < unlock_t:
        return lock_t <= now < unlock_t
    return now >= lock_t or now < unlock_t


class AutoLockCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_state: dict[str, bool] = {}

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.lock_loop.is_running():
            self.lock_loop.start()

    def cog_unload(self):
        self.lock_loop.cancel()

    @tasks.loop(seconds=30)
    async def lock_loop(self):
        configs = Database.get_document("auto_lock") or {}
        now = datetime.now().time()

        for lock_id, data in configs.items():
            try:
                if not isinstance(data, dict) or not data.get("enabled", False):
                    continue

                channel_id = data.get("channel_id")
                lock_t = _parse_hhmm(data.get("lock_time"))
                unlock_t = _parse_hhmm(data.get("unlock_time"))
                if not channel_id or not lock_t or not unlock_t:
                    continue

                ch_id = int(channel_id)
                channel = self.bot.get_channel(ch_id)
                if not channel:
                    continue

                guild = channel.guild
                overwrite = channel.overwrites_for(guild.default_role)
                currently_locked = overwrite.send_messages is False
                should_lock = _is_locked_now(now, lock_t, unlock_t)

                state_key = f"{lock_id}:{ch_id}"
                last_known = self._last_state.get(state_key)

                if should_lock and not currently_locked:
                    overwrite.send_messages = False
                    await channel.set_permissions(guild.default_role, overwrite=overwrite, reason="Auto Lock")
                    if last_known is not True:
                        try:
                            await channel.send(
                                components=[disnake.ui.Container(
                                    disnake.ui.TextDisplay("# 🔒 Canal Bloqueado\n-# Os membros não podem mais enviar mensagens neste canal."),
                                    disnake.ui.Separator(),
                                    disnake.ui.TextDisplay(f"O canal será reaberto às **{data.get('unlock_time')}**."),
                                )],
                                flags=disnake.MessageFlags(is_components_v2=True),
                            )
                        except Exception as send_err:
                            print(f"[AutoLock] erro ao avisar bloqueio: {send_err}")
                    self._last_state[state_key] = True
                    print(f"[AutoLock] Canal {channel.name} bloqueado")

                elif (not should_lock) and currently_locked:
                    overwrite.send_messages = None
                    await channel.set_permissions(guild.default_role, overwrite=overwrite, reason="Auto Unlock")
                    if last_known is not False:
                        try:
                            await channel.send(
                                components=[disnake.ui.Container(
                                    disnake.ui.TextDisplay("# 🔓 Canal Desbloqueado\n-# Os membros já podem voltar a conversar."),
                                    disnake.ui.Separator(),
                                    disnake.ui.TextDisplay(f"O canal será bloqueado novamente às **{data.get('lock_time')}**."),
                                )],
                                flags=disnake.MessageFlags(is_components_v2=True),
                            )
                        except Exception as send_err:
                            print(f"[AutoLock] erro ao avisar desbloqueio: {send_err}")
                    self._last_state[state_key] = False
                    print(f"[AutoLock] Canal {channel.name} desbloqueado")

                else:
                    self._last_state[state_key] = currently_locked

            except Exception as e:
                print(f"[AutoLock] Erro processando {lock_id}: {e}")

    @lock_loop.before_loop
    async def before_lock_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(AutoLockCog(bot))
