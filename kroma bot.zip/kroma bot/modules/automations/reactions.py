"""
Sistema de Reacoes Automaticas (runtime)
Adiciona reacoes automaticas a mensagens em canais especificos conforme config
salva via dashboard web.

Super Reactions (burst): exige token de SELFBOT com Nitro. Cada reação tem
seu próprio campo `super_token` configurado pela dashboard. Como fallback de
compat, ainda lê `vip_config.super_reaction_token`.
"""
import asyncio

import aiohttp
import disnake
from disnake.ext import commands
from functions.database import Database

# Reusa o helper que já tava no VIP (raw HTTP com token de selfbot)
from modules.vip.reactions import _apply_super_reaction, _parse_emoji
from modules.vip.manager import VipManager


class AutoReactionsManager:
    @staticmethod
    def get_reactions() -> dict:
        return Database.get_document("auto_reactions") or {}


class AutoReactionsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot:
            return
        if message.guild is None:
            return

        reactions = AutoReactionsManager.get_reactions()
        if not reactions:
            return

        # Fallback global (compat antiga). Cada reação pode sobrescrever via super_token.
        config = VipManager.get_config()
        fallback_super_token = (config.get("super_reaction_token") or "").strip() or None

        session: aiohttp.ClientSession | None = None

        try:
            for _react_id, data in reactions.items():
                if not data.get("enabled", False):
                    continue

                channel_id = data.get("channel_id")
                try:
                    ch_id = int(channel_id) if channel_id else None
                except (ValueError, TypeError):
                    continue
                if message.channel.id != ch_id:
                    continue

                emojis = data.get("emojis", [])
                per_token = (data.get("super_token") or "").strip() or None
                super_token = per_token or fallback_super_token
                wants_super = bool(data.get("super", False)) and super_token is not None

                for i, emoji_str in enumerate(emojis):
                    applied_super = False
                    if wants_super:
                        if session is None:
                            session = aiohttp.ClientSession()
                        applied_super = await _apply_super_reaction(
                            session, super_token, message.channel.id, message.id, emoji_str
                        )

                    if not applied_super:
                        # Fallback pra reação normal via bot
                        emoji = _parse_emoji(emoji_str, self.bot)
                        if emoji is None:
                            continue
                        try:
                            await message.add_reaction(emoji)
                        except disnake.HTTPException as e:
                            print(f"[AUTO REACTIONS] Falha add_reaction {emoji_str}: {e}")
                        except Exception as e:
                            print(f"[AUTO REACTIONS] Erro inesperado: {e}")

                    # Pequeno delay entre reactions pra evitar rate-limit
                    if i < len(emojis) - 1:
                        await asyncio.sleep(0.25)
        finally:
            if session is not None:
                await session.close()


def setup(bot: commands.Bot):
    bot.add_cog(AutoReactionsCog(bot))
