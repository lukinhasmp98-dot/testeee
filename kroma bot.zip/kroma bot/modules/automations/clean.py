import disnake
from disnake.ext import commands, tasks
from functions.database import Database
from functions import log_reporter
from datetime import datetime, timedelta


class AutoCleanManager:
    @staticmethod
    def get_configs() -> dict:
        return Database.get_document("auto_clean") or {}

    @staticmethod
    def save_config(clean_id: str, data: dict):
        configs = AutoCleanManager.get_configs()
        configs[clean_id] = data
        Database.save_document("auto_clean", configs)


class AutoCleanCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.clean_loop.is_running():
            self.clean_loop.start()

    def cog_unload(self):
        self.clean_loop.cancel()

    @tasks.loop(minutes=1)
    async def clean_loop(self):
        configs = AutoCleanManager.get_configs()
        now_dt = datetime.now()
        now = now_dt.timestamp()

        for clean_id, data in configs.items():
            if not data.get("enabled", False):
                continue

            mode = data.get("mode", "interval")
            last_clean = data.get("last_clean", 0)

            if mode == "schedule":
                schedule_time = data.get("schedule_time", "00:00")
                try:
                    h_str, m_str = schedule_time.split(":")
                    sched_h, sched_m = int(h_str), int(m_str)
                except (ValueError, AttributeError):
                    log_reporter.error(f"Auto Clean '{clean_id}' schedule_time inválido: {schedule_time}", "AUTO_CLEAN")
                    continue
                target_today = now_dt.replace(hour=sched_h, minute=sched_m, second=0, microsecond=0)
                # Janela de 5min — não dispara imediato quando bot inicia depois do horário
                window_end = target_today + timedelta(minutes=5)
                if not (target_today <= now_dt <= window_end):
                    continue
                if last_clean and last_clean >= target_today.timestamp():
                    continue
            else:
                interval_value = data.get("interval", 24)
                interval_unit = data.get("interval_unit", "hours")
                unit_seconds = {"minutes": 60, "hours": 3600, "days": 86400}.get(interval_unit, 3600)
                interval_seconds = interval_value * unit_seconds
                if now - last_clean < interval_seconds:
                    continue

            channel_id = data.get("channel_id")
            if not channel_id:
                log_reporter.warn(f"Auto Clean '{clean_id}' sem canal configurado", "AUTO_CLEAN")
                continue

            try:
                ch_id = int(channel_id)
            except (TypeError, ValueError):
                log_reporter.error(f"Auto Clean '{clean_id}' channel_id inválido: {channel_id}", "AUTO_CLEAN")
                continue

            channel = self.bot.get_channel(ch_id)
            if channel is None:
                log_reporter.warn(f"Auto Clean '{clean_id}' canal {ch_id} não encontrado", "AUTO_CLEAN")
                continue

            try:
                await channel.purge(limit=1000, reason="Auto Clean")
                data["last_clean"] = now
                AutoCleanManager.save_config(clean_id, data)
            except disnake.Forbidden as e:
                log_reporter.error(f"Auto Clean '{clean_id}' sem permissão no canal {ch_id}: {e}", "AUTO_CLEAN")
            except Exception as e:
                log_reporter.error(f"Auto Clean '{clean_id}' falhou no canal {ch_id}: {e}", "AUTO_CLEAN")

    @clean_loop.before_loop
    async def before_clean_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(AutoCleanCog(bot))
