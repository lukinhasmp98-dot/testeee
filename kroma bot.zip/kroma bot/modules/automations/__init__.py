def setup(bot):
    bot.load_extension("modules.automations.messages")
    bot.load_extension("modules.automations.reactions")
    bot.load_extension("modules.automations.responses")
    bot.load_extension("modules.automations.nuke")
    bot.load_extension("modules.automations.clean")
    bot.load_extension("modules.automations.lock")
    bot.load_extension("modules.automations.suggestions")
