"""
Sistema de Sugestões automático.
Em canais configurados, transforma mensagens em sugestões formatadas:
- Apaga a mensagem original
- Posta um Container V2 com título + conteúdo + botões de voto (com contadores)
- Cria thread automática pra discussão
- Botão "Moderar" pra cargos manager_roles → aprovar/reprovar/apagar

Config: doc `auto_suggestions` no DB do bot — múltiplos canais via dict de items.
Cada item: {
  enabled, channel_id, ignored_roles[], manager_roles[],
  auto_thread, require_text
}

Dados das sugestões: doc `auto_suggestions_data` — { suggestions: { [id]: {...} } }
"""
import re
import uuid

import disnake
from disnake.ext import commands
from functions.database import Database


class AutoSuggestionsManager:
    @staticmethod
    def get_all() -> dict:
        return Database.get_document("auto_suggestions") or {}

    @staticmethod
    def get_data() -> dict:
        return Database.get_document("auto_suggestions_data") or {"suggestions": {}}

    @staticmethod
    def save_data(data: dict):
        Database.save_document("auto_suggestions_data", data)


_STYLE_MAP = {
    "success": disnake.ButtonStyle.green,
    "danger": disnake.ButtonStyle.red,
    "primary": disnake.ButtonStyle.blurple,
    "secondary": disnake.ButtonStyle.grey,
}

_EMOJI_CUSTOM_RE = re.compile(r"<(a?):(\w+):(\d+)>")


def _emoji_for_button(emoji_str):
    if not emoji_str:
        return None
    s = str(emoji_str).strip()
    if not s:
        return None
    m = _EMOJI_CUSTOM_RE.match(s)
    if m:
        animated = m.group(1) == "a"
        try:
            eid = int(m.group(3))
        except (TypeError, ValueError):
            return None
        try:
            return disnake.PartialEmoji(name=m.group(2), id=eid, animated=animated)
        except Exception:
            return None
    return s  # unicode


def _btn_kwargs(cfg, count, default_label, default_emoji, default_style, custom_id):
    cfg = cfg or {}
    display = cfg.get("display") or "name"
    label = (cfg.get("label") or default_label).strip() or default_label
    emoji_raw = cfg.get("emoji") if cfg.get("emoji") is not None else default_emoji
    style = _STYLE_MAP.get(cfg.get("style") or default_style, _STYLE_MAP[default_style])

    kwargs = {"style": style, "custom_id": custom_id}
    if display == "emoji":
        kwargs["label"] = f"({count})"
        emoji_obj = _emoji_for_button(emoji_raw)
        if emoji_obj is not None:
            kwargs["emoji"] = emoji_obj
        else:
            kwargs["label"] = f"{label} ({count})"
    elif display == "both":
        kwargs["label"] = f"{label} ({count})"
        emoji_obj = _emoji_for_button(emoji_raw)
        if emoji_obj is not None:
            kwargs["emoji"] = emoji_obj
    else:
        kwargs["label"] = f"{label} ({count})"
    return kwargs


def _build_suggestion_components(s_id: str, suggestion: dict, author_name: str, cfg: dict | None = None) -> list:
    status = suggestion.get("status", "aberta")
    upvotes = len(suggestion.get("upvotes", []))
    downvotes = len(suggestion.get("downvotes", []))
    content = suggestion.get("content", "")
    cfg = cfg or {}

    titles = {
        "aberta": f"### **Sugestão de {author_name}**",
        "aprovada": f"### **✅ Sugestão de {author_name} (APROVADA)**",
        "reprovada": f"### **❌ Sugestão de {author_name} (REPROVADA)**",
    }

    up = _btn_kwargs(cfg.get("button_up"), upvotes, "Sim", "👍", "success", f"AS_VoteUp:{s_id}")
    down = _btn_kwargs(cfg.get("button_down"), downvotes, "Não", "👎", "danger", f"AS_VoteDown:{s_id}")

    return [
        disnake.ui.Container(
            disnake.ui.TextDisplay(titles.get(status, titles["aberta"])),
            disnake.ui.TextDisplay(f"```\n{content}\n```"),
            disnake.ui.Separator(),
            disnake.ui.ActionRow(
                disnake.ui.Button(**up),
                disnake.ui.Button(**down),
                disnake.ui.Button(label="Moderar", style=disnake.ButtonStyle.grey, custom_id=f"AS_ModMenu:{s_id}"),
            ),
        )
    ]


class AutoSuggestionsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _config_for_channel(self, channel_id: int) -> dict | None:
        for _id, data in AutoSuggestionsManager.get_all().items():
            if not data.get("enabled", False):
                continue
            try:
                cfg_ch = int(data.get("channel_id") or 0)
            except (ValueError, TypeError):
                continue
            if cfg_ch == channel_id:
                return data
        return None

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot or message.guild is None:
            return
        if message.components:
            return  # ignora msgs já com components (nossas próprias)

        cfg = self._config_for_channel(message.channel.id)
        if not cfg:
            return

        # Cargos ignorados
        ignored = [str(r) for r in cfg.get("ignored_roles", [])]
        if ignored:
            user_role_ids = {str(r.id) for r in getattr(message.author, "roles", [])}
            if user_role_ids & set(ignored):
                return

        content = (message.content or "").strip()
        if cfg.get("require_text", True) and not content:
            return
        if not content:
            return

        # Apaga msg original
        try:
            await message.delete()
        except Exception:
            pass

        s_id = str(uuid.uuid4())[:8]
        s_data = AutoSuggestionsManager.get_data()
        s_data.setdefault("suggestions", {})[s_id] = {
            "author_id": message.author.id,
            "content": content,
            "upvotes": [],
            "downvotes": [],
            "status": "aberta",
            "channel_id": message.channel.id,
            "guild_id": message.guild.id,
        }
        AutoSuggestionsManager.save_data(s_data)

        author_name = message.author.display_name
        components = _build_suggestion_components(s_id, s_data["suggestions"][s_id], author_name, cfg)

        try:
            sent = await message.channel.send(
                components=components,
                flags=disnake.MessageFlags(is_components_v2=True),
            )
        except disnake.HTTPException as e:
            print(f"[AUTO SUGGESTIONS] Falha ao enviar: {e}")
            return

        # Atualiza com message_id e cria thread
        s_data = AutoSuggestionsManager.get_data()
        if s_id in s_data.get("suggestions", {}):
            s_data["suggestions"][s_id]["message_id"] = sent.id
            AutoSuggestionsManager.save_data(s_data)

        if cfg.get("auto_thread", True):
            try:
                title = (content[:97] + "…") if len(content) > 100 else content
                if not title:
                    title = f"Sugestão {s_id}"
                await sent.create_thread(name=title, auto_archive_duration=1440)
            except Exception as e:
                print(f"[AUTO SUGGESTIONS] Falha thread: {e}")

    @commands.Cog.listener("on_button_click")
    async def on_button(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id or ""
        if not cid.startswith("AS_"):
            return

        parts = cid.split(":")
        action = parts[0]
        s_id = parts[1] if len(parts) > 1 else ""

        s_data = AutoSuggestionsManager.get_data()
        suggestion = s_data.get("suggestions", {}).get(s_id)
        if not suggestion and action != "AS_ModMenu":
            return await inter.response.send_message("Sugestão não encontrada.", ephemeral=True)

        cfg = self._config_for_channel(inter.channel.id) or {}

        if action == "AS_ModMenu":
            manager_roles = [str(r) for r in cfg.get("manager_roles", [])]
            user_role_ids = {str(r.id) for r in getattr(inter.author, "roles", [])}
            is_admin = inter.author.guild_permissions.manage_guild
            if not is_admin and not (user_role_ids & set(manager_roles)):
                return await inter.response.send_message(
                    "❌ Você não tem permissão pra moderar sugestões.", ephemeral=True
                )
            mod_components = [
                disnake.ui.Container(
                    disnake.ui.TextDisplay(f"# Moderar Sugestão\n-# ID: `{s_id}`"),
                    disnake.ui.Separator(),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(label="Aprovar", style=disnake.ButtonStyle.green, custom_id=f"AS_Approve:{s_id}"),
                        disnake.ui.Button(label="Reprovar", style=disnake.ButtonStyle.red, custom_id=f"AS_Reject:{s_id}"),
                        disnake.ui.Button(label="Apagar", style=disnake.ButtonStyle.grey, custom_id=f"AS_Delete:{s_id}"),
                    ),
                )
            ]
            return await inter.response.send_message(
                components=mod_components,
                flags=disnake.MessageFlags(is_components_v2=True),
                ephemeral=True,
            )

        if action in ("AS_VoteUp", "AS_VoteDown"):
            uid = inter.author.id
            upvotes = set(suggestion.get("upvotes", []))
            downvotes = set(suggestion.get("downvotes", []))
            if action == "AS_VoteUp":
                if uid in upvotes:
                    upvotes.remove(uid)
                else:
                    upvotes.add(uid)
                    downvotes.discard(uid)
            else:
                if uid in downvotes:
                    downvotes.remove(uid)
                else:
                    downvotes.add(uid)
                    upvotes.discard(uid)
            suggestion["upvotes"] = list(upvotes)
            suggestion["downvotes"] = list(downvotes)
            AutoSuggestionsManager.save_data(s_data)

            author = inter.guild.get_member(suggestion.get("author_id")) if inter.guild else None
            author_name = author.display_name if author else "Usuário"
            components = _build_suggestion_components(s_id, suggestion, author_name, cfg)
            try:
                await inter.response.edit_message(
                    components=components,
                    flags=disnake.MessageFlags(is_components_v2=True),
                )
            except Exception as e:
                print(f"[AUTO SUGGESTIONS] edit_message: {e}")
            return

        # Moderação requer permissão
        manager_roles = [str(r) for r in cfg.get("manager_roles", [])]
        user_role_ids = {str(r.id) for r in getattr(inter.author, "roles", [])}
        is_admin = inter.author.guild_permissions.manage_guild
        if not is_admin and not (user_role_ids & set(manager_roles)):
            return await inter.response.send_message("❌ Sem permissão.", ephemeral=True)

        if action == "AS_Approve":
            suggestion["status"] = "aprovada"
        elif action == "AS_Reject":
            suggestion["status"] = "reprovada"
        elif action == "AS_Delete":
            try:
                channel = self.bot.get_channel(suggestion.get("channel_id") or inter.channel.id)
                if channel:
                    msg = await channel.fetch_message(suggestion["message_id"])
                    if msg.thread:
                        await msg.thread.delete()
                    await msg.delete()
            except Exception:
                pass
            del s_data["suggestions"][s_id]
            AutoSuggestionsManager.save_data(s_data)
            return await inter.response.edit_message(
                components=[disnake.ui.Container(disnake.ui.TextDisplay("🗑️ Sugestão apagada."))],
                flags=disnake.MessageFlags(is_components_v2=True),
            )

        AutoSuggestionsManager.save_data(s_data)

        try:
            channel = self.bot.get_channel(suggestion.get("channel_id") or inter.channel.id)
            if channel:
                orig = await channel.fetch_message(suggestion["message_id"])
                author = inter.guild.get_member(suggestion.get("author_id")) if inter.guild else None
                author_name = author.display_name if author else "Usuário"
                components = _build_suggestion_components(s_id, suggestion, author_name, cfg)
                await orig.edit(components=components, flags=disnake.MessageFlags(is_components_v2=True))
        except Exception as e:
            print(f"[AUTO SUGGESTIONS] update orig: {e}")

        label = "aprovada" if action == "AS_Approve" else "reprovada"
        await inter.response.edit_message(
            components=[disnake.ui.Container(disnake.ui.TextDisplay(f"✅ Sugestão {label}!"))],
            flags=disnake.MessageFlags(is_components_v2=True),
        )


def setup(bot: commands.Bot):
    bot.add_cog(AutoSuggestionsCog(bot))
