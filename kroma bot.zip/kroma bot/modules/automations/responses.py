"""
Sistema de Respostas Automaticas (runtime)
Responde automaticamente quando detecta palavras-chave em mensagens.
Config via dashboard web.
"""
import disnake
from disnake.ext import commands
from functions.database import Database


class AutoResponsesManager:
    @staticmethod
    def get_responses() -> dict:
        return Database.get_document("auto_responses") or {}


class AutoResponsesCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot:
            return

        responses = AutoResponsesManager.get_responses()

        for _resp_id, data in responses.items():
            if not data.get("enabled", False):
                continue

            trigger = data.get("trigger", "").lower()
            if trigger and trigger in message.content.lower():
                response_text = data.get("response", "Resposta automatica")

                try:
                    await message.reply(response_text)
                except Exception as e:
                    print(f"Erro ao enviar resposta: {e}")


def setup(bot: commands.Bot):
    bot.add_cog(AutoResponsesCog(bot))
