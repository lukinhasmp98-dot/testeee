"""Configuração completa de atendimento da Kroma, toda feita dentro do Discord."""
from datetime import datetime
from decimal import Decimal, InvalidOperation
import disnake
from disnake.ext import commands
from functions.database import Database
from functions.permissions import Permissions

FLAGS=disnake.MessageFlags(is_components_v2=True); ACCENT=disnake.Colour(0x43DBD0); ERROR=disnake.Colour.red()
def row(*items): return disnake.ui.ActionRow(*items)
def btn(label,key,style=disnake.ButtonStyle.secondary): return disnake.ui.Button(label=label,custom_id=key,style=style)
def selected(inter): return str(getattr(inter.values[0],"id",inter.values[0]))
def card(title,text,color=ACCENT): return [disnake.ui.Container(disnake.ui.TextDisplay(f"# {title}"),disnake.ui.Separator(),disnake.ui.TextDisplay(text),accent_colour=color)]
async def guard(inter):
    if await Permissions.check_user(inter.user.id): return True
    await inter.response.send_message(components=card("ACESSO RESTRITO","A Central é exclusiva da administração.",ERROR),flags=FLAGS,ephemeral=True); return False

def default_setup(): return {"title":"Central de Atendimento","intro":"Escolha abaixo o atendimento que você precisa. Nossa equipe responderá de forma privada.","banner":"","logo":"","accent":"#43DBD0","hours":{"enabled":False,"start":"10:00","end":"20:00","days":[0,1,2,3,4,5,6]},"options":[{"id":"orcamento","name":"Orçamento","short":"Quero pedir uma arte","description":"Envie briefing, referências e prazo desejado.","button":"Solicitar orçamento","style":"blurple"},{"id":"pedido","name":"Pedido","short":"Quero acompanhar uma arte","description":"Consulte andamento, envie ajustes ou materiais.","button":"Acompanhar pedido","style":"blurple"},{"id":"suporte","name":"Suporte","short":"Tenho uma dúvida","description":"Pagamento manual, prazos e suporte geral.","button":"Abrir suporte","style":"grey"}]}
def setup_data():
    saved=Database.get_document("kroma_ticket_setup") or {}; base=default_setup()
    for key,value in base.items(): saved.setdefault(key,value)
    return saved
def save_setup(data): Database.save_document("kroma_ticket_setup",data)
def chosen(data): return next((x for x in data["options"] if x["id"]==data.get("selected")),data["options"][0] if data["options"] else None)
def catalog_data():
 data=Database.get_document("kroma_catalog") or {}
 if data.get("items"):return data
 data={"items":[
  {"id":"gifs","name":"GIFs","type":"Serviço","description":"Arte animada","price":25},{"id":"logotipo","name":"LogoTipo","type":"Serviço","description":"Logo personalizada","price":15},{"id":"banner","name":"Banner","type":"Serviço","description":"Banner personalizado","price":19},{"id":"banner_youtube","name":"Banner (Capa YouTuber)","type":"Serviço","description":"Capa para YouTube","price":14},{"id":"barrinha","name":"Barrinha","type":"Serviço","description":"Barra visual","price":7},{"id":"thumbnail","name":"Thumbnail","type":"Serviço","description":"Thumbnail personalizada","price":15},{"id":"flyer","name":"Flyer","type":"Serviço","description":"Flyer de divulgação","price":20},
  {"id":"streamer","name":"Pacote Streamer","type":"Pacote","description":"Identidade visual para streamer","price":60},{"id":"youtuber","name":"Pacote YouTuber","type":"Pacote","description":"Artes para canal do YouTube","price":30},{"id":"server","name":"Pacote Server","type":"Pacote","description":"Kit visual para servidor","price":25},{"id":"server_premium","name":"Pacote Server Premium","type":"Pacote","description":"Kit completo + artes adicionais","price":65},{"id":"identidade","name":"Pacote Identidade","type":"Pacote","description":"Logo + Banner + Barrinha","price":40},{"id":"creator","name":"Pacote Creator","type":"Pacote","description":"Logo + Banner YouTuber + Thumbnail + Barrinha","price":45},{"id":"divulgacao","name":"Pacote Divulgação","type":"Pacote","description":"Banner + Flyer + Thumbnail","price":50},{"id":"completo","name":"Pacote Completo","type":"Pacote","description":"Logo + Banner + Barrinha + Flyer + Thumbnail","price":75},{"id":"fivem","name":"Pacote FiveM","type":"Pacote","description":"Kit visual para servidor FiveM","price":55}
 ]};Database.save_document("kroma_catalog",data);return data
def price(value):return f"R$ {Decimal(str(value)).quantize(Decimal('0.01')):,.2f}".replace(",","X").replace(".",",").replace("X",".")

def home(): return card("KROMA STUDIO / OPERAÇÃO","Configure atendimento, fila, preços, PIX e portfólio em um único lugar.")+[row(btn("Tickets","Kroma:tickets",disnake.ButtonStyle.primary),btn("Fila de artes","Kroma:queue",disnake.ButtonStyle.primary),btn("Preços","Kroma:prices",disnake.ButtonStyle.primary)),row(btn("PIX manual","Kroma:pix",disnake.ButtonStyle.primary),btn("Portfólio","Kroma:portfolio",disnake.ButtonStyle.primary),btn("Atualizar","Kroma:home"))]
def prices_page():
 data=catalog_data(); services=[x for x in data["items"] if x["type"]=="Serviço"];packs=[x for x in data["items"] if x["type"]=="Pacote"]
 lines=["**SERVIÇOS**"]+[f"`{x['name']}` · **{price(x['price'])}**" for x in services]+["\n**PACOTES**"]+[f"`{x['name']}` · **{price(x['price'])}**\n-# {x['description']}" for x in packs]
 selected_id=data.get("selected");options=[disnake.SelectOption(label=x["name"][:100],description=f"{x['type']} · {price(x['price'])}"[:100],value=x["id"],default=x["id"]==selected_id) for x in data["items"][:25]]
 return card("TABELA DE PREÇOS / KROMA STUDIO","\n".join(lines))+[row(disnake.ui.StringSelect(custom_id="Kroma:price-select",placeholder="Selecionar item para editar",options=options)),row(btn("Adicionar item","Kroma:price-add",disnake.ButtonStyle.success),btn("Editar selecionado","Kroma:price-edit",disnake.ButtonStyle.primary),btn("Remover selecionado","Kroma:price-remove",disnake.ButtonStyle.danger)),row(btn("Voltar","Kroma:home"))]
def ticket_page():
    d=setup_data(); h=d["hours"]; item=chosen(d); channel=f'<#{d.get("channel_id")}>' if d.get("channel_id") else "`não escolhido`"; cat=f'<#{d.get("category_id")}>' if d.get("category_id") else "`não escolhida`"; time=f"**ATIVO** · `{h['start']}` às `{h['end']}`" if h.get("enabled") else "**LIVRE**"; detail=f"**{item['name']}**\nPré-descrição: `{item['short']}`\nDescrição: {item['description']}\nBotão: `{item['button']}`" if item else "Nenhuma função cadastrada."
    result=card("TICKETS / CENTRAL DE ATENDIMENTO",f"**PAINEL PÚBLICO**\nCanal: {channel}\nCategoria: {cat}\nEquipe: `{len(d.get('staff_roles',[]))}` cargo(s)\n\n**HORÁRIOS**\n{time}\n\n**FUNÇÃO SELECIONADA**\n{detail}\n\n-# Aparência, banner, horários e cada função podem ser alterados abaixo.")
    result += [row(disnake.ui.ChannelSelect(custom_id="Kroma:channel",placeholder="Canal do painel",channel_types=[disnake.ChannelType.text])),row(disnake.ui.ChannelSelect(custom_id="Kroma:category",placeholder="Categoria dos tickets",channel_types=[disnake.ChannelType.category])),row(disnake.ui.RoleSelect(custom_id="Kroma:roles",placeholder="Cargos da equipe",min_values=1,max_values=10))]
    if d["options"]: result.append(row(disnake.ui.StringSelect(custom_id="Kroma:select",placeholder="Selecionar função",options=[disnake.SelectOption(label=x["name"][:100],description=x["short"][:100],value=x["id"],default=x["id"]==d.get("selected")) for x in d["options"][:25]])))
    result += [row(btn("Definir aparência","Kroma:appearance",disnake.ButtonStyle.primary),btn("Configurar horários","Kroma:hours",disnake.ButtonStyle.primary)),row(btn("Adicionar função","Kroma:add",disnake.ButtonStyle.success),btn("Editar função","Kroma:edit",disnake.ButtonStyle.primary),btn("Mídia da função","Kroma:media"),btn("Remover função","Kroma:remove",disnake.ButtonStyle.danger)),row(btn("Postar","Kroma:post",disnake.ButtonStyle.success),btn("Sincronizar","Kroma:sync"),btn("Voltar","Kroma:home"))]
    return result

def pix_page():
    d=Database.get_config().get("manual_pix",{}); key=str(d.get("key") or ""); masked=f"{key[:3]}••••{key[-3:]}" if len(key)>6 else ("configurada" if key else "não configurada")
    return card("PIX MANUAL / CONFIGURAÇÃO",f"Status: **{'ATIVO' if d.get('enabled') else 'INATIVO'}**\nRecebedor: **{d.get('recipient') or 'Kroma Studio'}**\nChave: `{masked}`")+[row(btn("Editar chave","Kroma:pix-edit",disnake.ButtonStyle.primary),btn("Ativar / desativar","Kroma:pix-toggle"),btn("Voltar","Kroma:home"))]
def queue_page():
    data=Database.get_document("kroma_art_queue") or {}; channel=f'<#{data.get("channel_id")}>' if data.get("channel_id") else "`não escolhido`"; count=len([x for x in data.get("entries",[]) if x.get("status")=="fila"]); producing=len([x for x in data.get("entries",[]) if x.get("status")=="em_producao"])
    return card("FILA DE ARTES / CONFIGURAÇÃO",f"Canal da fila: {channel}\nAguardando: `{count}` · Em produção: `{producing}`\n\n-# Clientes entram aqui somente quando a equipe confirma o PIX de um ticket de orçamento. A equipe usa **Iniciar produção** no ticket e `/entregar_arte` ao finalizar.")+[row(disnake.ui.ChannelSelect(custom_id="Kroma:queue-channel",placeholder="Canal público da fila",channel_types=[disnake.ChannelType.text])),row(btn("Definir aparência","Kroma:queue-appearance",disnake.ButtonStyle.primary),btn("Publicar / atualizar fila","Kroma:queue-sync",disnake.ButtonStyle.success),btn("Voltar","Kroma:home"))]
def portfolio_page():
    data=Database.get_document("kroma_portfolio") or {}; channel=f'<#{data.get("channel_id")}>' if data.get("channel_id") else "`não escolhido`"; title=data.get("title") or "PORTFÓLIO / KROMA STUDIO"
    return card("PORTFÓLIO / CONFIGURAÇÃO",f"Canal de publicação: {channel}\nTítulo: **{title}**\n\n-# Quando a equipe usar `/entregar_arte` dentro de um orçamento pago, a imagem será enviada para este canal e o pedido sairá da fila.")+[row(disnake.ui.ChannelSelect(custom_id="Kroma:portfolio-channel",placeholder="Canal público do portfólio",channel_types=[disnake.ChannelType.text])),row(btn("Definir título","Kroma:portfolio-title",disnake.ButtonStyle.primary),btn("Voltar","Kroma:home"))]

class Appearance(disnake.ui.Modal):
 def __init__(self):
  d=setup_data(); super().__init__(title="Aparência do atendimento",components=[
   disnake.ui.TextInput(label="Título",custom_id="title",value=d["title"],max_length=80),
   disnake.ui.TextInput(label="Texto principal",custom_id="intro",value=d["intro"],style=disnake.TextInputStyle.paragraph,max_length=500),
   disnake.ui.Label("Thumbnail / Logo (Opcional)",disnake.ui.FileUpload(custom_id="logo_file",required=False)),
   disnake.ui.Label("Banner (Opcional)",disnake.ui.FileUpload(custom_id="banner_file",required=False)),
   disnake.ui.Label("Posição do Banner",disnake.ui.StringSelect(custom_id="banner_position",options=[disnake.SelectOption(label="Banner em Cima",value="top",default=d.get("banner_position","top")=="top"),disnake.SelectOption(label="Banner em Baixo",value="bottom",default=d.get("banner_position")=="bottom")],required=False)),
  ])
 async def callback(self,inter):
  if not await guard(inter): return
  def uploaded(key):
   value=inter.resolved_values.get(key)
   return value[0].url if isinstance(value,list) and value else None
  d=setup_data(); logo=uploaded("logo_file");banner=uploaded("banner_file");position=inter.values.get("banner_position","top")
  if isinstance(position,list):position=position[0] if position else "top"
  d.update({"title":inter.text_values["title"].strip(),"intro":inter.text_values["intro"].strip(),"banner_position":position})
  if logo:d["logo"]=logo
  if banner:d["banner"]=banner
  save_setup(d); await inter.response.send_message(components=card("APARÊNCIA SALVA","Mídias enviadas e visual salvo. Use Postar ou Sincronizar para aplicar."),flags=FLAGS,ephemeral=True)
class Hours(disnake.ui.Modal):
 def __init__(self):
  h=setup_data()["hours"]; names=["seg","ter","qua","qui","sex","sab","dom"]; super().__init__(title="Horários",components=[disnake.ui.TextInput(label="Abertura HH:MM",custom_id="start",value=h["start"],max_length=5),disnake.ui.TextInput(label="Fechamento HH:MM",custom_id="end",value=h["end"],max_length=5),disnake.ui.TextInput(label="Dias: seg,ter,qua,qui,sex,sab,dom",custom_id="days",value=",".join(names[i] for i in h["days"]),max_length=40),disnake.ui.TextInput(label="Ativar? sim ou não",custom_id="enabled",value="sim" if h["enabled"] else "não",max_length=3)])
 async def callback(self,inter):
  if not await guard(inter): return
  try: datetime.strptime(inter.text_values["start"],"%H:%M"); datetime.strptime(inter.text_values["end"],"%H:%M")
  except ValueError: return await inter.response.send_message(components=card("HORÁRIO INVÁLIDO","Use `10:00`.",ERROR),flags=FLAGS,ephemeral=True)
  aliases={"seg":0,"ter":1,"qua":2,"qui":3,"sex":4,"sab":5,"dom":6}; days=[aliases[x] for x in inter.text_values["days"].lower().replace(" ","").split(",") if x in aliases]
  if not days:return await inter.response.send_message(components=card("DIAS INVÁLIDOS","Exemplo: `seg,ter,qua,qui,sex`.",ERROR),flags=FLAGS,ephemeral=True)
  d=setup_data(); d["hours"]={"enabled":inter.text_values["enabled"].lower().strip() in {"sim","s","1"},"start":inter.text_values["start"].strip(),"end":inter.text_values["end"].strip(),"days":sorted(set(days))};save_setup(d);await inter.response.send_message(components=card("HORÁRIOS SALVOS","Poste ou sincronize para aplicar."),flags=FLAGS,ephemeral=True)
class Function(disnake.ui.Modal):
 def __init__(self,edit=False):
  self.edit=edit; item=chosen(setup_data()) or {}; super().__init__(title="Editar função" if edit else "Adicionar função",components=[disnake.ui.TextInput(label="Nome",custom_id="name",value=item.get("name","") if edit else "",max_length=80),disnake.ui.TextInput(label="Pré-descrição",custom_id="short",value=item.get("short","") if edit else "",max_length=100),disnake.ui.TextInput(label="Descrição",custom_id="desc",value=item.get("description","") if edit else "",style=disnake.TextInputStyle.paragraph,max_length=500),disnake.ui.TextInput(label="Texto do botão",custom_id="button",value=item.get("button","") if edit else "",max_length=80),disnake.ui.TextInput(label="Cor: blurple, green, red ou grey",custom_id="style",value=item.get("style","blurple") if edit else "blurple",max_length=10)])
 async def callback(self,inter):
  if not await guard(inter):return
  style=inter.text_values["style"].strip().lower()
  if style not in {"blurple","green","red","grey"}:return await inter.response.send_message(components=card("COR INVÁLIDA","Use `blurple`, `green`, `red` ou `grey`.",ERROR),flags=FLAGS,ephemeral=True)
  d=setup_data(); value={"name":inter.text_values["name"].strip(),"short":inter.text_values["short"].strip(),"description":inter.text_values["desc"].strip(),"button":inter.text_values["button"].strip(),"style":style}
  if self.edit:
   item=chosen(d)
   if not item:return await inter.response.send_message(components=card("FUNÇÃO NÃO ENCONTRADA","Selecione uma função.",ERROR),flags=FLAGS,ephemeral=True)
   value["id"]=item["id"];item.update(value)
  else:
   stem="".join(c for c in value["name"].lower() if c.isalnum())[:24] or "atendimento"; used={x["id"] for x in d["options"]}; ident=stem; n=2
   while ident in used:ident=f"{stem}{n}";n+=1
   value["id"]=ident;d["options"].append(value);d["selected"]=ident
  save_setup(d);await inter.response.send_message(components=card("FUNÇÃO SALVA","Poste ou sincronize para aplicar."),flags=FLAGS,ephemeral=True)
class Pix(disnake.ui.Modal):
 def __init__(self):
  d=Database.get_config().get("manual_pix",{});super().__init__(title="PIX manual",components=[disnake.ui.TextInput(label="Chave PIX",custom_id="key",value=str(d.get("key") or ""),max_length=180),disnake.ui.TextInput(label="Recebedor",custom_id="recipient",value=str(d.get("recipient") or "Kroma Studio"),max_length=100),disnake.ui.TextInput(label="Mensagem",custom_id="message",value=str(d.get("message") or "Envie o comprovante neste atendimento."),style=disnake.TextInputStyle.paragraph,max_length=400)])
 async def callback(self,inter):
  if not await guard(inter):return
  c=Database.get_config();c["manual_pix"]={"enabled":c.get("manual_pix",{}).get("enabled",False),"key":inter.text_values["key"].strip(),"recipient":inter.text_values["recipient"].strip(),"message":inter.text_values["message"].strip()};Database.save_config(c);await inter.response.send_message(components=card("PIX SALVO","Chave salva no banco local."),flags=FLAGS,ephemeral=True)

class FunctionMedia(disnake.ui.Modal):
 def __init__(self):
  super().__init__(title="Mídia da função",components=[
   disnake.ui.Label("Thumbnail (Opcional)",disnake.ui.FileUpload(custom_id="thumbnail",required=False)),
   disnake.ui.Label("Banner (Opcional)",disnake.ui.FileUpload(custom_id="banner",required=False)),
   disnake.ui.Label("Posição do Banner",disnake.ui.StringSelect(custom_id="position",options=[disnake.SelectOption(label="Banner em Cima",value="top"),disnake.SelectOption(label="Banner em Baixo",value="bottom",default=True)],required=False)),
  ])
 async def callback(self,inter):
  if not await guard(inter):return
  d=setup_data(); item=chosen(d)
  if not item:return await inter.response.send_message(components=card("FUNÇÃO NÃO ENCONTRADA","Selecione uma função antes de enviar a mídia.",ERROR),flags=FLAGS,ephemeral=True)
  def uploaded(key):
   value=inter.resolved_values.get(key)
   return value[0].url if isinstance(value,list) and value else None
  thumb=uploaded("thumbnail"); banner=uploaded("banner"); position=inter.values.get("position", "bottom")
  if isinstance(position,list):position=position[0] if position else "bottom"
  if thumb:item["thumbnail"]=thumb
  if banner:item["banner"]=banner
  item["banner_position"]=position
  save_setup(d);await inter.response.send_message(components=card("MÍDIA SALVA",f"A mídia foi vinculada à função **{item['name']}**. Use Postar ou Sincronizar para aplicar."),flags=FLAGS,ephemeral=True)

class QueueAppearance(disnake.ui.Modal):
 def __init__(self):
  data=Database.get_document("kroma_art_queue") or {}
  super().__init__(title="Aparência da fila",components=[
   disnake.ui.TextInput(label="Título",custom_id="title",value=data.get("title") or "FILA DE ARTES / KROMA STUDIO",max_length=80),
   disnake.ui.TextInput(label="Texto principal",custom_id="intro",value=data.get("intro") or "Pedidos entram somente após a confirmação manual do PIX.",style=disnake.TextInputStyle.paragraph,max_length=500),
   disnake.ui.Label("Thumbnail (Opcional)",disnake.ui.FileUpload(custom_id="thumbnail",required=False)),
   disnake.ui.Label("Banner (Opcional)",disnake.ui.FileUpload(custom_id="banner",required=False)),
   disnake.ui.Label("Posição do Banner",disnake.ui.StringSelect(custom_id="position",options=[disnake.SelectOption(label="Banner em Cima",value="top",default=data.get("banner_position","top")=="top"),disnake.SelectOption(label="Banner em Baixo",value="bottom",default=data.get("banner_position")=="bottom")],required=False)),
  ])
 async def callback(self,inter):
  if not await guard(inter):return
  data=Database.get_document("kroma_art_queue") or {}
  def uploaded(key):
   value=inter.resolved_values.get(key)
   return value[0].url if isinstance(value,list) and value else None
  position=inter.values.get("position","top")
  if isinstance(position,list):position=position[0] if position else "top"
  data.update({"title":inter.text_values["title"].strip(),"intro":inter.text_values["intro"].strip(),"banner_position":position})
  thumbnail=uploaded("thumbnail");banner=uploaded("banner")
  if thumbnail:data["thumbnail_url"]=thumbnail
  if banner:data["banner_url"]=banner
  Database.save_document("kroma_art_queue",data)
  await inter.response.send_message(components=card("APARÊNCIA SALVA","Use Publicar / atualizar fila para aplicar."),flags=FLAGS,ephemeral=True)

class PortfolioTitle(disnake.ui.Modal):
 def __init__(self):
  data=Database.get_document("kroma_portfolio") or {};super().__init__(title="Título do portfólio",components=[disnake.ui.TextInput(label="Título",custom_id="title",value=data.get("title") or "PORTFÓLIO / KROMA STUDIO",max_length=80)])
 async def callback(self,inter):
  if not await guard(inter):return
  data=Database.get_document("kroma_portfolio") or {};data["title"]=inter.text_values["title"].strip() or "PORTFÓLIO / KROMA STUDIO";Database.save_document("kroma_portfolio",data);await inter.response.send_message(components=card("PORTFÓLIO SALVO","O título será usado nas próximas entregas."),flags=FLAGS,ephemeral=True)

class PriceModal(disnake.ui.Modal):
 def __init__(self,edit=False):
  self.edit=edit;data=catalog_data();item=next((x for x in data["items"] if x["id"]==data.get("selected")),{})
  super().__init__(title="Editar preço" if edit else "Adicionar item",components=[disnake.ui.TextInput(label="Nome",custom_id="name",value=item.get("name","") if edit else "",max_length=80),disnake.ui.TextInput(label="Tipo: Serviço ou Pacote",custom_id="type",value=item.get("type","Serviço") if edit else "Serviço",max_length=12),disnake.ui.TextInput(label="Descrição / inclui",custom_id="description",value=item.get("description","") if edit else "",style=disnake.TextInputStyle.paragraph,max_length=300),disnake.ui.TextInput(label="Preço",custom_id="price",value=str(item.get("price", "")) if edit else "",placeholder="Ex.: 25,00",max_length=20)])
 async def callback(self,inter):
  if not await guard(inter):return
  kind=inter.text_values["type"].strip().capitalize()
  if kind not in {"Serviço","Pacote"}:return await inter.response.send_message(components=card("TIPO INVÁLIDO","Use `Serviço` ou `Pacote`.",ERROR),flags=FLAGS,ephemeral=True)
  raw=inter.text_values["price"].replace("R$","").replace(".","").replace(",",".").strip()
  try:value=float(raw);assert value>=0
  except (ValueError,AssertionError):return await inter.response.send_message(components=card("PREÇO INVÁLIDO","Use um valor como `25,00`.",ERROR),flags=FLAGS,ephemeral=True)
  data=catalog_data();entry={"name":inter.text_values["name"].strip(),"type":kind,"description":inter.text_values["description"].strip(),"price":value}
  if self.edit:
   item=next((x for x in data["items"] if x["id"]==data.get("selected")),None)
   if not item:return await inter.response.send_message(components=card("ITEM NÃO ENCONTRADO","Selecione um item primeiro.",ERROR),flags=FLAGS,ephemeral=True)
   entry["id"]=item["id"];item.update(entry)
  else:
   stem="".join(c for c in entry["name"].lower() if c.isalnum())[:24] or "item";used={x["id"] for x in data["items"]};ident=stem;n=2
   while ident in used:ident=f"{stem}{n}";n+=1
   entry["id"]=ident;data["items"].append(entry);data["selected"]=ident
  Database.save_document("kroma_catalog",data);await inter.response.send_message(components=card("PREÇO SALVO","A tabela foi atualizada."),flags=FLAGS,ephemeral=True)

def built_panel(d):
 h=d["hours"]; options=[]
 for x in d["options"]: options.append({"id":x["id"],"name":x["name"],"button":x["button"],"description":x["short"],"roles":{"attendant":d.get("staff_roles",[])},"form":{"questions":[{"id":"detalhes","label":"Conte o que você precisa","placeholder":x["description"][:100],"style":"paragraph","required":True}]},"open_message":{"style":"container","container":{"color":d["accent"],"content":f"## {x['name'].upper()}\n{x['description']}","image_url":x.get("banner") or d["banner"],"thumbnail_url":x.get("thumbnail") or d["logo"],"banner_position":x.get("banner_position","bottom")}}})
 return {"name":d["title"],"enabled":True,"mode":"channel","channel_id":str(d.get("channel_id") or ""),"category_id":d.get("category_id"),"roles":{"attendant":d.get("staff_roles",[])},"button":{"label":"Abrir atendimento","style":"blurple","position":"below"},"container":{"content":f"# {d['title']}\n-# Atendimento privado\n\n{d['intro']}\n\n## COMO PODEMOS AJUDAR?\nEscolha uma função abaixo.","color":d["accent"],"image_url":d["banner"],"thumbnail_url":d["logo"],"banner_position":d.get("banner_position","top"),"display_mode":"buttons"},"office_hours":{"enabled":h["enabled"],"start_time":h["start"],"end_time":h["end"],"days":h["days"],"closed_message":"Estamos fora do horário de atendimento."},"layout":"multi","options":options}

class KromaCenter(commands.Cog):
 def __init__(self,bot):self.bot=bot
 @commands.slash_command(name="central",description="Central de gestão da Kroma Studio.",default_member_permissions=disnake.Permissions(manage_guild=True))
 async def central(self,inter):
  if await guard(inter):await inter.response.send_message(components=home(),flags=FLAGS,ephemeral=True)
 @commands.slash_command(name="precos",description="Veja a tabela de preços da Kroma Studio.")
 async def precos(self,inter):
  data=catalog_data();services=[x for x in data["items"] if x["type"]=="Serviço"];packs=[x for x in data["items"] if x["type"]=="Pacote"];text="**SERVIÇOS**\n"+"\n".join(f"`{x['name']}` · **{price(x['price'])}**" for x in services)+"\n\n**PACOTES**\n"+"\n".join(f"`{x['name']}` · **{price(x['price'])}**" for x in packs);await inter.response.send_message(components=card("TABELA DE PREÇOS / KROMA STUDIO",text),flags=FLAGS)
 @commands.Cog.listener("on_message_interaction")
 async def controls(self,inter):
  key=getattr(inter.component,"custom_id","")
  if not key.startswith("Kroma:") or not await guard(inter):return
  pages={"Kroma:home":home,"Kroma:tickets":ticket_page,"Kroma:pix":pix_page,"Kroma:queue":queue_page,"Kroma:prices":prices_page,"Kroma:portfolio":portfolio_page}
  if key in pages:return await inter.response.edit_message(components=pages[key](),flags=FLAGS)
  if key=="Kroma:appearance":return await inter.response.send_modal(Appearance())
  if key=="Kroma:hours":return await inter.response.send_modal(Hours())
  if key=="Kroma:add":return await inter.response.send_modal(Function())
  if key=="Kroma:edit":return await inter.response.send_modal(Function(True))
  if key=="Kroma:media":return await inter.response.send_modal(FunctionMedia())
  if key=="Kroma:queue-appearance":return await inter.response.send_modal(QueueAppearance())
  if key=="Kroma:portfolio-title":return await inter.response.send_modal(PortfolioTitle())
  if key=="Kroma:price-add":return await inter.response.send_modal(PriceModal())
  if key=="Kroma:price-edit":return await inter.response.send_modal(PriceModal(True))
  if key=="Kroma:pix-edit":return await inter.response.send_modal(Pix())
  if key=="Kroma:pix-toggle":
   c=Database.get_config();c.setdefault("manual_pix",{})["enabled"]=not c["manual_pix"].get("enabled",False);Database.save_config(c);return await inter.response.edit_message(components=pix_page(),flags=FLAGS)
  if key=="Kroma:queue-channel":
   q=Database.get_document("kroma_art_queue") or {};q["channel_id"]=selected(inter);Database.save_document("kroma_art_queue",q);return await inter.response.edit_message(components=queue_page(),flags=FLAGS)
  if key=="Kroma:portfolio-channel":
   p=Database.get_document("kroma_portfolio") or {};p["channel_id"]=selected(inter);Database.save_document("kroma_portfolio",p);return await inter.response.edit_message(components=portfolio_page(),flags=FLAGS)
  if key=="Kroma:queue-sync":
   from functions.art_queue import sync
   if not await sync(self.bot):return await inter.response.send_message(components=card("CANAL NECESSÁRIO","Escolha um canal público para a fila.",ERROR),flags=FLAGS,ephemeral=True)
   return await inter.response.send_message(components=card("FILA PUBLICADA","A fila foi publicada e será atualizada a cada PIX confirmado."),flags=FLAGS,ephemeral=True)
  d=setup_data()
  if key=="Kroma:price-select":
   data=catalog_data();data["selected"]=selected(inter);Database.save_document("kroma_catalog",data);return await inter.response.edit_message(components=prices_page(),flags=FLAGS)
  if key=="Kroma:price-remove":
   data=catalog_data();item=next((x for x in data["items"] if x["id"]==data.get("selected")),None)
   if not item:return await inter.response.send_message(components=card("ITEM NÃO ENCONTRADO","Selecione um item primeiro.",ERROR),flags=FLAGS,ephemeral=True)
   data["items"].remove(item);data["selected"]=data["items"][0]["id"] if data["items"] else None;Database.save_document("kroma_catalog",data);return await inter.response.edit_message(components=prices_page(),flags=FLAGS)
  if key=="Kroma:channel":d["channel_id"]=selected(inter)
  elif key=="Kroma:category":d["category_id"]=selected(inter)
  elif key=="Kroma:roles":d["staff_roles"]=[str(getattr(x,"id",x)) for x in inter.values]
  elif key=="Kroma:select":d["selected"]=selected(inter)
  elif key=="Kroma:remove":
   item=chosen(d)
   if not item:return await inter.response.send_message(components=card("NADA PARA REMOVER","Cadastre uma função primeiro.",ERROR),flags=FLAGS,ephemeral=True)
   d["options"].remove(item);d["selected"]=d["options"][0]["id"] if d["options"] else None
  elif key in {"Kroma:post","Kroma:sync"}:
   channel=inter.guild.get_channel(int(d.get("channel_id") or 0))
   if not isinstance(channel,disnake.TextChannel):return await inter.response.send_message(components=card("CANAL NECESSÁRIO","Escolha um canal de texto.",ERROR),flags=FLAGS,ephemeral=True)
   config=Database.get_document("tickets_config") or {}; old=config.get("panels",{}).get("kroma-artes",{}); p=built_panel(d);p["message_id"]=old.get("message_id");config.setdefault("panels",{})["kroma-artes"]=p;Database.save_document("tickets_config",config)
   from modules.tickets.publisher import TicketPublisher
   if key=="Kroma:post" and not p.get("message_id"):await TicketPublisher.send_panel(self.bot,"kroma-artes",channel)
   else:await TicketPublisher.sync_panel_message(self.bot,"kroma-artes")
   return await inter.response.send_message(components=card("PAINEL APLICADO",f"Atendimento atualizado em {channel.mention}."),flags=FLAGS,ephemeral=True)
  else:return
  save_setup(d);await inter.response.edit_message(components=ticket_page(),flags=FLAGS)
def setup(bot):bot.add_cog(KromaCenter(bot))
