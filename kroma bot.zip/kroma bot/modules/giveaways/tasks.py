import asyncio
import datetime
import random
import disnake
from disnake.ext import tasks
from functions.giveaways import GiveawaysManager
from functions.database import Database
from . import message

async def select_winners(bot: disnake.Client, task: dict, giveaway_data: dict, all_previous_winners: list) -> list:
    winners = []
    guild = bot.get_guild(task.get("guild_id"))
    if not guild:
        return []

    if giveaway_data.get("mode") == "falso":

        user_ids = set(giveaway_data.get("winner_users", []))
        role_ids = giveaway_data.get("winner_roles", [])

        for role_id in role_ids:
            role = guild.get_role(int(role_id))
            if role:
                for member in role.members:
                    user_ids.add(member.id)

        winners = list(user_ids)

    elif giveaway_data.get("mode") == "real":

        min_participants = giveaway_data.get("min_participants", 0)
        if len(task.get("participants", [])) < min_participants:
            return []

        eligible_participants_ids = [p for p in task.get("participants", []) if p not in all_previous_winners]

        if not eligible_participants_ids:
            return []

        bonus_roles = giveaway_data.get("bonus_roles", {})
        weighted_participants = []

        for user_id in eligible_participants_ids:
            member = guild.get_member(user_id)
            if not member:
                try:
                    member = await guild.fetch_member(user_id)
                except (disnake.NotFound, disnake.Forbidden):
                    member = None

            entries = 1
            if member and bonus_roles:
                member_role_ids = {str(r.id) for r in member.roles}
                for role_id, bonus_entries in bonus_roles.items():
                    if role_id in member_role_ids:
                        entries += int(bonus_entries)

            weighted_participants.extend([user_id] * entries)

        if not weighted_participants:
            return []

        max_winners = task.get("max_winners", 1)

        unique_participants_count = len(set(weighted_participants))
        if max_winners > unique_participants_count:
            max_winners = unique_participants_count

        drawn_winners = set()
        while len(drawn_winners) < max_winners and weighted_participants:
            winner = random.choice(weighted_participants)
            drawn_winners.add(winner)
            weighted_participants = [p for p in weighted_participants if p != winner]

        winners = list(drawn_winners)

    return winners

async def announce_winners(bot: disnake.Client, original_message: disnake.Message, task: dict, giveaway_data: dict, winners: list, is_reroll: bool = False):
    winner_mentions = [f"<@{winner_id}>" for winner_id in winners]
    participants_count = len(task.get("participants", []))

    if not winners:
        if giveaway_data.get("mode") == "real":
            if participants_count < giveaway_data.get("min_participants", 0):
                announcement_content = f"O sorteio **{giveaway_data.get('name')}** foi cancelado por não atingir o mínimo de **{giveaway_data.get('min_participants', 0)}** participantes."
            else:
                announcement_content = f"Não há mais participantes elegíveis para sortear em **{giveaway_data.get('name')}**."
        else:
            announcement_content = f"Não foram definidos ganhadores para o sorteio falso **{giveaway_data.get('name')}**."
        await original_message.reply(announcement_content)
        return

    container_winner = giveaway_data.get("container_winner", {})
    custom_content = container_winner.get("content", "")

    if custom_content:
        announcement_content = custom_content
        announcement_content = announcement_content.replace("{winners}", ", ".join(winner_mentions))
        announcement_content = announcement_content.replace("{giveaway_name}", giveaway_data.get("name", "Sorteio"))
        announcement_content = announcement_content.replace("{participants}", str(participants_count))

        container_items = [disnake.ui.TextDisplay(announcement_content)]

        winner_image = container_winner.get("image_url")
        if winner_image:
            container_items.append(disnake.ui.Separator())
            container_items.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=winner_image)))

        container = disnake.ui.Container(*container_items)

        reroll_text = " (Re-sorteio)" if is_reroll else ""
        if reroll_text:
            container_items.insert(0, disnake.ui.TextDisplay(f"-# {reroll_text.strip()}"))

        await original_message.reply(components=[container], flags=disnake.MessageFlags(is_components_v2=True))
    else:
        if len(winners) == 1:
            pronoun = "você"
            verb = "ganhou"
        else:
            pronoun = "vocês"
            verb = "ganharam"

        reroll_text = " (Re-sorteio)" if is_reroll else ""
        announcement_content = f"Parabéns {', '.join(winner_mentions)}, {pronoun} {verb} o sorteio **{giveaway_data.get('name')}**!{reroll_text}"
        await original_message.reply(announcement_content)

async def deliver_prizes(bot: disnake.Client, giveaway_data: dict, winners: list, guild: disnake.Guild, message_url: str):
    for winner_id in winners:
        try:
            member = bot.get_user(winner_id) or await bot.fetch_user(winner_id)

            view = disnake.ui.View()
            view.add_item(disnake.ui.Button(label="Ir para o Sorteio", url=message_url))

            message = f"Parabéns! Você ganhou o sorteio **{giveaway_data.get('name')}** no servidor **{guild.name}**."
            await member.send(message, view=view)
        except (disnake.NotFound, disnake.Forbidden):
            pass
        except Exception as e:
            print(f"Error sending prize DM to {winner_id}: {e}")

async def process_giveaway_roll(bot: disnake.Client, giveaway_id: str, task_id: str, is_reroll: bool = False):
    giveaway_data = GiveawaysManager.obter_giveaway(giveaway_id)
    if not giveaway_data:
        return

    task = next((t for t in giveaway_data.get("tasks", []) if t.get("id") == task_id), None)
    if not task:
        return

    guild = None
    message_url = ""
    original_message = None

    try:
        ch_id = task.get('channel_id')
        channel = bot.get_channel(int(ch_id)) if ch_id else None
        if not channel:
            raise ValueError(f"Channel {ch_id} not found.")

        guild = channel.guild
        task['guild_id'] = guild.id

        msg_id = task.get("message_id")
        if msg_id:
            message_url = f"https://discord.com/channels/{guild.id}/{channel.id}/{msg_id}"
            original_message = await channel.fetch_message(int(msg_id))
        else:
            raise ValueError("Message ID not found in task.")

    except (disnake.NotFound, disnake.Forbidden, ValueError, TypeError) as e:
        print(f"[Giveaway] Erro ao buscar canal/mensagem {giveaway_id}/{task_id}: {e}")
        task['status'] = 'error'
        GiveawaysManager.salvar_giveaway(giveaway_id, giveaway_data)
        return

    if "draws" not in task:
        task["draws"] = []

    all_previous_winners = [winner for draw in task["draws"] for winner in draw["winners"]]

    winners = await select_winners(bot, task, giveaway_data, all_previous_winners)

    await announce_winners(bot, original_message, task, giveaway_data, winners, is_reroll)

    if winners:
        await deliver_prizes(bot, giveaway_data, winners, guild, message_url)

    new_draw = {
        "draw_id": GiveawaysManager.gerar_id(8),
        "winners": winners,
        "timestamp": datetime.datetime.now().timestamp()
    }
    task["draws"].append(new_draw)

    task["status"] = "finished"
    task["rolled"] = True

    if original_message:
        try:
            embed, view, container_components = message.build_giveaway_message(giveaway_data, task, finished=True)
            if container_components:
                await original_message.edit(components=container_components, embed=None)
            else:
                await original_message.edit(embed=embed, view=view)
        except Exception as e:
            print(f"Erro ao atualizar mensagem do sorteio {giveaway_id}/{task_id}: {e}")

    GiveawaysManager.salvar_giveaway(giveaway_id, giveaway_data)

class GiveawayTasks:

    def __init__(self, bot: disnake.Client):
        self.bot = bot

    def start_tasks(self):
        if not self.roll_task.is_running():
            self.roll_task.start()
        if not self.monitor_task.is_running():
            self.monitor_task.start()

    def cog_unload(self):
        self.roll_task.cancel()
        self.monitor_task.cancel()

    @tasks.loop(seconds=3)
    async def roll_task(self):
        await self.bot.wait_until_ready()
        # Força refresh direto do Mongo ignorando circuit breaker — caminho crítico
        try:
            await Database.refresh_document("giveaways_data", force=True)
        except Exception as e:
            print(f"[Giveaway] Refresh falhou, seguindo com cache existente: {e}")

        giveaways = GiveawaysManager.obter_giveaways()
        if not isinstance(giveaways, dict):
            return

        current_time = datetime.datetime.now().timestamp()

        for giveaway_id, giveaway_data in list(giveaways.items()):
            for task in list(giveaway_data.get("tasks", [])):
                try:
                    if task.get("status") == "scheduled":
                        await self._publish_scheduled_task(giveaway_id, giveaway_data, task)
                        await asyncio.sleep(0.5)
                    elif task.get("status") == "running" and task.get("end_time") and current_time >= task["end_time"]:
                        print(f"[Giveaway] Finalizando sorteio {giveaway_id}/{task.get('id')} (end_time={task['end_time']}, now={current_time})")
                        await process_giveaway_roll(self.bot, giveaway_id, task["id"], is_reroll=False)
                        await asyncio.sleep(1)
                except Exception as e:
                    print(f"[Giveaway] Erro ao processar task {giveaway_id}/{task.get('id')}: {e}")
                    import traceback
                    traceback.print_exc()

    async def _publish_scheduled_task(self, giveaway_id: str, giveaway_data: dict, task: dict):
        task_id = task.get("id")
        channel_id = task.get("channel_id")
        if not channel_id:
            print(f"[Giveaway] Task {giveaway_id}/{task_id} sem channel_id — marcando como erro")
            task["status"] = "error"
            GiveawaysManager.atualizar_task(giveaway_id, task_id, task)
            return

        channel = self.bot.get_channel(int(channel_id))
        if not channel:
            print(f"[Giveaway] Canal {channel_id} não encontrado para task {giveaway_id}/{task_id}")
            task["status"] = "error"
            GiveawaysManager.atualizar_task(giveaway_id, task_id, task)
            return

        duration_hours = task.get("duration_hours", 24)
        end_time = datetime.datetime.now().timestamp() + (duration_hours * 3600)
        task["end_time"] = end_time

        cid = f"Giveaways_Participate_{giveaway_id}/{task_id}"
        embed, view, container_components = message.build_giveaway_message(giveaway_data, task, custom_id=cid)

        try:
            msg = await channel.send(components=container_components, flags=disnake.MessageFlags(is_components_v2=True))
            task["message_id"] = msg.id
            task["status"] = "running"
            task["guild_id"] = channel.guild.id
            print(f"[Giveaway] Task {giveaway_id}/{task_id} publicada — end_time={end_time} ({duration_hours}h)")
            GiveawaysManager.atualizar_task(giveaway_id, task_id, task)
        except Exception as e:
            print(f"[Giveaway] Erro ao publicar task {giveaway_id}/{task_id}: {e}")
            import traceback
            traceback.print_exc()
            task["status"] = "error"
            GiveawaysManager.atualizar_task(giveaway_id, task_id, task)

    @tasks.loop(minutes=1)
    async def monitor_task(self):
        await self.bot.wait_until_ready()
        giveaways = GiveawaysManager.obter_giveaways()

        for giveaway_id, giveaway in giveaways.items():
            tasks_list = giveaway.get("tasks", [])
            for task in tasks_list:
                if task.get("status") != "running":
                    continue

                participants = task.get("participants", [])
                if not participants:
                    continue

                guild = self.bot.get_guild(task.get("guild_id"))
                if not guild:
                    continue

                to_remove = []
                for user_id in list(participants):
                    member = guild.get_member(user_id)
                    if not member:
                        try:
                            member = await guild.fetch_member(user_id)
                        except Exception:
                            to_remove.append(user_id)
                            continue

                    success, reason = GiveawaysManager.check_requirements(member, giveaway)
                    if not success:
                        to_remove.append(user_id)
                        try:
                            await member.send(f"Você foi removido do sorteio **{giveaway.get('name')}** por não cumprir mais os requisitos:\n> {reason}")
                        except Exception:
                            pass

                if to_remove:
                    task["participants"] = [p for p in participants if p not in to_remove]
                    GiveawaysManager.atualizar_task(giveaway_id, task["id"], task)


                    from .core import GiveawaysCog
                    self.bot.loop.create_task(GiveawaysCog.update_giveaway_messages(self.bot, giveaway_id))
