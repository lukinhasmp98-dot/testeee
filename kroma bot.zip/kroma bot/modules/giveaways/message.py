import disnake


def build_giveaway_message(giveaway: dict, task: dict = None, finished: bool = False, custom_id: str = None):
    button_data = giveaway.get("button", {})
    button_style_str = button_data.get("style", "grey")

    style_map = {
        "green": disnake.ButtonStyle.green,
        "blurple": disnake.ButtonStyle.blurple,
        "grey": disnake.ButtonStyle.grey,
        "red": disnake.ButtonStyle.red,
    }
    btn_style = style_map.get(button_style_str, disnake.ButtonStyle.grey)

    participants_count = len(task.get("participants", [])) if task else 0
    max_winners = task.get("max_winners", 1) if task else 1
    end_time = task.get("end_time") if task else None

    def replace_placeholders(text: str) -> str:
        if not text:
            return text
        text = text.replace("{participants}", str(participants_count))
        text = text.replace("{winners}", str(max_winners))
        if end_time:
            timestamp = f"<t:{int(end_time)}:R>"
            text = text.replace("{end_time}", timestamp)
        return text

    label = button_data.get("label", "Participar")
    if label:
        label = label.strip()

    button_kwargs = {
        "label": label if label else None,
        "style": btn_style,
        "custom_id": custom_id or "giveaway_participate",
        "disabled": finished,
    }

    emoji_raw = button_data.get("emoji")
    if emoji_raw and emoji_raw.strip():
        emoji_str = emoji_raw.strip()
        if emoji_str.isdigit():
            button_kwargs["emoji"] = disnake.PartialEmoji(id=int(emoji_str))
        elif emoji_str.startswith("<") and ":" in emoji_str:
            try:
                button_kwargs["emoji"] = disnake.PartialEmoji.from_string(emoji_str)
            except Exception:
                button_kwargs["emoji"] = emoji_str
        else:
            button_kwargs["emoji"] = emoji_str

    button = disnake.ui.Button(**button_kwargs)

    counter_button = disnake.ui.Button(
        label=f"{participants_count}",
        style=disnake.ButtonStyle.grey,
        disabled=True,
    )

    list_button = disnake.ui.Button(
        label="Ver participantes",
        style=disnake.ButtonStyle.grey,
        custom_id=(
            f"{custom_id.replace('Participate', 'ListParticipants')}"
            if custom_id
            else "giveaway_list_participants"
        ),
    )

    container_data = giveaway.get("container", {})
    main_content = replace_placeholders(container_data.get("content", "# Sorteio\nClique no botao para participar!"))

    container_items = [disnake.ui.TextDisplay(main_content)]

    image_url = container_data.get("image_url")
    if image_url:
        container_items.append(disnake.ui.Separator())
        container_items.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=image_url)))

    if task and not finished:
        container_items.append(disnake.ui.Separator())
        info_text = f"-# Participantes: `{participants_count}` - Ganhadores: `{max_winners}`"
        if end_time:
            info_text += f"\n-# Encerra: <t:{int(end_time)}:R>"
        container_items.append(disnake.ui.TextDisplay(info_text))
    elif finished:
        container_items.append(disnake.ui.Separator())
        container_items.append(disnake.ui.TextDisplay("-# Status: Sorteio finalizado!"))

    container_items.append(disnake.ui.Separator())
    container_items.append(disnake.ui.ActionRow(button, counter_button, list_button))

    container = disnake.ui.Container(*container_items)
    return None, None, [container]
