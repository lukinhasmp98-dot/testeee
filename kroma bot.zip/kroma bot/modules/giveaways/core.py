"""
Sorteios (runtime)
Mantem apenas os listeners que atendem participacoes de usuarios finais
e o update ao vivo das mensagens de sorteio. A configuracao foi movida
integralmente para a dashboard web.
"""
import io
import disnake
from disnake.ext import commands

from functions.giveaways import GiveawaysManager

from . import message
from .tasks import GiveawayTasks


class GiveawaysCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.giveaway_tasks = GiveawayTasks(bot)

    @commands.Cog.listener()
    async def on_ready(self):
        self.giveaway_tasks.start_tasks()

    def cog_unload(self):
        self.giveaway_tasks.cog_unload()

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        giveaway_ids = GiveawaysManager.obter_giveaways()
        changed_giveaways = set()

        for gid, giveaway in giveaway_ids.items():
            changed = False
            for task in giveaway.get("tasks", []):
                if task.get("status") == "running" and member.id in task.get("participants", []):
                    task["participants"].remove(member.id)
                    changed = True

            if changed:
                GiveawaysManager.salvar_giveaway(gid, giveaway)
                changed_giveaways.add(gid)

        for gid in changed_giveaways:
            self.bot.loop.create_task(self.update_giveaway_messages(self.bot, gid))

    @staticmethod
    async def update_giveaway_messages(bot: disnake.Client, giveaway_id: str):
        giveaway = GiveawaysManager.obter_giveaway(giveaway_id)
        if not giveaway:
            return

        for task in giveaway.get("tasks", []):
            if task.get("status") == "running" and task.get("message_id") and task.get("channel_id"):
                try:
                    channel = bot.get_channel(task["channel_id"])
                    if not channel:
                        channel = await bot.fetch_channel(task["channel_id"])

                    if channel:
                        msg = await channel.fetch_message(task["message_id"])
                        if msg:
                            cid = f"Giveaways_Participate_{giveaway_id}/{task['id']}"
                            _embed, _view, container_components = message.build_giveaway_message(giveaway, task, custom_id=cid)
                            await msg.edit(components=container_components, embed=None)
                except Exception as e:
                    print(f"Erro ao atualizar mensagem ao vivo {task.get('message_id')}: {e}")

    @commands.Cog.listener("on_button_click")
    async def runtime_button_listener(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id
        if not cid:
            return

        try:
            if cid.startswith("Giveaways_Participate_"):
                parts = cid.replace("Giveaways_Participate_", "").split("/")
                if len(parts) < 2:
                    print(f"[GIVEAWAYS] custom_id mal formado: {cid}")
                    return
                giveaway_id, task_id = parts[0], parts[1]
                await self._handle_participation(inter, giveaway_id, task_id)
                return

            if cid.startswith("Giveaways_ListParticipants_"):
                parts = cid.replace("Giveaways_ListParticipants_", "").split("/")
                if len(parts) < 2:
                    print(f"[GIVEAWAYS] custom_id mal formado: {cid}")
                    return
                giveaway_id, task_id = parts[0], parts[1]
                await self._send_participants_list(inter, giveaway_id, task_id)
                return
        except Exception as e:
            print(f"[GIVEAWAYS] Erro processando interacao '{cid}' por {inter.author.id}: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao processar sua participacao. Tenta de novo.", ephemeral=True)
            except Exception:
                pass

    async def _handle_participation(self, inter: disnake.MessageInteraction, giveaway_id: str, task_id: str):
        giveaway = GiveawaysManager.obter_giveaway(giveaway_id)
        if not giveaway:
            print(f"[GIVEAWAYS] Sorteio '{giveaway_id}' nao encontrado no DB (clique de {inter.author.id}).")
            await inter.response.send_message("Sorteio nao encontrado.", ephemeral=True)
            return
        task = next((t for t in giveaway.get("tasks", []) if t.get("id") == task_id), None)

        if not task:
            await inter.response.send_message("Sorteio nao encontrado.", ephemeral=True)
            return

        if task.get("rolled") or task.get("status") == "finished":
            await inter.response.send_message("Este sorteio ja foi encerrado!", ephemeral=True)
            return

        user_id = inter.author.id
        participants = task.get("participants", [])

        if user_id in participants:
            participants.remove(user_id)
            feedback_msg = "Voce saiu do sorteio."
        else:
            success, reason = GiveawaysManager.check_requirements(inter.author, giveaway)
            if not success:
                await inter.response.send_message(
                    f"Voce nao pode entrar neste sorteio.\n**Motivo:** {reason}",
                    ephemeral=True,
                )
                return

            participants.append(user_id)
            feedback_msg = "Voce esta participando do sorteio!"

        task["participants"] = participants
        GiveawaysManager.atualizar_task(giveaway_id, task_id, task)

        await inter.response.send_message(feedback_msg, ephemeral=True)

        giveaway = GiveawaysManager.obter_giveaway(giveaway_id)
        task = next((t for t in giveaway.get("tasks", []) if t.get("id") == task_id), None)

        try:
            cid = f"Giveaways_Participate_{giveaway_id}/{task_id}"
            is_finished = task.get("status") == "finished"
            _embed, _view, container_components = message.build_giveaway_message(
                giveaway, task, finished=is_finished, custom_id=cid
            )
            await inter.message.edit(components=container_components, embed=None)
        except Exception as e:
            print(f"Erro ao atualizar mensagem do sorteio: {e}")

    async def _send_participants_list(self, inter: disnake.MessageInteraction, giveaway_id: str, task_id: str):
        await inter.response.defer(ephemeral=True)

        giveaway = GiveawaysManager.obter_giveaway(giveaway_id)
        if not giveaway:
            print(f"[GIVEAWAYS] Sorteio '{giveaway_id}' nao encontrado no DB (lista participantes).")
            await inter.followup.send("Sorteio nao encontrado.", ephemeral=True)
            return
        task = next((t for t in giveaway.get("tasks", []) if t.get("id") == task_id), None)

        if not task:
            await inter.followup.send("Sorteio nao encontrado.", ephemeral=True)
            return

        participants = task.get("participants", [])
        if not participants:
            await inter.followup.send("Este sorteio ainda nao possui participantes.", ephemeral=True)
            return

        content = ""
        for i, user_id in enumerate(participants, 1):
            user = self.bot.get_user(user_id)
            if user:
                content += f"{i}. {user.name} (ID: {user_id})\n"
            else:
                content += f"{i}. Usuario Desconhecido (ID: {user_id})\n"

        file_bytes = io.BytesIO(content.encode("utf-8"))
        file = disnake.File(file_bytes, filename=f"participantes_{task_id}.txt")
        await inter.followup.send(file=file, ephemeral=True)


def setup(bot: commands.Bot):
    bot.add_cog(GiveawaysCog(bot))
