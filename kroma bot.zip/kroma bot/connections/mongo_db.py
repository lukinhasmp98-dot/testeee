"""Compatibility shim kept for legacy modules.

Kroma Studio persists through functions.database in data/documents.json. No
Mongo client is opened by this module.
"""
bot_collection = None
collection = None

def init_connection(): return None
def get_mongo_connection(): return None
def get_client(): return None
def get_main_database(): return None
def get_config_path(): return None
def set_config_path(path: str): return None
