"""Kroma Studio Discord bot — local, self-contained runtime."""
import asyncio
import os
import sys
import traceback
from pathlib import Path

import disnake
from disnake.ext import commands
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from functions.database import Database

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
GUILD_ID = int(os.getenv("GUILD_ID", "0") or 0)
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)

intents = disnake.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=commands.when_mentioned_or("-"), intents=intents, owner_id=OWNER_ID or None, help_command=None, test_guilds=[GUILD_ID] if GUILD_ID else None, reload=True)
bot._fully_ready = False


def load_cogs():
    excluded = {"modules.vip", "modules.cache_sync", "connections", "functions", "scripts", "__pycache__"}
    count = 0
    for root, dirs, files in os.walk(ROOT):
        dirs[:] = [directory for directory in dirs if directory not in {".git", "__pycache__", "node_modules", ".venv", "venv", "vip"}]
        for filename in files:
            if not filename.endswith(".py") or filename.startswith("__") or filename == "main.py": continue
            path = Path(root) / filename
            module = path.relative_to(ROOT).with_suffix("").as_posix().replace("/", ".")
            if any(module == item or module.startswith(item + ".") for item in excluded): continue
            try:
                bot.load_extension(module); count += 1
            except commands.NoEntryPointError:
                continue
            except Exception as exc:
                print(f"[MODULE] Falha ao carregar {module}: {exc}")
                traceback.print_exc()
    print(f"[MODULE] {count} módulo(s) carregado(s); módulos VIP e integrações legadas estão desativados.")


@bot.event
async def on_ready():
    if bot._fully_ready: return
    await Database.load_all()
    config = Database.get_config()
    # IDs de produção vêm do ambiente do host, nunca de um arquivo enviado
    # junto com o código. Assim o mesmo pacote pode ser usado localmente e no
    # Discloud sem expor a configuração do servidor.
    if OWNER_ID:
        config["owner_id"] = str(OWNER_ID)
    if GUILD_ID:
        config["server_id"] = str(GUILD_ID)
    config["plan"] = "kroma"
    Database.save_config(config)
    bot._fully_ready = True
    print(f"[ONLINE] {bot.user} conectado | guilds={len(bot.guilds)}")
    try:
        from health import start_health_server
        asyncio.create_task(start_health_server(bot))
    except Exception as exc:
        print(f"[HEALTH] {exc}")


@bot.event
async def on_guild_join(guild):
    if GUILD_ID and guild.id != GUILD_ID:
        await guild.leave()


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError("Defina DISCORD_TOKEN nas variáveis de ambiente antes de iniciar o bot.")
    load_cogs()
    bot.run(TOKEN)
