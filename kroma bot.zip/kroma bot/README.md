# Kroma Studio Bot

Bot da loja de artes com tickets, PIX manual, fila de produção, entrega no
portfólio, preços, boas-vindas/autorole e sorteios. Os dados operacionais são
mantidos em `data/documents.json` enquanto o processo está em execução.

## Início

1. Copie `.env.example` para `.env`.
2. Informe `DISCORD_TOKEN`, `GUILD_ID` e `OWNER_ID` no `.env`.
3. Instale as dependências: `py -m pip install -r requirements.txt`.
4. Inicie: `py main.py`.

## Operação

- `/central` abre a central da Kroma: tickets, PIX manual, fila, preços e portfólio.
- `/gerar_pix` cria uma cobrança manual com QR e confirmação pela equipe.
- O painel de tickets é configurado na central por seletores de canal, categoria e cargo; não há IDs para copiar.
- Em um ticket de **Orçamento**, a equipe abre o Painel do Atendente, usa **Gerar PIX** e confirma o recebimento. O pedido entra na fila automaticamente.
- A equipe usa **Iniciar produção** no ticket e `/entregar_arte arquivo:<imagem> descricao:<texto>` quando concluir. A entrega sai da fila e vai para o canal de portfólio definido na Central.
- A tabela de preços é visível em `/precos` e editável em `/central`.
- `/boas_vindas`, `/autorole` e `/sorteio` configuram diretamente os recursos de comunidade no servidor.

## Publicar no Discloud

O pacote já contém `discloud.config` com `TYPE=bot` e `MAIN=main.py`. Configure
`DISCORD_TOKEN`, `GUILD_ID`, `OWNER_ID`, `MONGODB_URI` e `MONGODB_DATABASE`.
Para upload privado por ZIP, crie o `.env` na raiz a partir de `.env.example` e
envie-o junto: essa é a forma de o Discloud carregar os segredos. O `.env` está
protegido pelo `.gitignore`, portanto nunca o suba ao Git ou compartilhe o ZIP
em público. Se o deploy for por integração com GitHub, deixe o `.env` fora do
repositório e informe as mesmas variáveis na área **Environment Variables** do
Discloud. `config.json` e os dados locais continuam excluídos do deploy.

Depois do primeiro boot, execute `/central` no seu servidor para configurar:

1. Canal/categoria/cargos e publicar o painel de tickets.
2. Chave PIX manual e ativar o PIX.
3. Canal público da fila e publicar a fila.
4. Canal público do portfólio.

Importante: o disco de um host pode ser recriado em atualizações. Com
`MONGODB_URI` definido, tickets, pagamentos, fila, preços, portfólio, boas-vindas
e sorteios são gravados no MongoDB e sobrevivem ao redeploy. Sem essa variável,
o modo local em `data/documents.json` continua existindo apenas para testar na
sua máquina.

Os módulos VIP foram mantidos apenas como arquivos de referência da base original e não são carregados pelo bot.
