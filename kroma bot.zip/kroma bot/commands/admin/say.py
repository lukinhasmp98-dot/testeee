import disnake
from disnake.ext import commands
from functions.permissions import Permissions

class SayCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(
        name="say",
        description="Envia uma mensagem personalizada no canal.",
        default_member_permissions=disnake.Permissions(manage_messages=True)
    )
    async def say(self, inter: disnake.ApplicationCommandInteraction):
        await inter.response.send_modal(SayV2Modal())

class SayV2Modal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Conteúdo da Mensagem",
                custom_id="content",
                style=disnake.TextInputStyle.paragraph,
                placeholder="Dica: Use [separador] para uma linha divisória.",
                required=True,
                max_length=4000
            ),
            disnake.ui.Label(
                "Thumbnail (Opcional)",
                disnake.ui.FileUpload(custom_id="thumb_file", required=False)
            ),
            disnake.ui.Label(
                "Banner (Opcional)",
                disnake.ui.FileUpload(custom_id="banner_file", required=False)
            ),
            disnake.ui.Label(
                "Posição do Banner",
                disnake.ui.StringSelect(
                    custom_id="banner_pos",
                    options=[
                        disnake.SelectOption(label="Banner em Cima", value="top"),
                        disnake.SelectOption(label="Banner em Baixo", value="bottom", default=True),
                    ],
                    required=False
                )
            ),
            disnake.ui.Label(
                "Arquivo (Opcional)",
                disnake.ui.FileUpload(custom_id="attachment_file", required=False)
            )
        ]
        super().__init__(title="Enviar Mensagem", custom_id="SayV2_Modal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        def get_resolved(key):
            val = inter.resolved_values.get(key)
            if isinstance(val, list) and val:
                return val
            return None


        def get_val(key, default=None):
            val = inter.values.get(key)
            if isinstance(val, list) and val:
                return val[0]
            return val or default

        content = inter.text_values["content"]
        banner_pos = get_val("banner_pos", "bottom")

        thumb_attachments = get_resolved("thumb_file")
        banner_attachments = get_resolved("banner_file")
        msg_attachments = get_resolved("attachment_file")

        file_to_send = None
        if msg_attachments:
            file_to_send = await msg_attachments[0].to_file()

        root_components = []

        text_blocks = []
        parts = content.split("[separador]")
        for i, part in enumerate(parts):
            text = part.strip()
            if text:
                text = text.replace("[vazio]", "\u200b")
                text_blocks.append(disnake.ui.TextDisplay(text))
            if i < len(parts) - 1:
                text_blocks.append(disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small))

        if thumb_attachments:
            thumb_url = thumb_attachments[0].url
            if text_blocks and isinstance(text_blocks[0], disnake.ui.TextDisplay):
                first_text = text_blocks.pop(0)
                text_blocks.insert(0, disnake.ui.Section(
                    first_text,
                    accessory=disnake.ui.Thumbnail(media=thumb_url)
                ))
            else:
                text_blocks.insert(0, disnake.ui.Section(
                    accessory=disnake.ui.Thumbnail(media=thumb_url)
                ))

        banner_gallery = None
        if banner_attachments:
            banner_url = banner_attachments[0].url
            banner_gallery = disnake.ui.MediaGallery(disnake.MediaGalleryItem(banner_url))

        if banner_gallery and banner_pos == "top":
            root_components.append(banner_gallery)

        root_components.extend(text_blocks)

        if banner_gallery and banner_pos == "bottom":
            root_components.append(banner_gallery)

        if file_to_send:
            root_components.append(disnake.ui.Separator())
            root_components.append(disnake.ui.File(file=f"attachment://{file_to_send.filename}"))


        if not root_components:
            root_components.append(disnake.ui.TextDisplay("\u200b"))

        await inter.channel.send(
            components=root_components,
            file=file_to_send,
            flags=disnake.MessageFlags(is_components_v2=True)
        )

        confirm_components = [
            disnake.ui.Container(
                disnake.ui.TextDisplay("✅ **Mensagem enviada com sucesso!**"),

            )
        ]

        await inter.response.send_message(
            components=confirm_components,
            ephemeral=True,
            flags=disnake.MessageFlags(is_components_v2=True)
        )

        import asyncio
        await asyncio.sleep(3)
        try:
            await inter.delete_original_response()
        except Exception:
            pass

def setup(bot: commands.Bot):
    bot.add_cog(SayCommand(bot))
