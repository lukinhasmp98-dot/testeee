import disnake
from disnake.ext import commands
from functions.permissions import Permissions

class BanCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_accent(self) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @commands.slash_command(
        name="ban",
        description="Banir um usuário do servidor.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(ban_members=True)
    async def ban(self, inter: disnake.CommandInteraction, user: disnake.User, motivo: str = "Não informado"):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        member = inter.guild.get_member(user.id)
        if member and member.top_role >= inter.author.top_role and inter.author.id != inter.guild.owner_id:
            return await inter.response.send_message("❌ Você não pode banir alguém com cargo igual ou superior ao seu.", ephemeral=True)

        try:
            await inter.guild.fetch_ban(user)
            return await inter.response.send_message(f"❌ O usuário **{user.name}** já está banido deste servidor.", ephemeral=True)
        except disnake.NotFound:
            pass
        except Exception as e:
            print(f"[BAN ERROR] Erro ao buscar ban: {e}")

        try:
            await inter.guild.ban(user, reason=f"Executor: {inter.author} | Motivo: {motivo}")
            await inter.response.send_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Usuário Banido\n-# O martelo do ban foi utilizado."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Usuário:** {user.name} (`{user.id}`)\n**Motivo:** `{motivo}`")
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True),
                ephemeral=True
            )
        except Exception as e:
            await inter.response.send_message(f"❌ Erro ao banir: {e}", ephemeral=True)

    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    async def prefix_ban(self, ctx: commands.Context, user: disnake.User, *, motivo: str = "Não informado"):
        try: await ctx.message.delete()
        except Exception: pass

        if not await Permissions.check_user(ctx.author.id):
            return await ctx.send("❌ Você não tem permissão para usar este comando.", delete_after=10)

        member = ctx.guild.get_member(user.id)
        if member and member.top_role >= ctx.author.top_role and ctx.author.id != ctx.guild.owner_id:
            return await ctx.send("❌ Você não pode banir alguém com cargo igual ou superior ao seu.")

        try:
            await ctx.guild.fetch_ban(user)
            return await ctx.send(f"❌ O usuário **{user.name}** já está banido deste servidor.", delete_after=10)
        except disnake.NotFound:
            pass
        except Exception as e:
            print(f"[BAN ERROR PREFIX] Erro ao buscar ban: {e}")

        try:
            await ctx.guild.ban(user, reason=f"Executor: {ctx.author} | Motivo: {motivo}")

            await ctx.send(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"✅ **{user.name}** foi banido com sucesso."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"# Usuário Banido\n-# O martelo do ban foi utilizado."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Usuário:** {user.name} (`{user.id}`)\n**Motivo:** `{motivo}`"),

                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True),
                delete_after=15
            )
        except Exception as e:
            await ctx.send(f"❌ Erro ao banir: {e}", delete_after=10)

def setup(bot: commands.Bot):
    bot.add_cog(BanCommand(bot))
