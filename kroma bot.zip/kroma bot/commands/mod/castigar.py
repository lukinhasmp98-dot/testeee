import disnake
from disnake.ext import commands
import datetime
from functions.permissions import Permissions

class TimeoutCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_accent(self) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @commands.slash_command(
        name="castigar",
        description="Aplicar timeout (castigo) em um usuário.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(moderate_members=True)
    async def castigar(self, inter: disnake.CommandInteraction, user: disnake.Member, tempo: str, motivo: str = "Não informado"):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        seconds = 0
        try:
            unit = tempo[-1].lower()
            amount = int(tempo[:-1])
            if unit == 's': seconds = amount
            elif unit == 'm': seconds = amount * 60
            elif unit == 'h': seconds = amount * 3600
            elif unit == 'd': seconds = amount * 86400
            else: raise ValueError
        except Exception:
            return await inter.response.send_message("❌ Formato de tempo inválido. Use: 10m, 1h, 1d.", ephemeral=True)

        duration = datetime.timedelta(seconds=seconds)
        try:
            await user.timeout(duration=duration, reason=f"Executor: {inter.author} | Motivo: {motivo}")
            await inter.response.send_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Usuário Castigado\n-# O membro foi silenciado."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Usuário:** {user.mention} (`{user.id}`)\n**Tempo:** `{tempo}`\n**Motivo:** `{motivo}`")
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
        except Exception as e:
            await inter.response.send_message(f"❌ Erro ao aplicar castigo: {e}", ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(TimeoutCommand(bot))
