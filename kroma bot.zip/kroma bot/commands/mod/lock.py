import disnake
from disnake.ext import commands
from functions.permissions import Permissions


class LockCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(
        name="lock",
        description="Bloqueia o envio de mensagens no canal.",
        default_member_permissions=disnake.Permissions(manage_guild=True),
    )
    @commands.has_permissions(manage_channels=True)
    async def lock(self, inter: disnake.CommandInteraction, canal: disnake.TextChannel = None):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        canal = canal or inter.channel
        overwrite = canal.overwrites_for(inter.guild.default_role)
        if overwrite.send_messages is False:
            return await inter.response.send_message("❌ Este canal já está bloqueado.", ephemeral=True)

        overwrite.send_messages = False
        try:
            await canal.set_permissions(inter.guild.default_role, overwrite=overwrite, reason=f"Lock por {inter.author}")

            await inter.response.send_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Canal Bloqueado\n-# O envio de mensagens foi desativado."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Canal:** {canal.mention}"),
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True),
                ephemeral=True,
            )

            try:
                await canal.send(
                    components=[
                        disnake.ui.Container(
                            disnake.ui.TextDisplay(f"# 🔒 Canal Bloqueado\n-# Os membros não podem mais enviar mensagens neste canal."),
                            disnake.ui.Separator(),
                            disnake.ui.TextDisplay(f"**Executor:** {inter.author.mention}"),
                        )
                    ],
                    flags=disnake.MessageFlags(is_components_v2=True),
                )
            except Exception as send_err:
                print(f"[Lock] erro ao avisar bloqueio no canal: {send_err}")

        except Exception as e:
            try:
                await inter.response.send_message(f"❌ Erro ao dar lock: {e}", ephemeral=True)
            except Exception:
                pass


class UnlockCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(
        name="unlock",
        description="Desbloqueia o envio de mensagens no canal.",
        default_member_permissions=disnake.Permissions(manage_guild=True),
    )
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, inter: disnake.CommandInteraction, canal: disnake.TextChannel = None):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        canal = canal or inter.channel
        overwrite = canal.overwrites_for(inter.guild.default_role)
        if overwrite.send_messages is not False:
            return await inter.response.send_message("❌ Este canal não está bloqueado.", ephemeral=True)

        overwrite.send_messages = None
        try:
            await canal.set_permissions(inter.guild.default_role, overwrite=overwrite, reason=f"Unlock por {inter.author}")

            await inter.response.send_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Canal Desbloqueado\n-# O envio de mensagens foi restaurado."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Canal:** {canal.mention}"),
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True),
                ephemeral=True,
            )

            try:
                await canal.send(
                    components=[
                        disnake.ui.Container(
                            disnake.ui.TextDisplay(f"# 🔓 Canal Desbloqueado\n-# Os membros já podem voltar a conversar neste canal."),
                            disnake.ui.Separator(),
                            disnake.ui.TextDisplay(f"**Executor:** {inter.author.mention}"),
                        )
                    ],
                    flags=disnake.MessageFlags(is_components_v2=True),
                )
            except Exception as send_err:
                print(f"[Unlock] erro ao avisar desbloqueio no canal: {send_err}")

        except Exception as e:
            try:
                await inter.response.send_message(f"❌ Erro ao desbloquear: {e}", ephemeral=True)
            except Exception:
                pass


def setup(bot: commands.Bot):
    bot.add_cog(LockCommand(bot))
    bot.add_cog(UnlockCommand(bot))
