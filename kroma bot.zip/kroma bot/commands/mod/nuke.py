import disnake
from disnake.ext import commands
from functions.permissions import Permissions


class NukeCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot


    @commands.slash_command(
        name="nuke",
        description="Apaga o canal atual e o recria do zero.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(administrator=True)
    async def nuke(self, inter: disnake.CommandInteraction):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        canal = inter.channel
        try:

            new_channel = await canal.clone(reason=f"Nuke por {inter.author}")

            await canal.delete(reason=f"Nuke por {inter.author}")

            await new_channel.edit(position=canal.position)

            await new_channel.send(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Canal Resetado (Nuke)\n-# Este canal foi recriado completamente."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Executor:** {inter.author.mention}")
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True),
                delete_after=3
            )
        except Exception as e:

            try:
                await inter.response.send_message(f"❌ Erro ao dar nuke: {e}", ephemeral=True)
            except Exception:
                pass

def setup(bot: commands.Bot):
    bot.add_cog(NukeCommand(bot))
