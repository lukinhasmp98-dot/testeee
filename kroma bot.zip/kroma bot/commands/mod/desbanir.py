import disnake
from disnake.ext import commands
from functions.permissions import Permissions

class UnbanCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_accent(self) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @commands.slash_command(
        name="desbanir",
        description="Remover o banimento de um usuário.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(ban_members=True)
    async def desbanir(self, inter: disnake.CommandInteraction, user_id: str):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        try:
            user = await self.bot.fetch_user(int(user_id))
            await inter.guild.unban(user, reason=f"Executor: {inter.author}")
            await inter.response.send_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Usuário Desbanido\n-# O acesso foi restaurado."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Usuário:** {user.name} (`{user.id}`)")
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
        except Exception as e:
            await inter.response.send_message(f"❌ Erro ao desbanir: {e}", ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(UnbanCommand(bot))
