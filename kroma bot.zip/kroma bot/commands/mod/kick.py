import disnake
from disnake.ext import commands
from functions.permissions import Permissions

class KickCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_accent(self) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @commands.slash_command(
        name="kick",
        description="Expulsar um usuário do servidor.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(kick_members=True)
    async def kick(self, inter: disnake.CommandInteraction, user: disnake.Member, motivo: str = "Não informado"):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        if user.top_role >= inter.author.top_role and inter.author.id != inter.guild.owner_id:
            return await inter.response.send_message("❌ Você não pode expulsar alguém com cargo igual ou superior ao seu.", ephemeral=True)

        try:
            await user.kick(reason=f"Executor: {inter.author} | Motivo: {motivo}")
            await inter.response.send_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Usuário Expulso\n-# O membro foi removido do servidor."),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(f"**Usuário:** {user.mention} (`{user.id}`)\n**Motivo:** `{motivo}`")
                    )
                ],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
        except Exception as e:
            await inter.response.send_message(f"❌ Erro ao expulsar: {e}", ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(KickCommand(bot))
