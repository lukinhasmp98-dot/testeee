import disnake
from disnake.ext import commands
from functions.permissions import Permissions

class ClearCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_accent(self) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @commands.slash_command(
        name="limpar",
        description="Limpa mensagens do canal atual.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(manage_messages=True)
    async def limpar(self, inter: disnake.CommandInteraction, quantidade: int):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        if quantidade <= 0 or quantidade > 1000:
            return await inter.response.send_message("❌ Quantidade inválida (mín: 1, máx: 1000).", ephemeral=True)

        await inter.response.defer(ephemeral=True)
        try:
            deleted = await inter.channel.purge(limit=quantidade)
            await inter.edit_original_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# Canal Limpo\n-# Foram removidas `{len(deleted)}` mensagens.")
                    )
                ]
            )
        except Exception as e:
            await inter.followup.send(f"❌ Erro ao limpar: {e}", ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(ClearCommand(bot))
