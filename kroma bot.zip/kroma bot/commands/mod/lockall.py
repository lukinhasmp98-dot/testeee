import disnake
from disnake.ext import commands
from functions.permissions import Permissions
import asyncio

class LockAllCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_accent(self) -> disnake.Colour:
        return disnake.Colour(0x5865F2)

    @commands.slash_command(
        name="lockall",
        description="Bloqueia o envio de mensagens em todos os canais de texto.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(administrator=True)
    async def lockall(self, inter: disnake.CommandInteraction):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        await inter.response.defer(ephemeral=True)

        count = 0
        guild = inter.guild
        for channel in guild.text_channels:
            overwrite = channel.overwrites_for(guild.default_role)
            if overwrite.send_messages is not False:
                overwrite.send_messages = False
                try:
                    await channel.set_permissions(guild.default_role, overwrite=overwrite, reason=f"LockAll por {inter.author}")
                    count += 1
                except Exception:
                    continue

        await inter.edit_original_message(
            components=[
                disnake.ui.Container(
                    disnake.ui.TextDisplay(f"# Bloqueio Total\n-# Todos os canais de texto acessíveis foram bloqueados."),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(f"**Canais processados:** `{count}`")
                )
            ]
        )

    @commands.slash_command(
        name="unlockall",
        description="Desbloqueia o envio de mensagens em todos os canais de texto.",
        default_member_permissions=disnake.Permissions(manage_guild=True)
    )
    @commands.has_permissions(administrator=True)
    async def unlockall(self, inter: disnake.CommandInteraction):
        if not await Permissions.check_user(inter.author.id):
            return await inter.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        await inter.response.defer(ephemeral=True)

        count = 0
        guild = inter.guild
        for channel in guild.text_channels:
            overwrite = channel.overwrites_for(guild.default_role)
            if overwrite.send_messages is False:
                overwrite.send_messages = None
                try:
                    await channel.set_permissions(guild.default_role, overwrite=overwrite, reason=f"UnlockAll por {inter.author}")
                    count += 1
                except Exception:
                    continue

        await inter.edit_original_message(
            components=[
                disnake.ui.Container(
                    disnake.ui.TextDisplay(f"# Desbloqueio Total\n-# O envio de mensagens foi restaurado em todos os canais."),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(f"**Canais processados:** `{count}`")
                )
            ]
        )

def setup(bot: commands.Bot):
    bot.add_cog(LockAllCommand(bot))
