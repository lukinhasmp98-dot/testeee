"""Manual PIX checkout. No external payment gateway is used."""
import io
import time
import uuid
import disnake
from disnake.ext import commands
from functions.database import Database
from functions.permissions import Permissions
from functions.qr_code import QRGenerator


FLAGS = disnake.MessageFlags(is_components_v2=True)

def card(title, text, *, color=None):
    return [disnake.ui.Container(disnake.ui.TextDisplay(f"# {title}"), disnake.ui.Separator(), disnake.ui.TextDisplay(text), accent_colour=color or disnake.Colour(0x43DBD0))]


class ManualPix(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.slash_command(name="gerar_pix", description="Gera uma cobrança PIX manual para um cliente.", default_member_permissions=disnake.Permissions(manage_guild=True))
    async def gerar_pix(self, inter, preco: float, usuario: disnake.Member, descricao: str = "Pedido Kroma Studio"):
        if not await Permissions.check_user(inter.user.id):
            return await inter.response.send_message(components=card("Acesso restrito", "Somente a equipe pode gerar cobranças.", color=disnake.Colour.red()), flags=FLAGS, ephemeral=True)
        if preco <= 0: return await inter.response.send_message(components=card("Valor inválido", "Informe um valor maior que zero.", color=disnake.Colour.red()), flags=FLAGS, ephemeral=True)
        config = Database.get_config(); pix = config.get("manual_pix", {})
        key = str(pix.get("key") or "").strip()
        if not pix.get("enabled") or not key:
            return await inter.response.send_message(components=card("PIX não configurado", "Abra a central e configure/ative a chave PIX manual.", color=disnake.Colour.red()), flags=FLAGS, ephemeral=True)
        payment_id = f"KROMA-{uuid.uuid4().hex[:8].upper()}"; expires = int(time.time() + 60 * 60)
        image = None
        try:
            raw = await QRGenerator.generate(key)
            if raw: image = disnake.File(io.BytesIO(raw), filename="pix-kroma.png")
        except Exception: pass
        details = f"**Cliente:** {usuario.mention}\n**Pedido:** {descricao[:120]}\n**Valor:** `R$ {preco:,.2f}`\n**Recebedor:** {pix.get('recipient') or 'Kroma Studio'}\n**Válido até:** <t:{expires}:R>\n\n**Chave PIX**\n```\n{key}\n```\n-# {pix.get('message') or 'Após o pagamento, envie o comprovante neste atendimento.'}"
        if image:
            components = [disnake.ui.Container(disnake.ui.TextDisplay("# PIX MANUAL  /  KROMA STUDIO"), disnake.ui.Separator(), disnake.ui.TextDisplay(details), disnake.ui.MediaGallery(disnake.MediaGalleryItem(media="attachment://pix-kroma.png")), accent_colour=disnake.Colour(0x43DBD0))]
        else:
            components = card("PIX MANUAL  /  KROMA STUDIO", details)
        components.append(disnake.ui.ActionRow(disnake.ui.Button(label="Copiar chave PIX", custom_id=f"KromaPix:copy:{payment_id}", style=disnake.ButtonStyle.secondary), disnake.ui.Button(label="Confirmar recebimento", custom_id=f"KromaPix:confirm:{payment_id}", style=disnake.ButtonStyle.success)))
        await inter.response.send_message(components=components, file=image, flags=FLAGS)
        payments = Database.get_document("manual_pix_payments") or {}; payments[payment_id] = {"amount": preco, "user_id": usuario.id, "staff_id": inter.user.id, "description": descricao[:120], "key": key, "status": "awaiting_proof", "created_at": time.time(), "expires_at": expires, "channel_id": inter.channel.id}; Database.save_document("manual_pix_payments", payments)

    @commands.Cog.listener("on_button_click")
    async def pix_buttons(self, inter):
        custom_id = getattr(inter.component, "custom_id", "")
        if not custom_id.startswith("KromaPix:"): return
        _, action, payment_id = custom_id.split(":", 2); payments = Database.get_document("manual_pix_payments") or {}; payment = payments.get(payment_id)
        if not payment: return await inter.response.send_message(components=card("Cobrança indisponível", "Esta cobrança não foi encontrada.", color=disnake.Colour.red()), flags=FLAGS, ephemeral=True)
        if action == "copy": return await inter.response.send_message(components=card("PIX copia e cola", f"```\n{payment['key']}\n```"), flags=FLAGS, ephemeral=True)
        if action == "confirm":
            if not await Permissions.check_user(inter.user.id): return await inter.response.send_message(components=card("Acesso restrito", "A confirmação é feita pela equipe.", color=disnake.Colour.red()), flags=FLAGS, ephemeral=True)
            if payment.get("status") == "approved": return await inter.response.send_message(components=card("Já confirmado", "Este pagamento já foi registrado."), flags=FLAGS, ephemeral=True)
            payment.update({"status": "approved", "approved_at": time.time(), "confirmed_by": inter.user.id}); payments[payment_id] = payment; Database.save_document("manual_pix_payments", payments)
            sales = Database.get_document("kroma_sales") or []; sales.append({"id": payment_id, "amount": payment["amount"], "customer_id": payment["user_id"], "description": payment["description"], "approved_at": payment["approved_at"]}); Database.save_document("kroma_sales", sales)
            queue_note = ""
            if payment.get("ticket_id"):
                from functions.art_queue import add_confirmed_payment
                if await add_confirmed_payment(inter.bot, {**payment, "id": payment_id}):
                    queue_note = " O cliente entrou automaticamente na fila de artes."
            return await inter.response.send_message(components=card("Pagamento confirmado", f"`{payment_id}` foi marcado como recebido. A venda entrou no faturamento local.{queue_note}"), flags=FLAGS)


def setup(bot): bot.add_cog(ManualPix(bot))
