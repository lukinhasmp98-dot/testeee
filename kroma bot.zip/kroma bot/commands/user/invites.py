import disnake
from disnake.ext import commands
from functions.utils import Utils
from modules.invites import helpers

class InvitesCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(name="convites", description="Ver convites de um usuário.", guild_ids=[Utils.get_server_id()])
    async def convites(self, inter: disnake.CommandInteraction, user: disnake.Member = None):
        await inter.response.defer(ephemeral=True)
        user = user or inter.user
        invites_data = helpers.get_invites_data()
        guild_id = str(inter.guild.id)
        user_id = str(user.id)

        data = invites_data.get(guild_id, {}).get("invites", {}).get(user_id, {"valid": 0, "fake": 0, "left": 0, "bonus": 0, "total": 0})

        content = (
            f"## Resumo de Convites\n"
            f"-# Informações gerais de {user.mention}\n\n"
            f"**Estatísticas principais**\n"
            f"-# Convites Válidos: `{data['valid']}`\n"
            f"-# Convites Bônus: `{data['bonus']}`\n"
            f"-# Total Geral: `{data['total']}`\n\n"
            f"**Logs detalhados**\n"
            f"-# Convites Falsos: `{data['fake']}`\n"
            f"-# Pessoas que Saíram: `{data['left']}`"
        )

        colors = helpers.Database.get_document("custom_colors")
        primary_hex = colors.get("primary")
        accent = disnake.Colour.from_hex(primary_hex) if primary_hex else None

        await inter.followup.send(
            components=[disnake.ui.Container(disnake.ui.TextDisplay(content))],
            flags=disnake.MessageFlags(is_components_v2=True)
        )

def setup(bot: commands.Bot):
    bot.add_cog(InvitesCommand(bot))
