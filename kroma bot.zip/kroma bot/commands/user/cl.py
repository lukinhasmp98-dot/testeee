import disnake
from disnake.ext import commands

class SelfClearCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _clear_user_messages(self, channel, user_id: int):
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        fourteen_days_ago = now - timedelta(days=14)

        recent_chunk = []

        try:
            async for message in channel.history(limit=None):
                if message.author.id == user_id:
                    if message.created_at > fourteen_days_ago:
                        recent_chunk.append(message)

                        if len(recent_chunk) >= 100:
                            try:
                                await channel.delete_messages(recent_chunk)
                                recent_chunk = []
                            except Exception:
                                pass
                    else:
                        try:
                            await message.delete()
                        except Exception:
                            pass

            if recent_chunk:
                try:
                    if len(recent_chunk) == 1:
                        await recent_chunk[0].delete()
                    else:
                        await channel.delete_messages(recent_chunk)
                except Exception:
                    pass
        except Exception:
            pass

    @commands.slash_command(
        name="cl",
        description="Deletar todas as suas mensagens neste canal.",
    )
    async def cl(self, inter: disnake.CommandInteraction):
        await inter.response.defer(ephemeral=True)
        await self._clear_user_messages(inter.channel, inter.author.id)
        try:
            await inter.delete_original_response()
        except Exception:
            pass

    @commands.Cog.listener("on_message")
    async def on_tomalerda_message(self, message: disnake.Message):
        if message.author.bot:
            return

        if message.content.lower().strip() == "tomalerda":
            try:
                await message.delete()
            except Exception:
                pass
            await self._clear_user_messages(message.channel, message.author.id)

def setup(bot: commands.Bot):
    bot.add_cog(SelfClearCommand(bot))
